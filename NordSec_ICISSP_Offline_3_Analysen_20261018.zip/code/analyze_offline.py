#!/usr/bin/env python3
"""Read-only reanalysis of NordSec's 32 raw-SSE validation episodes.
Inputs: original serving_campaign_20261018 JSONL, unchanged.
Outputs: CSV, PNG, and provenance in chosen new output directory.
No network/GPU/server usage. Requires numpy/matplotlib only for analysis/figures.
"""
import argparse, collections, csv, hashlib, json, math, pathlib, statistics
import numpy as np

DEFAULT_ROOT=pathlib.Path(__file__).resolve().parent/'serving_campaign_20261018'
DEFAULT_OUT=pathlib.Path(__file__).resolve().parent/'results'
TARGETS=(25,50,100)
K=range(16,65)
B=50000
RNG=np.random.default_rng(20261018)

def dumpcsv(path,rows,fields):
    with open(path,'w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)

def ci(v,seed=None):
    a=np.asarray(v,dtype=float)
    boot=a[RNG.integers(0,len(a),size=(B,len(a)))].mean(axis=1)
    return [float(a.mean()),*np.quantile(boot,[.025,.975]).tolist()]

def parse(root):
    episodes={}
    provenance=[]
    for path in sorted(root.glob('validation-*/validation-*.jsonl')):
        digest=hashlib.sha256();records=[]
        with open(path,'rb') as fin:
            for line in fin:
                digest.update(line)
                records.append(json.loads(line))
        starts=[r for r in records if r['record_type']=='episode_start']
        ends=[r for r in records if r['record_type']=='episode_result']
        triggers=[r for r in records if r['record_type']=='progress_trigger']
        assert len(starts)==len(ends)==len(triggers)==1, str(path)
        ep=ends[0]['episode'];meta=ep['plan']
        assert ends[0]['assessment']['measurement_valid'],str(path)
        budget,rep,cond=meta['budget'],meta['repeat'],meta['condition']
        key=(budget,rep,cond)
        assert key not in episodes and budget in (512,2048) and 1<=rep<=8
        trigger=triggers[0]['trigger']['trigger_ns']
        traces=collections.defaultdict(list)
        for r in records:
            if r['record_type']!='sse_wire' or not r['role'].startswith('V'):continue
            data=r['raw_data']
            if data=='[DONE]':continue
            event=json.loads(data)
            ch=event.get('choices') or []
            if len(ch)==0 or not ch[0].get('token_ids'):continue
            ids=ch[0]['token_ids']
            assert len(ids)==1, f'Unexpected multi-token SSE: {path}'
            traces[r['role']].append((r['receive_ns'],ids[0]))
        assert sorted(traces)==[f'V{i}' for i in range(8)], str(path)
        assert all(len(a)==64 for a in traces.values()),str(path)
        for role in traces:
            assert all(traces[role][i][0]<traces[role][i+1][0] for i in range(63))
        rq={r['role']:r['record'] for r in records if r['record_type']=='request_result' and r['role'].startswith('V')}
        assert set(rq)==set(traces)
        for role in rq:
            assert rq[role]['output_token_ids']==[tk for _,tk in traces[role]],str(path)
        episodes[key]={'trigger':trigger,'traces':traces,'requests':rq}
        provenance.append({'source':str(path.relative_to(root)),'sha256':digest.hexdigest(),'budget':budget,'repeat':rep,'condition':cond,'victim_tokens':sum(len(t) for t in traces.values())})
    assert len(episodes)==32 and all((b,r,c) in episodes for b in (512,2048) for r in range(1,9) for c in ('burst','no_burst'))
    return episodes,provenance

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=pathlib.Path,default=DEFAULT_ROOT);ap.add_argument('--out',type=pathlib.Path,default=DEFAULT_OUT);a=ap.parse_args()
    if a.out.exists():raise SystemExit('Output path already exists; choose a new directory')
    a.out.mkdir(parents=True)
    eps,provenance=parse(a.root)
    dumpcsv(a.out/'source_hashes.csv',provenance,list(provenance[0]))
    victim_rows=[];block_rows=[];curve_data={};deadline_block=[];deadline_victims=[]
    issues=[]
    for budget in (512,2048):
      for rep in range(1,9):
        burst=eps[budget,rep,'burst'];control=eps[budget,rep,'no_burst']
        per_role={}
        for vid in range(8):
          role=f'V{vid}';x=burst['traces'][role];y=control['traces'][role]
          bx=np.array([(t-burst['trigger'])/1e6 for t,_ in x]);cy=np.array([(t-control['trigger'])/1e6 for t,_ in y])
          reqb=burst['requests'][role];reqc=control['requests'][role]
          for identity in ('prompt_sha256','prompt_seed','generation_seed'):
            assert reqb[identity]==reqc[identity],(budget,rep,role,identity)
          assert bx[31]>0 and cy[31]>0
          changed=x!=y if False else ([t for _,t in x]!=[t for _,t in y])
          vals=(bx-cy)
          per_role[role]=vals
          victim_rows.append({'budget':budget,'repeat':rep,'victim':role,'d32_ms':vals[31],'d64_ms':vals[63],'d32to64_ms':vals[63]-vals[31],'same_outputs':not changed})
          for cond,ep in (('burst',burst),('no_burst',control)):
            trace=ep['traces'][role];times=np.array([t for t,_ in trace]);trigger=ep['trigger']
            for section in ('after_trigger','token17_32','token33_64'):
              gaps=[]
              for k in range(1,64):
                tprev,tcur=times[k-1],times[k]
                # after_trigger = ITL with its *end* after intervention trigger; may straddle trigger
                if section=='after_trigger' and tcur<=trigger:continue
                if section=='token17_32' and not (16<=k<32):continue
                if section=='token33_64' and not (32<=k<64):continue
                gaps.append((tcur-tprev)/1e6)
              assert gaps
              for d in TARGETS:
                misses=sum(t>d for t in gaps)
                excess=sum(max(t-d,0) for t in gaps)
                deadline_victims.append({'budget':budget,'repeat':rep,'condition':cond,'victim':role,'section':section,'target_ms':d,'itls':len(gaps),'over_target':misses,'fraction_over_target':misses/len(gaps),'excess_ms':excess,'any_over_target':int(misses>0)})
        rows=[a for a in victim_rows if a['budget']==budget and a['repeat']==rep]
        assert len(rows)==8
        delta={k:np.mean([r[k] for r in rows]) for k in ('d32_ms','d64_ms','d32to64_ms')}
        block_rows.append({'budget':budget,'repeat':rep,**delta,'sum_victim64_s':sum(r['d64_ms'] for r in rows)/1000,'sum_victim32_s':sum(r['d32_ms'] for r in rows)/1000,'victim64_seconds_per_1000_burst_input_tokens':sum(r['d64_ms'] for r in rows)/1000*1000/8192,'victim32_seconds_per_1000_burst_input_tokens':sum(r['d32_ms'] for r in rows)/1000*1000/8192,'d32_fraction_of_d64':delta['d32_ms']/delta['d64_ms']})
        curve_data[budget,rep]=np.mean([per_role[f'V{i}'] for i in range(8)],axis=0)
        for section in ('after_trigger','token17_32','token33_64'):
          for d in TARGETS:
            for cond in ('burst','no_burst'):
              rr=[q for q in deadline_victims if q['budget']==budget and q['repeat']==rep and q['section']==section and q['target_ms']==d and q['condition']==cond]
              assert len(rr)==8
              deadline_block.append({'budget':budget,'repeat':rep,'condition':cond,'section':section,'target_ms':d,**{t:float(np.mean([r[t] for r in rr])) for t in ('fraction_over_target','over_target','excess_ms','any_over_target')}})

    dumpcsv(a.out/'paired_victims.csv',victim_rows,list(victim_rows[0]))
    dumpcsv(a.out/'paired_blocks.csv',block_rows,list(block_rows[0]))
    dumpcsv(a.out/'deadline_victims.csv',deadline_victims,list(deadline_victims[0]))
    dumpcsv(a.out/'deadline_blocks.csv',deadline_block,list(deadline_block[0]))

    curve_rows=[]
    for k in K:
        row={'token':k}
        for b in (512,2048):
            res=ci([curve_data[b,r][k-1] for r in range(1,9)])
            for label,val in zip(('mean_ms','lo95_ms','hi95_ms'),res):row[f'b{b}_{label}']=val
        res=ci([curve_data[2048,r][k-1]-curve_data[512,r][k-1] for r in range(1,9)])
        for label,val in zip(('mean_ms','lo95_ms','hi95_ms'),res):row[f'budget2048_minus512_{label}']=val
        curve_rows.append(row)
    dumpcsv(a.out/'token_progress_curve.csv',curve_rows,list(curve_rows[0]))

    summary={'meta':{'episodes':len(eps),'paired_blocks_per_budget':8,'matched_victims_per_budget':64,'tokens_per_victim':64,'burst_input_tokens':8192,'burst_output_tokens':64,'bootstrap_draws':B,'seed':20261018,'deadline_profiles_ms':TARGETS},'effects':{},'deadlines':[],'notes':[]}
    for b in (512,2048):
        bb=[r for r in block_rows if r['budget']==b]
        summary['effects'][str(b)]={metric:ci([r[metric] for r in bb]) for metric in ('d32_ms','d64_ms','d32to64_ms','sum_victim64_s','sum_victim32_s','victim64_seconds_per_1000_burst_input_tokens','victim32_seconds_per_1000_burst_input_tokens','d32_fraction_of_d64')}
    summary['budget_contrasts']={metric:ci([next(r[metric] for r in block_rows if r['budget']==2048 and r['repeat']==rep)-next(r[metric] for r in block_rows if r['budget']==512 and r['repeat']==rep) for rep in range(1,9)]) for metric in ('d32_ms','d64_ms','d32to64_ms','sum_victim64_s','victim64_seconds_per_1000_burst_input_tokens')}
    deadline_rows=[]
    for section in ('after_trigger','token17_32','token33_64'):
      for d in TARGETS:
        for b in (512,2048):
          for met in ('fraction_over_target','over_target','excess_ms','any_over_target'):
            x=[next(r[met] for r in deadline_block if r['budget']==b and r['repeat']==n and r['condition']=='burst' and r['section']==section and r['target_ms']==d)-next(r[met] for r in deadline_block if r['budget']==b and r['repeat']==n and r['condition']=='no_burst' and r['section']==section and r['target_ms']==d) for n in range(1,9)]
            mm=ci(x)
            deadline_rows.append({'section':section,'target_ms':d,'budget':b,'metric':met,'delta_mean':mm[0],'delta_ci_lo':mm[1],'delta_ci_hi':mm[2]})
    dumpcsv(a.out/'deadline_sensitivity.csv',deadline_rows,list(deadline_rows[0]))
    summary['deadline_sensitivity']=deadline_rows
    summary['notes']=['Client-side SSE receipt times, not internal GPU generation.','Deadline check is raw ITL exceedance, not full Etalon fluidity: no profiled prefill deadline and no inter-token slack carryover.','For after_trigger, the ITL ending after the trigger is included even if its earlier token was received before trigger.','Tokens 17-32/33-64 are ordinal segments; the 17-32 segment may contain the few tokens already received before trigger for fast victims.','Summed victim delay is a sum of endpoint penalties, not measured GPU time or paid attacker cost.','Uncorrected exploratory block bootstrap CIs, no familywise significance claims.']
    with open(a.out/'summary.json','w') as f:json.dump(summary,f,indent=2,ensure_ascii=False)
    try:
        import matplotlib;matplotlib.use('Agg');import matplotlib.pyplot as plt
        xs=[r['token'] for r in curve_rows]
        fig,ax=plt.subplots(figsize=(9.2,5.2))
        for b in (512,2048):
            y=[r[f'b{b}_mean_ms'] for r in curve_rows]
            lo=[r[f'b{b}_lo95_ms'] for r in curve_rows]
            hi=[r[f'b{b}_hi95_ms'] for r in curve_rows]
            line=ax.plot(xs,y,label=f'Budget {b}',linewidth=2)[0]
            ax.fill_between(xs,lo,hi,alpha=0.18,color=line.get_color())
        ax.axvline(32,linestyle='--',color='gray',alpha=.7)
        ax.axhline(0,linewidth=.5,color='gray')
        ax.set(xlabel='Output-token position',ylabel='Additional paired receipt delay (ms)',title='Trigger-relative victim progress: burst minus no-burst')
        ax.legend();fig.tight_layout();fig.savefig(a.out/'token_progress.png',dpi=200);plt.close(fig)
        fig,ax=plt.subplots(figsize=(9.2,4.8))
        for b in (512,2048):
          q=[r for r in deadline_rows if r['budget']==b and r['section']=='after_trigger' and r['metric']=='fraction_over_target']
          line=ax.plot([r['target_ms'] for r in q],[r['delta_mean']*100 for r in q],marker='o',label=f'Budget {b}',linewidth=2)[0]
          ax.fill_between([r['target_ms'] for r in q],[r['delta_ci_lo']*100 for r in q],[r['delta_ci_hi']*100 for r in q],alpha=.17,color=line.get_color())
        ax.axhline(0,linewidth=.6,color='gray')
        ax.set(xlabel='Published Etalon decode target (ms)',ylabel='Added share of above-target ITLs (percentage points)',title='Sensitivity to published decode targets (not Etalon fluidity)')
        ax.legend();fig.tight_layout();fig.savefig(a.out/'deadline_sensitivity.png',dpi=200);plt.close(fig)
    except ImportError:pass
    print('root:',a.root,'output:',a.out)
    for b in (512,2048):print(b,'d32:',summary['effects'][str(b)]['d32_ms'],'d64:',summary['effects'][str(b)]['d64_ms'],'late:',summary['effects'][str(b)]['d32to64_ms'],'sum64:',summary['effects'][str(b)]['sum_victim64_s'])
    print('budget contrast late',summary['budget_contrasts']['d32to64_ms'])
    print('DEADLINES, fraction_over_target (percentage points):')
    for r in deadline_rows:
      if r['section']=='after_trigger' and r['metric']=='fraction_over_target':print(r['budget'],r['target_ms'],*(round(r[k]*100,2) for k in ('delta_mean','delta_ci_lo','delta_ci_hi')))
if __name__=='__main__':main()
