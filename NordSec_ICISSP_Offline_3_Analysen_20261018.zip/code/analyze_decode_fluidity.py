#!/usr/bin/env python3
"""Exploratory decode-only Etalon Algorithm 1 replay (NO prefill deadline)."""
import argparse, csv, json, pathlib, math
import numpy as np
from analyze_offline import parse, dumpcsv

RNG=np.random.default_rng(20261019)
B=50000

def ci(x):
 a=np.asarray(x,dtype=float); bs=a[RNG.integers(len(a),size=(B,len(a)))].mean(axis=1)
 return (a.mean(),*np.quantile(bs,[.025,.975]))

def fluidity_decode_only(gaps, target):
 """Reproduce Etalon's Algorithm 1 deadline/slack math for decode intervals only.
 Each gap is inter-token period, no initial prefill deadline. At failures count the
 number of exceeded target slots and reset slack (not just binary miss count).
 """
 slack=0.0;total=0;missed=0
 for g in gaps:
  if g<=target+slack:
   total+=1;slack+=target-g
  else:
   overdue=g-slack-target
   n=math.floor(overdue/target)+1
   missed+=n;total+=n;slack=0.0
 return (total-missed)/total,total,missed

def main():
 p=argparse.ArgumentParser();p.add_argument('--root',type=pathlib.Path,default=pathlib.Path(__file__).parent/'serving_campaign_20261018');p.add_argument('--out',type=pathlib.Path,default=pathlib.Path(__file__).parent/'fluidity_results');a=p.parse_args()
 if a.out.exists():raise SystemExit('Output exists')
 a.out.mkdir()
 eps,prov=parse(a.root)
 allrows=[];blockrows=[];summary=[]
 for b in (512,2048):
  for rep in range(1,9):
   for cond in ('burst','no_burst'):
    ep=eps[b,rep,cond];tg=ep['trigger']
    for role, trace in sorted(ep['traces'].items()):
     t=np.asarray([x[0] for x in trace],dtype=np.int64)
     for mode in ('ending_post_trigger','fully_post_trigger'):
      gap=[]
      for k in range(1,len(t)):
       if mode=='ending_post_trigger' and t[k]<=tg:continue
       if mode=='fully_post_trigger' and t[k-1]<tg:continue
       gap.append((int(t[k])-int(t[k-1]))/1e6)
      assert len(gap)>=42,(b,rep,role,len(gap))
      for d in (25,50,100):
       fluid,denom,miss=fluidity_decode_only(gap,d)
       allrows.append({'budget':b,'repeat':rep,'condition':cond,'victim':role,'mode':mode,'target_ms':d,'fluidity':fluid,'n_intervals':len(gap),'total_deadline_slots':denom,'missed_slots':miss})
    for mode in ('ending_post_trigger','fully_post_trigger'):
     for d in (25,50,100):
      rr=[r for r in allrows if r['budget']==b and r['repeat']==rep and r['condition']==cond and r['mode']==mode and r['target_ms']==d]
      assert len(rr)==8
      blockrows.append({'budget':b,'repeat':rep,'condition':cond,'mode':mode,'target_ms':d,'avg_fluidity':float(np.mean([r['fluidity'] for r in rr])),'fraction_victims_fluidity_at_least_0_9':float(np.mean([r['fluidity']>=.9 for r in rr]))})
 dumpcsv(a.out/'fluidity_decode_victims.csv',allrows,list(allrows[0]))
 dumpcsv(a.out/'fluidity_decode_blocks.csv',blockrows,list(blockrows[0]))
 for mode in ('ending_post_trigger','fully_post_trigger'):
  for d in (25,50,100):
   for b in (512,2048):
    delta=[]; absolute={}
    for c in ('burst','no_burst'):
     vals=[next(r['avg_fluidity'] for r in blockrows if r['budget']==b and r['repeat']==n and r['condition']==c and r['target_ms']==d and r['mode']==mode) for n in range(1,9)]
     absolute[c]=float(np.mean(vals))
    for n in range(1,9):
     br=next(r['avg_fluidity'] for r in blockrows if r['budget']==b and r['repeat']==n and r['condition']=='burst' and r['target_ms']==d and r['mode']==mode)
     no=next(r['avg_fluidity'] for r in blockrows if r['budget']==b and r['repeat']==n and r['condition']=='no_burst' and r['target_ms']==d and r['mode']==mode)
     delta.append(br-no)
    avg,lo,hi=ci(delta)
    summary.append({'mode':mode,'target_ms':d,'budget':b,'no_burst_fluidity':absolute['no_burst'],'burst_fluidity':absolute['burst'],'delta_fluidity':avg,'ci_lo':lo,'ci_hi':hi})
 dumpcsv(a.out/'fluidity_decode_summary.csv',summary,list(summary[0]))
 with open(a.out/'README.txt','w') as f:
  f.write('Decode-only Etalon Algorithm 1 sensitivity (EXPLORATORY, NOT full Etalon fluidity).\\n'
  'In Etalon the first-token prefill deadline depends on prompt length and an independent profiling baseline; those data are absent here.\\n'
  'We initialize slack=0 for the selected decode interval, using D_d 25/50/100ms from Etalon 2024 Section 4.1.\\n'
  'ending_post_trigger includes an ITL crossing the trigger; fully_post_trigger excludes it.\\n'
  'All comparisons use eight paired episodes per budget, eight matched victims per episode.\\n')
 for row in summary:print(row['mode'],row['budget'],row['target_ms'],'baseline',round(row['no_burst_fluidity'],3),'burst',round(row['burst_fluidity'],3),'delta',round(row['delta_fluidity'],3),'CI',round(row['ci_lo'],3),round(row['ci_hi'],3))
if __name__=='__main__':main()
