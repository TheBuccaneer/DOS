"""Post-run forensic checks. No modification of campaign/source files."""
import csv,hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from design import BASELINE,require,sha,file_sha,validate
from analyze_three import load

def leaves(x,prefix=''):
    if isinstance(x,dict):
        out={}
        for k,v in x.items():out.update(leaves(v,prefix+'.'+k if prefix else k))
        return out
    return {prefix:x}

def main():
    data,rows,iterations=load(ROOT/'serving_campaign_768')
    baseline,_,_=load(BASELINE/'serving_campaign_20261018')
    plan=validate(json.loads((ROOT/'plan.json').read_text()))
    require(len(data)==16,'not16')
    identity=[];hook_rows=[];diffs=[];config_differences=[];log_start_end=[]
    total_requests=total_events=total_inputs=total_outputs=0
    output_diff=0;unknown_sources=[]
    for key,(e,a) in data.items():
        budget,repeat,condition=key;ep=e['plan'];trigger=e['trigger']['trigger_ns']
        path=ROOT/'serving_campaign_768'/ep['block_id']/(ep['episode_id']+'.jsonl')
        journal=[json.loads(l) for l in path.read_text().splitlines()]
        total_requests+=len(e['requests']);total_events+=sum(len(r['raw_sse_events']) for r in e['requests'].values())
        total_inputs+=sum(len(p) for p in ep['prompts'].values());total_outputs+=sum(len(r['output_token_ids']) for r in e['requests'].values())
        victim_times={}
        for role,r in e['requests'].items():
            prompt=r['wire_payload']['prompt'];digest=hashlib.sha256(json.dumps(prompt,separators=(',',':')).encode()).hexdigest()
            require(digest==ep['prompt_hashes'][role],'prompt hash mismatch')
            identity.append(dict(episode_id=ep['episode_id'],role=role,request_index=r['request_index'],
                request_id=r['request_id'],prompt_sha256=digest,generation_seed=r['generation_seed'],prompt_seed=r['prompt_seed']))
            if role.startswith('V'):
                victim_times[role]=[event['receive_perf_counter_ns'] for event in r['raw_sse_events'] if event.get('token_ids')]
                require(len(victim_times[role])==64,'victim token count')
        for wire in [r for r in journal if r['record_type']=='intervention_window']:
            counts=[sum(t<=wire['send_ns'] for t in victim_times[f'V{i}']) for i in range(8)]
            require(counts==wire['victim_token_counts'] and all(16<=n<32 for n in counts),'intervention counter/raw discrepancy')
            hook_rows.append(dict(episode_id=ep['episode_id'],role=wire['role'],send_ns=wire['send_ns'],
                trigger_to_hook_ms=(wire['send_ns']-trigger)/1e6,reconstructed_counts=counts))
        require(sum(r['record_type']=='intervention_window' for r in journal)==(4 if condition=='burst' else 0),'hook cardinality')
        for b in [512,2048]:
            ref=baseline[b,repeat,condition][0]
            left=leaves(ref['config_before']['body']['vllm_config']);right=leaves(e['config_before']['body']['vllm_config'])
            for name in sorted(set(left)|set(right)):
                if left.get(name)!=right.get(name):config_differences.append(dict(repeat=repeat,condition=condition,compared_with=b,key=name,baseline=left.get(name),new=right.get(name)))
        log_start_end.append(dict(episode_id=ep['episode_id'],start_wall_ns=journal[0]['wall_time_ns'],end_wall_ns=journal[-1]['wall_time_ns'],
            process_start=e['runtime']['process_start'],pid=e['runtime']['pid'],vllm=e['runtime']['vllm'],python=e['runtime']['python']))
    for repeat in range(1,9):
        a=data[768,repeat,'no_burst'][0];b=data[768,repeat,'burst'][0]
        for i in range(8):
            role=f'V{i}';x=a['requests'][role]['output_token_ids'];y=b['requests'][role]['output_token_ids']
            prefix=next((j for j,(u,v) in enumerate(zip(x,y)) if u!=v),64);output_diff+=prefix<64
            diffs.append(dict(repeat=repeat,request_index=i,common_prefix_tokens=prefix,output_equal=prefix==64))
    old_hashes=json.loads((ROOT/'evidence/BASELINE_READ_ONLY_SHA256.json').read_text())
    require(all(file_sha(p)==h for p,h in old_hashes.items()),'old files changed')
    frozen=json.loads((ROOT/'FROZEN_FILES_SHA256.json').read_text())
    require(all(file_sha(ROOT/p)==h for p,h in frozen.items()),'extension freeze changed')
    binding=json.loads((ROOT/'serving_campaign_768/approval_binding.json').read_text())
    require(binding['approved_plan_sha256']==sha(plan),'execution plan binding')
    require(binding['frozen_files_manifest_sha256']==file_sha(ROOT/'FROZEN_FILES_SHA256.json'),'execution code freeze binding')
    for name,digest in binding['executed_python_sources_sha256'].items():require(file_sha(ROOT/name)==digest,'executed code differs')
    summary=dict(valid_episodes=16,paired_blocks=8,victim_request_pairs=64,completion_requests=total_requests,
        raw_sse_events=total_events,offered_input_tokens=total_inputs,received_output_tokens=total_outputs,
        raw_and_journal_and_executor_copies_match=True,log_segments_match_original_server_bytes=True,
        raw_intervention_windows_match=True,paired_prompt_hashes_seeds_indices_match=True,
        matched_offered_workload_all_three_budgets=True,actual_gpu_work_identity_claimed=False,
        old_files_hashchecked=len(old_hashes),old_files_unchanged=True,frozen_extension_unchanged=True,
        output_different_request_pairs=output_diff,burst_requests=32,
        min_last_hook_to_token32_ms=min(r['min_hook_to_token32_ms'] for r in rows if r['condition']=='burst'),
        configuration_differences_against_old=config_differences,episode_runtime=log_start_end,
        total_scheduler_iterations=len(iterations),exact_per_request_scheduler_chunks_reconstructable=False)
    require(total_requests==160 and total_events==9024 and total_inputs==98304 and total_outputs==8704,'campaign token/request/event accounting')
    for filename,records in [('request_identity_audit.csv',identity),('intervention_window_audit.csv',hook_rows),('output_sequence_pairs.csv',diffs)]:
        with (ROOT/'audit'/filename).open('x',newline='') as f:
            w=csv.DictWriter(f,list(records[0]));w.writeheader();w.writerows(records)
    with (ROOT/'audit/RAW_AUDIT.json').open('x') as f:json.dump(summary,f,indent=2);f.write('\n')
    print(json.dumps({k:v for k,v in summary.items() if k not in ['configuration_differences_against_old','episode_runtime']},indent=2))

if __name__=='__main__':main()
