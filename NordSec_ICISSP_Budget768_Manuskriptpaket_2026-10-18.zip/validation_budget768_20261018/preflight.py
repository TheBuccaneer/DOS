"""Read-only parent audit and installed-source validator; no GPU imports."""
import ast,copy,hashlib,json,sys,types
from pathlib import Path
from design import ROOT,BASELINE,prepare,sha,validate,require,PYTHON,file_sha
from verify import read_episode

def source_gate():
    site=PYTHON.parent.parent/'lib/python3.13/site-packages'
    path=site/'vllm/config/scheduler.py';tree=ast.parse(path.read_text())
    cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='SchedulerConfig')
    method=copy.deepcopy(next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='verify_max_model_len'))
    method.returns=None
    for arg in method.args.args:arg.annotation=None
    scope={'logger':types.SimpleNamespace(warning=lambda *a:None)}
    exec(compile(ast.fix_missing_locations(ast.Module(body=[method],type_ignores=[])),str(path),'exec'),scope)
    obj=types.SimpleNamespace(max_num_batched_tokens=768,enable_chunked_prefill=True,max_num_seqs=16,
        max_num_partial_prefills=1,max_long_partial_prefills=1,long_prefill_token_threshold=0)
    scope['verify_max_model_len'](obj,8192)
    files=['vllm/config/scheduler.py','vllm/v1/core/sched/scheduler.py','vllm/v1/core/sched/async_scheduler.py',
        'vllm/v1/engine/core.py','vllm/v1/utils.py']
    return dict(budget768_accepted_by_actual_installed_validator=True,
        sources=[dict(path=str(site/f),sha256=file_sha(site/f)) for f in files],
        imports_vllm_or_torch=False,requestwise_scheduler_identity_observed=False)

def baseline_audit():
    campaign=BASELINE/'serving_campaign_20261018'
    frozen=json.loads((BASELINE/'FROZEN_FILES_SHA256.json').read_text())
    require(all(file_sha(BASELINE/f)==h for f,h in frozen.items()),'baseline code freeze mismatch')
    summary=json.loads((campaign/'campaign_summary.json').read_text())
    require(not summary['error'] and not summary['not_completed'] and len(summary['episodes'])==32,'baseline incomplete')
    rows=[];requests=events=outputs=0
    for block in json.loads((campaign/'plan.json').read_text())['blocks']:
        for ep in block['episodes']:
            path=campaign/block['block_id']/(ep['episode_id']+'.jsonl')
            episode,result=read_episode(path)
            require(result['measurement_valid'] and episode['origin']=='serving' and episode['plan']==ep,'invalid baseline raw episode')
            # Confirm recorded per-episode log segment against actual immutable server.log bytes.
            with (path.parent/'server.log').open('rb') as f:
                f.seek(episode['log_byte_start']);segment=f.read(episode['log_byte_end']-episode['log_byte_start'])
            require(segment.decode()==episode['iteration_log'],'baseline server log segment mismatch')
            requests+=len(episode['requests']);events+=sum(len(r['raw_sse_events']) for r in episode['requests'].values())
            outputs+=sum(len(r['output_token_ids']) for r in episode['requests'].values())
            rows.append(dict(episode_id=ep['episode_id'],budget=ep['budget'],repeat=ep['repeat'],condition=ep['condition'],
                primary_token32_ms=result['primary_token32_ms'],scheduler=result['scheduler'],window=result['measurement_window'],
                vllm=episode['runtime']['vllm'],python=episode['runtime']['python'],gpu_inventory=episode['runtime']['gpu_inventory']))
    bursts=[r for r in rows if r['condition']=='burst']
    require(all(r['scheduler']['additional_budget_binding_observed'] for r in bursts if r['budget']==512),'baseline512 not binding')
    require(all(r['scheduler']['additional_max_context_tokens']>512 for r in bursts if r['budget']==2048),'baseline2048 ineffective')
    return dict(valid_episodes=32,paired_blocks=16,completion_requests=requests,raw_sse_events=events,output_tokens=outputs,
        code_freeze_matches=True,raw_reassessment_and_log_bytes_match=True,actual_original_budget_difference=True,episodes=rows)

if __name__=='__main__':
    baseline=baseline_audit();static=source_gate();plan=prepare()
    result=dict(baseline=baseline,static=static,new_plan_sha256=sha(plan),baseline_files_written=False)
    with (ROOT/'evidence/PHASE_A.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps(dict(baseline_episodes=32,baseline_raw_events=baseline['raw_sse_events'],source_gate=static['budget768_accepted_by_actual_installed_validator'],new_plan_sha256=sha(plan)),indent=2))
