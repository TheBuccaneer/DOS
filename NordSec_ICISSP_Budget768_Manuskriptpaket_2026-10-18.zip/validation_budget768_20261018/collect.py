#!/usr/bin/env python3
"""Prepare/dry-run/audit, or run the frozen campaign ONLY AFTER explicit user GO."""
import argparse,asyncio,hashlib,importlib.metadata,json,os,secrets,signal,socket,subprocess,sys,time
from pathlib import Path
from design import SETTINGS,MODEL,load_executor,prepare,validate,sha,require,server_command
from instrument import Journal,ReceiptClock,Tap,Sampler,shared_httpx_transport
from verify import configuration,state,assess,read_episode

class DispatchTap(Tap):
    def sent(self,stamp):
        super().sent(stamp)
        self.journal.emit('http_dispatch',role=self.role,request_id=self.plan['request_ids'][self.role],send_ns=stamp)
        if hasattr(self,'intervention_guard'):self.intervention_guard(stamp)

async def workload(base,transport,plan,journal,episode,api_key,base_url):
    events=[asyncio.Event() for _ in range(8)];crossings=[None]*8;counts=[0]*8;single_threshold=[True]*8;tasks=[]
    episode['victim_start_ns']=time.perf_counter_ns()
    async def execute(role,deadline,created):
        clock=ReceiptClock(base.RealClock())
        tap=DispatchTap(transport,plan,role,journal,clock,deadline)
        if role.startswith('E'):
            def guard(stamp):
                snapshot=list(counts)
                journal.emit('intervention_window',role=role,send_ns=stamp,victim_token_counts=snapshot)
                require(all(16<=n<32 for n in snapshot),'token32 window closed at burst HTTP hook')
            tap.intervention_guard=guard
        def received(count,stamp):
            i=int(role[1:])
            if counts[i]<16 and count-counts[i]!=1:single_threshold[i]=False
            counts[i]=count
            if count>=16 and crossings[i] is None:crossings[i]=stamp;events[i].set()
        record=await base.execute_completion_request(transport=tap,clock=clock,url=base_url+'/v1/completions',api_key=api_key,
            model_full_id=MODEL,prompt_token_ids=plan['prompts'][role],max_tokens=plan['outputs'][role],min_tokens=plan['outputs'][role],
            temperature=0,request_seed=plan['seeds'][role],request_id=plan['request_ids'][role],
            role='victim' if role.startswith('V') else 'burst',request_index=int(role[1:]),
            prompt_seed=plan['prompt_seeds'][role],generation_seed=plan['seeds'][role],
            expected_prompt_tokens=len(plan['prompts'][role]),expected_completion_tokens=plan['outputs'][role],
            http_timeout_s=60,on_output_tokens=received if role.startswith('V') else None,
            task_created_ns=created,victim_phase_start_ns=episode['victim_start_ns'])
        record.update(send_ns=tap.dispatch_ns,dispatch_semantics=tap.semantics,wire_payload=tap.payload,scheduled_dispatch_ns=deadline)
        episode['requests'][role]=record;journal.emit('request_result',role=role,record=record)
        return record
    try:
        # No asyncio.Semaphore, no worker queue; one shared pool has 16 slots for
        # at most 12 completion streams plus one metrics request.
        for i in range(8):tasks.append(asyncio.create_task(execute(f'V{i}',episode['victim_start_ns'],time.perf_counter_ns())))
        await asyncio.wait_for(asyncio.gather(*(e.wait() for e in events)),30)
        trigger=max(crossings);episode['trigger']=dict(trigger_ns=trigger,observed_ns=time.perf_counter_ns(),crossings=list(crossings),
            token_counts_at_observation=list(counts),single_token_thresholds=list(single_threshold))
        journal.emit('progress_trigger',trigger=episode['trigger'])
        require(all(single_threshold),'token-16 threshold is not individually resolved')
        require(all(16<=n<32 for n in counts),'token32 window closed at trigger observation')
        if plan['condition']=='burst':
            for i in range(4):tasks.append(asyncio.create_task(execute(f'E{i}',trigger,time.perf_counter_ns())))
        await asyncio.gather(*tasks)
    finally:await base.cancel_all(tasks)

async def run_episode(base,transport,plan,journal,runtime,server_log,api_key,origin='serving'):
    episode=dict(plan=plan,origin=origin,runtime=runtime,requests={},trigger=None,errors=[],metrics_samples=[],
        config_before=None,config_after=None,victim_start_ns=None,iteration_log='')
    journal.emit('episode_start',plan=plan,plan_sha256=sha(plan),runtime=runtime,origin=origin)
    url='http://127.0.0.1:8028';sampler=Sampler(transport,url+'/metrics',journal,api_key);offset=None
    async def snapshot(phase):
        sample=dict(scrape_start_ns=time.perf_counter_ns(),http_status=None,error=None,body=None)
        try:
            sample['http_status'],sample['body']=await transport.get_json(url+'/server_info?config_format=json',{'Authorization':'Bearer '+api_key},10)
            require(api_key not in json.dumps(sample['body']),'secret in configuration snapshot')
        except Exception as exc:sample['error']=type(exc).__name__
        sample['response_ns']=time.perf_counter_ns();episode['config_'+phase]=sample
        journal.emit('configuration_snapshot',phase=phase,sample=sample);return sample
    try:
        configuration(await snapshot('before'),plan['budget'])
        initial=state(await sampler.sample());require(initial['running']==initial['waiting']==0,'server not idle')
        require(abs(initial['process_start']-runtime['process_start'])<2,'metrics not bound to launched server process')
        offset=server_log.stat()
        sampler.start()
        await asyncio.wait_for(workload(base,transport,plan,journal,episode,api_key,url),120)
    except (Exception,asyncio.CancelledError) as exc:
        episode['errors'].append(dict(type=type(exc).__name__,detail=str(exc).replace(api_key,'<redacted>')[:500]))
    finally:
        try:
            deadline=time.monotonic()+5
            while sampler.task is not None and time.monotonic()<deadline:
                await asyncio.sleep(.05)
                final=state(sampler.samples[-1])
                if final['running']==final['waiting']==0 and final['counters']['requests']-initial['counters']['requests']==len(plan['prompts']):break
            await sampler.stop();await asyncio.sleep(.15);await sampler.sample()
            await snapshot('after')
            if offset is not None:
                current=server_log.stat();require((current.st_dev,current.st_ino)==(offset.st_dev,offset.st_ino) and current.st_size>=offset.st_size,'server log replaced/truncated')
                with server_log.open('rb') as f:f.seek(offset.st_size);segment=f.read()
                episode['iteration_log']=segment.decode()
                episode['log_byte_start']=offset.st_size;episode['log_byte_end']=offset.st_size+len(segment)
                journal.emit('iteration_log',raw_text=episode['iteration_log'],byte_start=episode['log_byte_start'],byte_end=episode['log_byte_end'])
        except Exception as exc:episode['errors'].append(dict(type=type(exc).__name__,detail=('finalization failed: '+str(exc)).replace(api_key,'<redacted>')[:500]))
        episode['metrics_samples']=sampler.samples
        result=assess(plan,episode);journal.emit('episode_result',episode=episode,assessment=result);await journal.flush()
    return result

async def campaign(plan,out):
    require(Path(__file__).parent.resolve() in out.resolve().parents,'campaign output must be a new subdirectory of this revision package')
    require(sys.version_info[:2]==(3,13),'run through Python 3.13 runtime.py')
    require(importlib.metadata.version('vllm')=='0.17.1','vLLM version mismatch')
    # Do not attach to or kill a pre-existing service.
    sock=socket.socket()
    try:sock.bind(('127.0.0.1',8028))
    finally:sock.close()
    inventory=subprocess.run(['nvidia-smi','--query-gpu=index,name,memory.total,memory.used,driver_version','--format=csv,noheader'],capture_output=True,text=True,timeout=10)
    import csv
    gpu_rows=list(csv.reader(inventory.stdout.strip().splitlines(),skipinitialspace=True))
    require(inventory.returncode==0 and len(gpu_rows)==1 and gpu_rows[0][:3]==['0','NVIDIA GeForce RTX 3090','24576 MiB'],'single RTX 3090 device 0 unavailable')
    out.mkdir(parents=True,exist_ok=False)
    (out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
    (out/'approval_binding.json').write_text(json.dumps(dict(approved_plan_sha256=sha(plan),inventory=inventory.stdout,source='explicit user GO required by protocol',
        frozen_files_manifest_sha256=hashlib.sha256((Path(__file__).parent/'FROZEN_FILES_SHA256.json').read_bytes()).hexdigest(),
        executed_python_sources_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(Path(__file__).parent.glob('*.py'))}),indent=2))
    base=load_executor();api_key=secrets.token_hex(32);report=[];started=time.monotonic();failure=None
    for block in plan['blocks']:
        child=None;transport=None;log=None
        try:
            require(time.monotonic()-started<5400,'campaign time cap reached')
            bdir=out/block['block_id'];bdir.mkdir();log_path=bdir/'server.log';log=log_path.open('x')
            env=os.environ.copy();env.update(CUDA_VISIBLE_DEVICES='0',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',
                VLLM_NO_USAGE_STATS='1',DO_NOT_TRACK='1',VLLM_HOST_IP='127.0.0.1',PYTHONDONTWRITEBYTECODE='1',
                VLLM_SERVER_DEV_MODE='1',VLLM_API_KEY=api_key)
            command=server_command(block['budget']);log.write('VALIDATION_COMMAND: '+json.dumps(command)+'\n');log.flush()
            child=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            log.write('VALIDATION_API_PID: '+str(child.pid)+'\n');log.flush()
            transport=await shared_httpx_transport(base);deadline=time.monotonic()+180
            while True:
                require(child.poll() is None,'server exited during startup')
                require(time.monotonic()<deadline,'server startup timeout')
                try:
                    status,_=await transport.get_json('http://127.0.0.1:8028/health',{'Authorization':'Bearer '+api_key},2)
                    if status==200:break
                except Exception:pass
                await asyncio.sleep(.5)
            startup=log_path.read_text();require(api_key not in startup,'secret in startup log')
            require('v0.17.1' in startup and f'max_num_batched_tokens={block["budget"]}.' in startup,'startup software/budget not confirmed')
            require('GPU KV cache size: 16,384 tokens' in startup,'fixed KV size not confirmed')
            ticks=int(Path(f'/proc/{child.pid}/stat').read_text().rsplit(')',1)[1].split()[19])
            boot=next(int(x.split()[1]) for x in Path('/proc/stat').read_text().splitlines() if x.startswith('btime '))
            process_start=boot+ticks/os.sysconf('SC_CLK_TCK')
            runtime=dict(python=sys.version,vllm=importlib.metadata.version('vllm'),pid=child.pid,process_start=process_start,
                boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip(),startup_log=startup,gpu_inventory=inventory.stdout)
            for ep in block['episodes']:
                path=bdir/(ep['episode_id']+'.jsonl');journal=Journal(path)
                try:result=await run_episode(base,transport,ep,journal,runtime,log_path,api_key)
                finally:journal.close()
                _,independent=read_episode(path);require(result==independent,'reassessment differs')
                report.append(dict(block_id=block['block_id'],budget=block['budget'],repeat=block['repeat'],episode_id=ep['episode_id'],path=str(path),assessment=result))
                require(result['measurement_valid'],'invalid episode; no retry or replacement')
                if ep['condition']=='burst':
                    sched=result['scheduler']
                    require(sched['additional_budget_binding_observed'] and sched['additional_max_context_tokens']>512 and
                        sched['additional_prefill_decode_overlap_iterations']>0,'768 additional-prefill manipulation not demonstrated; stop without replacement')
                await asyncio.sleep(5)
        except (Exception,asyncio.CancelledError) as exc:
            failure=dict(block_id=block['block_id'],type=type(exc).__name__,detail=str(exc).replace(api_key,'<redacted>')[:500])
        finally:
            cleanup_errors=[]
            if transport is not None:
                try:await transport.close()
                except Exception as exc:cleanup_errors.append(dict(stage='transport_close',type=type(exc).__name__,detail=str(exc).replace(api_key,'<redacted>')[:500]))
            # A client cleanup failure must not skip terminating our own server.
            if child is not None and child.poll() is None:
                try:
                    try:os.killpg(child.pid,signal.SIGTERM)
                    except ProcessLookupError:pass
                    try:await asyncio.to_thread(child.wait,timeout=30)
                    except subprocess.TimeoutExpired:
                        try:os.killpg(child.pid,signal.SIGKILL)
                        except ProcessLookupError:pass
                        await asyncio.to_thread(child.wait,timeout=10)
                except Exception as exc:cleanup_errors.append(dict(stage='owned_server_stop',type=type(exc).__name__,detail=str(exc).replace(api_key,'<redacted>')[:500]))
            if log is not None:
                try:log.close()
                except Exception as exc:cleanup_errors.append(dict(stage='log_close',type=type(exc).__name__))
            if cleanup_errors and failure is None:failure=dict(block_id=block['block_id'],type='CleanupError',detail='cleanup failed; stop without replacement')
            summary=dict(plan_sha256=sha(plan),episodes=report,error=failure,cleanup_errors=cleanup_errors,planned_episodes=plan['serving_episodes'],
                not_completed=[e['episode_id'] for b in plan['blocks'] for e in b['episodes'] if e['episode_id'] not in {r['episode_id'] for r in report}],
                actual_budget_difference_demonstrated=False,scientific_claim_established=False)
            (out/'campaign_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
        if failure:break
    return 1 if failure else 0

def main():
    p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='mode',required=True)
    for name in ['dry-run','run']:
        q=sub.add_parser(name);q.add_argument('--plan',type=Path,required=True)
        if name=='run':q.add_argument('--approved-plan-sha',required=True);q.add_argument('--output-dir',type=Path,required=True)
    q=sub.add_parser('audit');q.add_argument('journal',type=Path,nargs='+')
    a=p.parse_args()
    if a.mode=='audit':
        for path in a.journal:print(json.dumps(dict(path=str(path),assessment=read_episode(path)[1])))
        return 0
    plan=validate(json.loads(a.plan.read_text()))
    if a.mode=='dry-run':
        print(json.dumps(dict(plan_sha256=sha(plan),serving_started=False,episodes=plan['serving_episodes'],completion_requests=plan['completion_requests'],
            server_commands={str(b):server_command(b) for b in [768]}),indent=2));return 0
    frozen=json.loads((Path(__file__).parent/'FROZEN_FILES_SHA256.json').read_text())
    for name,expected in frozen.items():
        require(hashlib.sha256((Path(__file__).parent/name).read_bytes()).hexdigest()==expected,'frozen preparation file changed: '+name)
    require(a.approved_plan_sha==sha(plan),'approval does not bind this exact plan')
    async def limited():return await asyncio.wait_for(campaign(plan,a.output_dir),5400)
    return asyncio.run(limited())

if __name__=='__main__':raise SystemExit(main())
