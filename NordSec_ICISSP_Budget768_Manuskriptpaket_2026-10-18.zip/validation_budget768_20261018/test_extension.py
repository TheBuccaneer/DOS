import asyncio,copy,json,socket,tempfile,time,unittest
from pathlib import Path
from unittest.mock import patch
from design import ROOT,prepare,validate,server_command,load_executor,sha
import original_design
from instrument import Journal
from collect import workload
from verify import assess,read_episode,scheduler
from analyze_three import measures

class Stream:
    async def stream_completion(self,url,headers,payload,timeout_s,*,request_id):
        for i in range(payload['max_tokens']):
            await asyncio.sleep(0)
            yield json.dumps(dict(choices=[dict(index=0,text='x',token_ids=[42],
                prompt_token_ids=payload['prompt'] if i==0 else None,
                finish_reason='length' if i==payload['max_tokens']-1 else None)],usage=None))
        yield json.dumps(dict(choices=[],usage=dict(prompt_tokens=len(payload['prompt']),
            completion_tokens=payload['max_tokens'],total_tokens=len(payload['prompt'])+payload['max_tokens'])))
        yield '[DONE]'

class Extension(unittest.TestCase):
    def test_plan_exact16_and_workload_identity(self):
        p=prepare();validate(p);self.assertEqual(len(p['blocks']),8)
        self.assertEqual(sum(len(b['episodes']) for b in p['blocks']),16)
        self.assertEqual(sum(b['episodes'][0]['condition']=='burst' for b in p['blocks']),4)
        old={b['repeat']:b for b in original_design.prepare()['blocks'] if b['budget']==512}
        for b in p['blocks']:
            self.assertEqual(b['budget'],768)
            for ep,ref in zip(b['episodes'],old[b['repeat']]['episodes']):
                for k in ['condition','repeat','order_in_block','prompts','seeds','prompt_seeds','prompt_hashes','outputs']:
                    self.assertEqual(ep[k],ref[k])
        changed=copy.deepcopy(p);changed['blocks'][0]['budget']=1024
        with self.assertRaises(ValueError):validate(changed)
    def test_only_budget_changes_in_command(self):
        self.assertEqual([(a,b) for a,b in zip(original_design.server_command(512),server_command(768)) if a!=b],[('512','768')])
        for b in [512,2048,1024]:
            with self.assertRaises(ValueError):server_command(b)
    def test_scheduler768_accounts_for_decode_and_remainder(self):
        chunks=[768,768,512]+[760]*10+[592]
        raw='\n'.join(f'Iteration({i}): 1 context requests, {n} context tokens, {0 if i<3 else 8} generation requests, {0 if i<3 else 8} generation tokens, iteration elapsed time: 1.00 ms' for i,n in enumerate(chunks))
        r=scheduler(raw,768,10240)
        self.assertEqual(r['additional_context_tokens'],8192)
        self.assertEqual(r['additional_max_context_tokens'],760)
        self.assertTrue(r['additional_budget_binding_observed'])
    def test_deadline_same_population_and_excess_definition(self):
        times=[0]
        for d in [25,50,100,130]+[1]*59:times.append(times[-1]+int(d*1e6))
        m=measures(dict(times=times),0)
        for d,n,e in [(25,3,205),(50,2,130),(100,1,30)]:
            self.assertEqual(m[f'count_above_{d}ms'],n);self.assertEqual(m[f'excess_above_{d}ms'],e)
        self.assertEqual(m['token64_ms'],m['token32_ms']+m['token32_to64_ms'])
        self.assertEqual(measures(dict(times=times),times[1]+1)['n_post_intervals'],62)
    def test_all16_synthetic_raw_episodes(self):
        async def run():
            base=load_executor()
            with tempfile.TemporaryDirectory(dir=ROOT) as d:
                for block in prepare()['blocks']:
                    for ep in block['episodes']:
                        path=Path(d)/(ep['episode_id']+'.jsonl');j=Journal(path)
                        e=dict(plan=ep,origin='synthetic',runtime={},requests={},trigger=None,errors=[],metrics_samples=[])
                        j.emit('episode_start',plan=ep,plan_sha256=sha(ep),origin='synthetic')
                        try:
                            await workload(base,Stream(),ep,j,e,'synthetic-key','http://127.0.0.1:8028')
                            a=assess(ep,e);self.assertTrue(a['measurement_valid'],a)
                            j.emit('episode_result',episode=e,assessment=a);await j.flush()
                        finally:j.close()
                        self.assertEqual(read_episode(path)[1],a)
        with patch.object(socket.socket,'connect',side_effect=AssertionError('network forbidden')):asyncio.run(run())

if __name__=='__main__':unittest.main()
