"""Exactly one prospective 768 arm derived from the frozen 512 workload plan."""
import copy,json,sys
from pathlib import Path
import original_design as old
from original_design import REPO,EXECUTOR,EXECUTOR_SHA,MODEL,MODEL_PATH,SETTINGS,require,sha,file_sha,load_executor

ROOT=Path(__file__).parent
BASELINE=ROOT.parent/'validation_no_semaphore_20261018'
PARENT_SHA='6bc0aab961058be3f402b11e71df4f42b3dbfc95b53aa02afaa566b59a5a05d0'
PYTHON=Path('/home/rock/projects/porto/.venv-py313-repair/bin/python')

def prepare():
    parent=old.validate(json.loads((BASELINE/'plan.json').read_text()))
    require(sha(parent)==PARENT_SHA,'parent plan differs')
    blocks=[]
    for b in parent['blocks']:
        if b['budget']!=512:continue
        new=copy.deepcopy(b);new['budget']=768;new['block_id']=b['block_id'].replace('b512','b768')
        for ep in new['episodes']:
            ep['budget']=768
            for field in ['block_id','episode_id']:ep[field]=ep[field].replace('b512','b768')
            ep['request_ids']={r:ep['episode_id']+':'+r for r in ep['request_ids']}
        blocks.append(new)
    plan=copy.deepcopy(parent)
    plan.update(schema='nordsec-validation-768-extension-v1',blocks=blocks,
        serving_episodes=16,completion_requests=160,input_tokens=98304,output_tokens=8704,
        parent_plan_sha256=PARENT_SHA,condition_order_source='exact 512-arm repeat ordering, chosen before768',
        extension_authorization_sha256=file_sha(ROOT/'USER_REQUEST.md'),
        python_environment=str(PYTHON.parent.parent),decode_targets_ms=[25,50,100],
        itl_filter='successive output tokens with right receipt strictly after own trigger, including crossing interval',
        aggregation='mean across fixed V0..V7 in each episode, paired burst-minus-no_burst block, equal weight of8 blocks',
        comparisons='768-512,768-2048,512-2048 paired by repeat;768 measured later, no randomized cross-session budget comparison')
    return plan

def validate(plan):
    require(plan==prepare(),'extension differs from fixed768 design or source files')
    return plan

def server_command(budget):
    require(budget==768,'only768 may be newly served')
    command=old.server_command(512)
    command[command.index('--max-num-batched-tokens')+1]='768'
    return command

if __name__=='__main__':
    plan=prepare()
    with (ROOT/'plan.json').open('x') as f:json.dump(plan,f,indent=2);f.write('\n')
    print(sha(plan))
