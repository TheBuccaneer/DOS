# Ausführbare Befehle und Freigabegrenze

Plan-SHA-256 (kanonisches JSON): `6bc0aab961058be3f402b11e71df4f42b3dbfc95b53aa02afaa566b59a5a05d0`.

## Bereits ausgeführte Offline-Prüfung

```bash
/home/rock/.local/bin/python3.13 -B /home/rock/.codex/.chatgpt-projects/g-p-6ac3aa45729881919c3a1edebe5c5965/revisions/validation_no_semaphore_20261018/runtime.py dry-run --plan /home/rock/.codex/.chatgpt-projects/g-p-6ac3aa45729881919c3a1edebe5c5965/revisions/validation_no_semaphore_20261018/plan.json
```

Dieser Befehl startet keinen Server und sendet keine Serving-Anfragen. Ausgabe: evidence/dry_run.json.

## Ausschließlich nach ausdrücklichem menschlichem GO

Der folgende Befehl wurde NICHT ausgeführt. Er startet die genau geplante Kampagne einschließlich16 Serverstarts und32 Episoden. Kein existierender Dienst wird übernommen oder beendet. Der Zielordner darf noch nicht existieren.

```bash
/home/rock/.local/bin/python3.13 -B /home/rock/.codex/.chatgpt-projects/g-p-6ac3aa45729881919c3a1edebe5c5965/revisions/validation_no_semaphore_20261018/runtime.py run --plan /home/rock/.codex/.chatgpt-projects/g-p-6ac3aa45729881919c3a1edebe5c5965/revisions/validation_no_semaphore_20261018/plan.json --approved-plan-sha 6bc0aab961058be3f402b11e71df4f42b3dbfc95b53aa02afaa566b59a5a05d0 --output-dir /home/rock/.codex/.chatgpt-projects/g-p-6ac3aa45729881919c3a1edebe5c5965/revisions/validation_no_semaphore_20261018/serving_campaign_20261018
```

Vor dem Start prüft der Runner die eingefrorenen Dateien sowie den Planhash. Der Lauf hält beim ersten technischen Fehler an; kein Resume oder Ersatzlauf. Server werden nur beendet, wenn sie von diesem Runner selbst gestartet wurden. Die zufälligen API-Schlüssel bleiben im Prozessspeicher und werden nicht in Dateien geschrieben.

## Nach einer vollständigen, gültigen Kampagne

Unabhängiges Rohjournal-Reaudit:

```bash
/home/rock/.local/bin/python3.13 -B /home/rock/.codex/.chatgpt-projects/g-p-6ac3aa45729881919c3a1edebe5c5965/revisions/validation_no_semaphore_20261018/runtime.py audit /home/rock/.codex/.chatgpt-projects/g-p-6ac3aa45729881919c3a1edebe5c5965/revisions/validation_no_semaphore_20261018/serving_campaign_20261018/validation-*/*.jsonl
```

Statistische Auswertung (Standardbibliothek, keine GPU):

```bash
python3 -B /home/rock/.codex/.chatgpt-projects/g-p-6ac3aa45729881919c3a1edebe5c5965/revisions/validation_no_semaphore_20261018/analyze_campaign.py --campaign /home/rock/.codex/.chatgpt-projects/g-p-6ac3aa45729881919c3a1edebe5c5965/revisions/validation_no_semaphore_20261018/serving_campaign_20261018 --out /home/rock/.codex/.chatgpt-projects/g-p-6ac3aa45729881919c3a1edebe5c5965/revisions/validation_no_semaphore_20261018/postrun_analysis_20261018
```

Die Auswertung verweigert eine vollständige Acht-Paar-Inferenz bei abgebrochener oder unvollständiger Kampagne. Der reale Budget-Manipulationsnachweis wird separat von den gemessenen Latenzen ausgewiesen. Geometrische relative Effekte stehen in relative_effects_pct.csv; der primäre Budgetkontrast bleibt in Millisekunden.

## Vorbereitungsprüfung reproduzieren

```bash
python3 -B /home/rock/.codex/.chatgpt-projects/g-p-6ac3aa45729881919c3a1edebe5c5965/revisions/validation_no_semaphore_20261018/preflight_offline.py
/home/rock/.local/bin/python3.13 -B -m unittest discover -s /home/rock/.codex/.chatgpt-projects/g-p-6ac3aa45729881919c3a1edebe5c5965/revisions/validation_no_semaphore_20261018 -p 'test_*.py' -v
```

Diese Prüfungen benötigen die genannten vorhandenen lokalen Quellen. Die GPU-Inventur in technical_inventory.json ist die dokumentierte passive Beobachtung vom18.10.2026 und wird vom Offline-Skript nicht neu durchgeführt. Synthetische Tests sind kein Serving-Nachweis.

## Finalen Code-Audit reproduzieren (ohne GPU)

Im Validierungsverzeichnis: `/home/rock/.local/bin/python3.13 -B -m unittest -v test_validation test_final_audit`.
Die vollständige Simulation ersetzt Prozessstarts, Netzwerk und GPU-Inventur durch Testobjekte; sie startet keinen Dienst. Ein zusätzlicher Test prüft die echte run_episode-Funktion mit künstlichen Konfigurations-, Metrik- und Logantworten.

Schreiblastmessung erneut ausführen: `/home/rock/.local/bin/python3.13 -B benchmark_journal.py --out final_code_audit/benchmark_rerun_01` (neues Zielverzeichnis erforderlich; ausschließlich lokale CPU-/Datei-I/O-Last). Vorherige Messergebnisse bleiben erhalten. Die Messung benötigt die historischen SSE-Nutzdaten für realistische Datensatzgrößen.

Aktuelle Freigabeentscheidung und verbleibende Bedingungen: FINALER_CODE_AUDIT.md. Das SHA-geprüfte Protokoll ist Revision 2. Der unveränderte Planhash allein beschreibt nicht die technische Implementierungsrevision; die Kampagne protokolliert zusätzlich Manifest- und Codehashes.
