#!/usr/bin/env python3
"""Source, model-cache and synthetic validator inspection; NO GPU imports."""
import ast,copy,csv,json,hashlib,types,re,subprocess,sys
from pathlib import Path
from design import REPO,MODEL_PATH,prepare,file_sha,sha,SETTINGS

ROOT=Path(__file__).parent
SITE=Path('/home/rock/projects/porto/.venv/lib/python3.13/site-packages')

def main():
    evidence=ROOT/'evidence';evidence.mkdir(exist_ok=True)
    scheduler_path=SITE/'vllm/config/scheduler.py';source=scheduler_path.read_text();tree=ast.parse(source)
    cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='SchedulerConfig')
    method=copy.deepcopy(next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='verify_max_model_len'))
    method.returns=None
    for arg in method.args.args:arg.annotation=None
    scope={'logger':types.SimpleNamespace(warning=lambda *x:None)}
    exec(compile(ast.fix_missing_locations(ast.Module(body=[method],type_ignores=[])),str(scheduler_path),'exec'),scope)
    results=[]
    for budget,chunked in [(512,True),(2048,True),(512,False)]:
        obj=types.SimpleNamespace(max_num_batched_tokens=budget,enable_chunked_prefill=chunked,max_num_seqs=16,
            max_num_partial_prefills=1,max_long_partial_prefills=1,long_prefill_token_threshold=0)
        try:scope['verify_max_model_len'](obj,8192);result='accepted'
        except ValueError as e:result='rejected: '+str(e)
        results.append(dict(budget=budget,chunked_prefill=chunked,result=result))
    config=json.loads((MODEL_PATH/'config.json').read_text());tok=json.loads((MODEL_PATH/'tokenizer.json').read_text())
    vocab=set(tok['model']['vocab'].values());special={t['id'] for t in tok['added_tokens'] if t.get('special')}
    plan=prepare();tokens={t for b in plan['blocks'] for e in b['episodes'] for prompt in e['prompts'].values() for t in prompt}
    assert tokens<=vocab and not tokens&special
    index=json.loads((MODEL_PATH/'model.safetensors.index.json').read_text());shards=sorted(set(index['weight_map'].values()))
    shard_info=[dict(path=str(MODEL_PATH/p),bytes=(MODEL_PATH/p).stat().st_size) for p in shards]
    bytes_per_token=2*config['num_hidden_layers']*config['num_key_value_heads']*(config['hidden_size']//config['num_attention_heads'])*2
    prior=[]
    for budget,path in [(512,REPO/'new/runs/prefill_shape_v1/diagnostic_b512_checked'),(2048,REPO/'new/runs/prefill_shape_v1/diagnostic_b2048_strict_20261017T204032')]:
        files=list(path.glob('*burst.jsonl'))
        if files:
            p=files[0];last=json.loads(p.read_text().splitlines()[-1]);prior.append(dict(path=str(p),sha256=file_sha(p),
                note='Stored prior four-victim/timer study; not a measurement of the new eight-victim trigger design',
                last_record_type=last.get('record_type'),assessment=last.get('assessment')))
    versions={}
    for name in ['vllm','torch','transformers','httpx']:
        p=next(SITE.glob(name+'-*.dist-info/METADATA'));versions[name]=re.search(r'^Version: (.+)$',p.read_text(),re.M)[1]
    record=dict(serving_started=False,gpu_libraries_imported=False,installed_versions_from_metadata=versions,
        scheduler_source=dict(path=str(scheduler_path),sha256=file_sha(scheduler_path)),source_method_checks=results,
        model_snapshot=str(MODEL_PATH),all_model_shards_present=shard_info,all_frozen_prompt_ids_valid_non_special=True,
        kv_bytes_per_token=bytes_per_token,fixed_pool_bytes=16384*bytes_per_token,
        worst_case_context_tokens=8*320+4*2064,usable_pool_tokens=(1024-1)*16,
        actual_new_budget_trajectories='pending approved serving run',prior_related_artifacts=prior,
        driver_inventory=dict(command='nvidia-smi --query-gpu=index,name,memory.total,memory.used,driver_version --format=csv,noheader',
            observed_date='2026-10-18',refreshed_by_this_offline_script=False,
            inspected_read_only_outside_sandbox=True,stdout='0, NVIDIA GeForce RTX 3090, 24576 MiB, 802 MiB, 580.178.04',
            note='Sandbox NVML access failed; successful read-only external inventory disproves a driver-failure conclusion'),
        runtime_issue='Historical venv executable resolves to Python 3.14; use existing portable Python 3.13.7 with explicit existing package path via runtime.py; no venv changes')
    (evidence/'technical_inventory.json').write_text(json.dumps(record,indent=2)+'\n')
    sources=[scheduler_path,SITE/'vllm/v1/core/sched/scheduler.py',SITE/'vllm/v1/core/kv_cache_utils.py',MODEL_PATH/'config.json',MODEL_PATH/'tokenizer.json',MODEL_PATH/'model.safetensors.index.json',
        REPO/'new/scripts/prefill_shape_v1/instrument.py',REPO/'new/scripts/prefill_shape_v1/audit.py',
        REPO/'new/scripts/prefill_confirmation/run_prefill_confirmation.py',REPO/'new/scripts/chunk_budget_screen/run_server.sh']
    sources += [Path(r['path']) for r in plan['historical_inputs']]
    project=ROOT.parents[1]
    sources += [project/'audits/nordsec_main_raw_sse_20261018/verified/summary.json',project/'revisions/trigger_progress_20261018/results/summary.json']
    with (evidence/'sources_sha256.csv').open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['path','size_bytes','sha256'])
        for p in sources:w.writerow([str(p),p.stat().st_size,file_sha(p)])
    print(json.dumps(dict(source_method_checks=results,valid_prompt_ids=True,kv_pool_gib=16384*bytes_per_token/2**30,weight_files_bytes=sum(s['bytes'] for s in shard_info)),indent=2))

if __name__=='__main__':main()
