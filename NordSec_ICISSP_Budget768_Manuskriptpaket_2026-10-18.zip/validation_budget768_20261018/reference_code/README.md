# NordSec-Validierung: Vorbereitung bis zum Freigabepunkt

**Start: FINALER_CODE_AUDIT.md. Entscheidung: GO unter Bedingungen; ausdrückliche menschliche Freigabe steht aus. Keine neuen GPU-Messepisoden wurden ausgeführt.**

- PROTOCOL.md: eingefrorenes wissenschaftliches Messprotokoll mit Stützungs-/Schwächungsregeln.
- COMMANDS.md: Dry-Run, späterer explizit freizugebender Kampagnenstart, Roh-Reaudit und Auswertung.
- plan.json: vollständige32-Episoden-Planung einschließlich aller Prompt-IDs, Seeds und Reihenfolgen.
- design.py / collect.py / runtime.py: neue Ausführung ohne Victim-Semaphore; vorhandene Runtime über separaten Python3.13-Wrapper.
- instrument.py: abgeleitete Instrumentierung mit gepuffertem Writer; ursprüngliche Fassung in final_code_audit/before/.
- wire_checks.py: abgeleitete historische Prüffunktionen mit zusätzlichen Raw-Integritätsprüfungen.
- verify.py: unabhängige Rekonstruktion/Gates aus dem Raw-Journal.
- analyze_campaign.py: vorbereitete Block-/Budgetauswertung, Prä-Kontrollen, Ausgabe-Sensitivitäten und reale Zusatzprefill-Wirkung.
- preflight_offline.py / test_validation.py: source-only Bestandsprüfung und künstliche Tests ohne Netzwerk/GPU.
- evidence/: tatsächlich erzeugte Offline-Belege, passive Geräteinventur und Quellenhashes.
- REUSE_PROVENANCE.json: Herkunft wiederverwendeter Komponenten.
- FROZEN_FILES_SHA256.json: eingefrorene Code-, Protokoll- und Planhashes; wird vor einem späteren Lauf geprüft.
- ARTIFACT_SHA256.csv: Prüfsummen der ausgelieferten Dateien.

Das Paket ist für die lokale Work-Umgebung vorbereitet. Zum tatsächlichen Lauf werden die bezeichneten read-only DOS-Quellen und der vorhandene Modellcache benötigt. Das ZIP enthält keine Modellgewichte, keine historischen Rohkampagnen und keine Zugangsschlüssel. Alle neuen Dateien liegen in diesem separaten Revisionsverzeichnis.

Das benannte zusätzliche GPU-Experiment beginnt erst nach dem ausdrücklichen menschlichen GO. Keine Arbeiten oder Änderungen in DOS2.

- test_final_audit.py: zusätzliche Grenzfall-, Fehler- und Kampagnentests.
- benchmark_journal.py und final_code_audit/benchmark/: reproduzierbare Offline-Schreiblastmessung.
- final_code_audit/: vorherige Fassungen, Änderungen, Tests und Auditbelege.

Die früheren 11-Test-Freigabedokumente sind historischer Vorbereitungsstand. Maßgeblich sind FINALER_CODE_AUDIT.md und PROTOCOL.md Revision 2.
