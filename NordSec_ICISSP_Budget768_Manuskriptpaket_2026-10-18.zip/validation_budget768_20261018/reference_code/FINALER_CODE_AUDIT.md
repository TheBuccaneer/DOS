# Finaler Code-Audit vor NordSec-Validierungsmessung

**18.10.2026 · Entscheidung: GO unter Bedingungen. Keine GPU-Messung und kein vLLM-Server gestartet.**

Geprüft wurde die lokale Vorbereitung in `revisions/validation_no_semaphore_20261018`, ausgehend vom tatsächlich vorhandenen Code und vom angehängten Arbeitsauftrag. Der frühere Freigabebericht wird durch diesen Bericht ersetzt. Die historische negative/nicht robuste Offload×Burst-Primäraussage bleibt unverändert. Es gibt weiterhin genau zwei gültige Reviews (−1/0), Frist 22.10.2026. Kein DOS2, keine neue Forschungsrichtung.

Der Audit ist eine erneute quellen- und testgestützte Prüfung durch denselben technischen Assistenten. Ein zweiter menschlicher oder externer unabhängiger Reviewer wird nicht behauptet. SSE-Rekonstruktion und Assertions greifen auf Rohaufzeichnungen zurück, nicht auf die frühere Ergebniszusammenfassung.

## 1. Code-Audit: tatsächlich überprüfte Komponenten

| Komponente | Tatsächliche Prüfung / Beleg | Aussagegrenze |
|---|---|---|
| `design.py`, `plan.json` | Alle 32 Episoden, 16 Paare, 8 Identitäten, Prompt-Hashes/Seeds, IDs, Reihenfolgen und alleiniger CLI-Budgetunterschied geprüft | Fester Plan und Offline-Test; keine neue Serving-Beobachtung |
| Historischer Einzelexecutor | Unveränderte SHA-geprüfte Implementierung gelesen; Callback-, Raw-, Cancel- und Terminalpfad mit künstlichen Streams ausgeführt | Alter Kampagnencontroller mit Semaphore wird nicht verwendet |
| `collect.py`: workload | Acht direkte Victim-Tasks, Trigger-Callback, Watcher, vier Burst-Tasks, Fehler/Cancel geprüft | Keine Client-Semaphore; der HTTPX-Pool und TCP/Server bleiben echte Laufkomponenten |
| `instrument.py` | Vollständiger Pfad HTTPX-Hook → SSE-data-Yield → Receipt-Timestamp → Queue → Executor/Callback → Writer/Barriere | Receipt bedeutet Client-Verarbeitung einer SSE-data-Zeile, keinen Socket-/GPU-Zeitpunkt |
| `verify.py`, `wire_checks.py` | Raw-Rekonstruktion, Original-/Journalkopien, IDs, Seeds, Payload, Tokenzeiten, Finish/Usage/DONE, Endpunkte und Invalidierung geprüft | Ungültige und physisch unvollständige Daten werden nicht vervollständigt |
| Episoden-/Kampagnensteuerung | Echte `run_episode` mit künstlichen Konfigurations-/Metrik-/Logantworten; volle Kampagnensteuerung mit 32 simulierten Episoden sowie Fehlerabbruch getestet | Prozessstart, GPU, Health-Service und Prozess-Warten in der Kampagnensimulation ersetzt |
| Scheduler/Konfiguration | Installierte vLLM-Quellen, reales altes Konfigurationsfixture, Budget-/Kontextparser und 512/2048-Validator geprüft | Neue tatsächliche Prefill-Trajektorien und neue Konfigurationsantworten stehen aus |
| `analyze_campaign.py` | Paar-/Budgetarithmetik, Logverhältnisse, Blockeinheit, Untergruppen und CI-Regel gelesen; Percentile-Bootstrap gegen unabhängige geordnete Resamples geprüft | Kein experimentelles Ergebnis aus Simulatorlatenzen; kein GPU-Budgeteffekt bewiesen |
| Laufzeit/Provenienz | Python-3.13-Wrapper, installierte Metadaten, Modellcache-/Tokenizerprüfung, eingefrorene Quellenhashes geprüft | Modellgewichte nicht vollständig neu gehasht; keine Bytegleichheit mit historischen Gewichten behauptet |

Die detaillierte Prüfmatrix steht in `final_code_audit/AUDIT_MATRIX.csv`. Quelle des HTTPX-Hooks: installierte `_client.py`, Hook vor `_send_single_request` und `transport.handle_async_request`. vLLM `engine/core.py` und `v1/utils.py` bestätigen Herkunft und Aggregation der Iterationslogs; sie liefern keine einzelnen serverseitigen Request-Admissions oder Kernelzeiten.

## 2. Fehleranalyse

### A. Nachgewiesener Fehler: zu weites Token-32-Fenster

Die bisherige Bedingung `16 <= empfangene Tokens < 64` ließ Token32 bereits zu. Auch der alte Reaudit verlangte nur Trigger < Token64 und ersten Burst-Hook < Token64. Damit konnte ein negativer oder bereits abgeschlossener primärer Token32-Zeitwert technisch als gültig durchgehen. Es gab noch keine echten Daten dieser neuen Kampagne, die dadurch nachträglich ausgewählt oder verworfen wurden.

**Jetzt vorab festgelegte Regeln:**

1. Trigger bleibt exakt `max(receipt[V0,16], …, receipt[V7,16])`; eigener Trigger in beiden Bedingungen.
2. Alle Token16-Schwellen müssen einzeln aufgelöst sein. Beim Beobachter müssen alle acht Zähler 16…31 sein. Zeitpunkt, Zähler und acht Schwellenzeiten werden gespeichert.
3. Am HTTPX-Hook jedes der vier Burst-Requests müssen alle acht Zähler weiterhin 16…31 sein. Ein geschlossener Hook wird dokumentiert und der betreffende Transportversuch mit Fehler beendet.
4. Der Raw-Reaudit verlangt Trigger < Token32 aller acht Victims; rekonstruierte Zähler am Beobachter müssen stimmen. Der letzte der vier Burst-Hooks muss ebenfalls strikt vor jedem Token32 liegen. Gleichheit ist ungültig.
5. Berichtete Fensterdiagnosen: Trigger→Beobachter, Trigger→erster/letzter Burst-Hook, Hook-Spanne, kleinste Trigger→Token32- und letzte-Hook→Token32-Lücke.
6. Invalidierung ergibt keinen primären Mittelwert. Die erste technisch ungültige Episode beendet die Kampagne ohne Ersatz/Resume; eine Teilkampagne erzeugt keine vollständige Acht-Paar-Inferenz.

Diese Regeln sind unabhängig vom Vorzeichen/CI des späteren Burst-Effekts. Die Hook→Token32-Regel ist eine festgelegte Machbarkeitsbedingung des Client-Messfensters; daraus folgt keine allgemeine Behandlung unabhängiger Selektion. Es werden insbesondere keine durchgefallenen Episoden still entfernt und durch günstigere ersetzt. Wenn der reale Ablauf das Fenster nicht zulässt, ist ein Bericht mit neuer Zustimmung erforderlich. **Eine Triggeränderung wurde weder benötigt noch vorgenommen.**

### B. Nachgewiesene Schreiblast; GPU-Verzerrung nicht nachgewiesen

Der bisherige Writer machte pro Datensatz `flush` und `fsync`. Das geschah bereits im Writer-Thread, also nicht als direkter Dateisystemaufruf im Streaming-Callback. Der Producer nutzt aber Queue-Locks; JSON-Serialisierung im anderen Python-Thread konkurriert um CPU/GIL. Eine volle Queue führt zu einem Fehler. Das sind reale mögliche Instrumentierungskosten, kein Beleg eines bereits aufgetretenen GPU-Bias.

Der neue Writer bündelt Durabilität nach 64 Datensätzen oder ungefähr 50 ms sowie an der FIFO-Abschlussbarriere. Queuegröße 4096, nicht wartender Producer, Reihenfolge und vor `emit` erfasste Receipts bleiben erhalten. Geprüfte Call-Sites mutieren bereits emittierte referenzierte Felder nicht: immutable Raw-Strings/Integer, kopierte Zählerlisten, abgeschlossene Requests, gestoppter Sampler und erst danach finaler Episodendatensatz. Gleichzeitige Producer-Threads werden nicht als unterstützter Modus behauptet.

Queue-Überlauf bleibt ein harter Fehler; schon angenommene Einträge werden nach Möglichkeit weiter geschrieben. Der überlaufende Eintrag selbst kann fehlen. Bei I/O-Ausfall oder Prozessabsturz ist vollständige Persistenz nicht garantierbar. Das Journal wird dann ausdrücklich nicht als vollständige Messung anerkannt; fehlende Ereignisse werden nicht erfunden. `flush()` bestätigt erst eine vom Writer abgearbeitete FIFO-Durabilitätsbarriere. `close()` erfolgt nach beendeten bzw. abgebrochenen Streams, nicht während aktiver Messung.

### C. Weitere gefundene Fehler/Risiken

- Task-Erstellung wurde innerhalb der bereits gestarteten Coroutine erfasst. Jetzt liegt dieser Beobachtungstimestamp unmittelbar vor `create_task`.
- Der Journalreader erwartete auch bei invaliden Teil-Episoden alle Burst-Payloads und einen Trigger. Jetzt kann er dokumentierte finale Fehler-Episoden erneut prüfen, ohne fehlende Requests zu erfinden; für gültige Episoden bleiben Vollständigkeit und Kopiengleichheit zwingend.
- Raw-Finish-/Usage-Kardinalität, totale Tokenbilanz, Event-Indizes und Terminal≥DONE werden zusätzlich geprüft. Einzelne Request-Result-Journalzeilen werden mit der finalen Kopie verglichen.
- Ein Fehler bei `transport.close()` konnte das Stoppen des eigenen Servers und die Kampagnenzusammenfassung überspringen. Diese Schritte laufen jetzt getrennt; Aufräumfehler werden gespeichert und stoppen die Kampagne. Ein Prozess, der trotz TERM/KILL nicht beendet werden kann, bleibt ein expliziter technischer Fehler.
- Die Kampagne erhält zusätzlich Manifesthash und tatsächliche Python-Dateihashes in ihrer Herkunftsdatei.

## 3. Korrekturen und Nachvollziehbarkeit

| Datei | Änderung |
|---|---|
| `collect.py` | Beobachter-/Hook-Gates, gespeicherte Zähler, Task-Erstellungszeit, ausführlichere Fehler, unabhängige Cleanup-Schritte, Codeherkunft |
| `instrument.py` | Gepufferter Journal-Worker mit FIFO-Synchronisierungsbarriere; Fake-Transport durch denselben Dispatch-Callback |
| `verify.py` | Raw-Token32-Grenzen, vier Hooks, Zeitabstände, Zählerrekonstruktion, Request-Kopien, diagnostische Relektüre finaler Fehler-Episoden; Assessment-Schema v2 |
| `wire_checks.py` | Raw-Finish, einmalige Usage, Gesamt-Tokenzahl, Indizes, Terminalreihenfolge |
| Neue Test-/Benchmarkdateien | `test_final_audit.py`, `benchmark_journal.py` |
| Protokoll/Dokumente | Explizites technisches Amendment v2, aktualisierte Herkunft, Befehle, dieser Bericht |

Vorherige Root-Dateien sind bytegetreu in `final_code_audit/before/` gesichert. `before_sha256.json`, `changes.patch`, aktuelle Manifest-/Artefakthashes dokumentieren die Änderungen. **`design.py`, `plan.json`, `test_validation.py` und `analyze_campaign.py` bleiben gegenüber dem Vorbereitungsstand bytegleich.** Historische Daten und Skripte außerhalb dieses Validierungsordners wurden nicht beschrieben.

## 4. Tests und quantitative Offline-Belastung

**29/29 Tests bestanden: alle unveränderten elf ursprünglichen Tests plus 18 neue Tests.** Vollständige Ausgabe: `final_code_audit/offline_tests.txt`.

Zusätzlich zu den ursprünglichen Prüfungen: gültiger Zähler31-Fall; Zähler32/63 und Token32 exakt am Trigger; vier Burst-Hooks inklusive später/exakt an der Endpunktgrenze; verspätete HTTP-Hooks im echten Executorpfad; Mehrtoken-Batch an Token16; fehlendes DONE mit erhaltenen Fehlerdaten; Raw-Tampering und fehlender Abschluss; Prompt-/Seed-/Hashgleichheit innerhalb und zwischen Budgets; Queue-Überlauf mit erhaltenen 4160 angenommenen Zeilen; injizierter fsync-Fehler; geordnete 1000 Zeilen mit Receipt-Erhalt; CI-Abgleich gegen alle geordneten Vierer-Resamples und 6435 Achtblock-Häufigkeitsvektoren; echter Episodenablauf mit künstlichen Serviceantworten; Kampagne mit 32 Episoden/16 simulierten Serverstarts; Abbruch an Episode5 ohne Ersatz; Client-Cleanup-Fehler mit trotzdem ausgeführtem Serverstop und Zusammenfassung.

Der komplette ursprüngliche 32-Episoden-Workloadtest und die zusätzliche Kampagnensimulation benutzen den echten unveränderten Einzelexecutor. Die Kampagnensimulation ersetzt `run_episode` durch eine synthetische Hülle; ein separater Test führt `run_episode` selbst mit künstlichen Antworten aus. Diese Kombination prüft keine echte vLLM-Inferenz.

**Umgebungsbefund:** Die eingeschränkte Offline-Umgebung verhinderte die explizite Socket-Erzeugung. Ein weiterer Simulationsversuch blieb im Prozesswarte-/Eventloop-Pfad hängen; die Diagnose zeigt einen wartenden Selector und einen untätigen Executor-Thread. Die genaue Ursache dieser Hängesituation wurde nicht abschließend isoliert. Ein kleiner separater Test mit expliziter Eventloop-Schließung konnte einen Thread-Return in0,774 ms verarbeiten; eine allgemeine Behauptung defekter Wakeup-Sockets wäre daher nicht belegt. Diagnose und erster fehlgeschlagener Testlauf sind erhalten. Im finalen Simulator sind Socket-Erzeugung und ausschließlich das Warten auf Fake-Prozesse ersetzt. Daraus wird weder ein Fehler des GPU-Treibers noch ein bestandener echter Server-Shutdown abgeleitet. Die GPU-Kampagne erfordert später eine freigegebene Umgebung mit lokalen Sockets/Prozess-/GPU-Zugriff.

### Journaling-Benchmark

36 lokale CPU/I/O-Proben: 2 Implementierungen × 2 Bedingungen × 3 Raten × 3 Wiederholungen. Tatsächliche historische SSE-Nutzdaten der ersten acht Victims und vier Bursts aus Repeat1 dienen als Größenfixture. Kontrolle: 528 SSE-data-Einträge; Burst: 600; jeweils ein großer finaler Ergebnisdatensatz zusätzlich. Acht Victim-Events werden je Kadenz freigegeben; Burst fügt vier Streams ab Token16 hinzu. 400 bezeichnet Victim-Tokenereignisse/s; Zusatzlast kommt hinzu. Das liegt nahe den aus diesem historischen Fixture vor Trigger gemessenen etwa384 Ereignissen/s (Median-ITL20,833 ms bei acht Streams). 2000/10000 sind Stressraten, keine behaupteten GPU-Durchsatzwerte.

Tabelle: jeweils alter → neuer Writer. P99-/Nachlaufwerte sind Mediane der drei einzelnen Laufkennzahlen, Queue-Werte Maxima. Keine Konfidenzintervalle oder Symmetriebehauptungen aus drei Wiederholungen.

| Victim-Events/s | Bedingung | fsync-Aufrufe | Emit-P99 µs | Zeitplanabweichung P99 ms | Nachlauf ms | Queue-Maximum |
|---|---|---|---|---|---|---|
| 400 | no_burst | 529 → 26 | 23.88 → 26.76 | 1.094 → 1.120 | 24.97 → 4.43 | 24 → 24 |
| 400 | burst | 601 → 25 | 13.91 → 13.53 | 1.081 → 1.078 | 29.49 → 6.98 | 24 → 24 |
| 2000 | no_burst | 529 → 9 | 10.24 → 15.86 | 1.090 → 1.086 | 240.53 → 5.45 | 263 → 24 |
| 2000 | burst | 601 → 10 | 8.83 → 12.88 | 1.075 → 1.071 | 302.56 → 7.38 | 327 → 24 |
| 10000 | no_burst | 529 → 9 | 9.24 → 10.21 | 1.089 → 1.083 | 432.98 → 5.50 | 471 → 24 |
| 10000 | burst | 601 → 10 | 6.80 → 10.51 | 1.062 → 1.087 | 506.40 → 7.49 | 550 → 32 |

**Interpretation:** Die Schreibfrequenz und der Rückstau gehen deutlich zurück. Bei400 Ereignissen/s sinken die Synchronisierungen von529/601 auf26/25; der Nachlauf von24,97/29,49 auf4,43/6,98 ms. Die neue Emit-P99 liegt über alle Konfigurationen bei etwa10,21…26,76 µs; sie verbessert sich nicht durchgängig gegenüber vorher. Die P99-Zeitplanabweichung bleibt ungefähr1,06…1,12 ms. Beim neuen Writer beträgt Burst minus Kontrolle dort −0,042/−0,015/+0,005 ms für400/2000/10000; daraus lässt sich keine reale Inferenzsymmetrie folgern. Bei10000 sinkt das Queue-Maximum von471/550 auf24/32. Alle36 Proben bestanden Zeilenanzahl-, Reihenfolge-, Raw-Inhalts- und Receipt-Prüfung, ohne Queue-Überlauf.

Die Proben enthalten lokale Producer-/Writer-Konkurrenz und Datensatzgrößen, aber keine GPU, TCP-SSE-Übertragung, vLLM-Iterationsloglast oder echte Servermetriken. Zeitplanabweichung ist kein Messfehler-Bound für Tokenzeiten. Große finale Datensätze werden wie im Messcode erst nach Streaming erzeugt. Temporäre Benchmarkjournale werden nach erfolgreicher Integritätsprüfung entfernt; tabellarische Einzelergebnisse und Quellenhash bleiben erhalten. Reproduzierbare Befehle stehen in COMMANDS.md.

## 5. Offene Punkte und verbleibende kritische Bedingungen

1. **Reales Token32-Fenster:** Ob alle acht Victims und alle vier Hooks in allen32 Episoden die festen Grenzen einhalten, ist live offen. Keine Garantie durch Offline-Tests; bei Verletzung Stop-and-Report, keine Triggerkorrektur ohne Zustimmung.
2. **Realer Scheduler/KV/Metriknachweis:** Zwei CLI-Budgets sind kein Wirksamkeitsbeleg. Erst vollständige Server-Snapshots, KV-Zähler, Null-Preemption, Kontextbilanz und tatsächliche Zusatzprefill-Trajektorien können den Vergleich bestätigen. Ein fehlender Budgetkontrast in den Logs bleibt ein fehlender Manipulationsnachweis.
3. **Instrumentierung im GPU-Betrieb:** Gemeinsamer CPU/GIL, HTTPX-/TCP-Pufferung, Metriklast und vLLM-Iterationslogging können Effekte beeinflussen; gleiche Einstellungen beweisen keine gleiche Last in beiden Bedingungen/Budgets. Der neue Writer beseitigt den per-record-fsync, nicht jeden Overhead. Keine unbeobachteten Serverursachen behaupten.
4. **Laufzeit/Umgebung:** Modellladen, Compile-/First-Condition-Effekte, aktueller Treiber, echte HTTP-Fehler/Timeouts und Prozesscleanup sind nicht live validiert. Die aktuelle Sandbox gestattet den echten Start nicht; die spätere freigegebene Ausführung muss lokale Sockets und GPU erlauben.

**Kein verbleibender durch Offline-Belege nachgewiesener kritischer Codefehler ist bekannt.** Die vier genannten Punkte bleiben kritische Bedingungen für die Verwertbarkeit echter Daten, keine vorweggenommenen erfolgreichen Tests. Ein statischer Audit ist kein Vollständigkeitsbeweis gegen unbekannte Softwarefehler.

## 6. Reproduzierbarkeit

Unveränderter kanonischer Plan-SHA-256:
`6bc0aab961058be3f402b11e71df4f42b3dbfc95b53aa02afaa566b59a5a05d0`.

32 Episoden, 16 Paare, Budget512/2048, je8 Paare; identische historische Victim-Prompts und Seeds; gespeicherte aus Masterseed20261018 abgeleitete Reihenfolge; pro Budget4×Burst zuerst; gegenläufige Budget-/Bedingungsreihenfolge. Keine Client-Semaphore, maximal12 Completion-Streams plus Metrikabruf im Pool16. Modell-/Serverparameter, Snapshots, Datensatzmengen, Timeouts, Abbruchregeln und Block-CI sind in PROTOCOL.md und plan.json festgelegt. Keine neuen Messparameter oder Zellen.

`final_code_audit/source_integrity.json` bestätigt acht vor Audit eingefrorene historische Episodenhashes und drei vor Audit eingefrorene historische Skripthashes. Zusätzlich sind verwendete Modell-/Softwarequellen inventarisiert. Dies ist keine Behauptung eines vollständigen Vorher/Nachher-Hashes des gesamten DOS-Dateisystems. Der unveränderte historische Executor hat SHA256 `981aba99aff820ea8fea3bef6df0e1e8bfb127df059695d4736d7702ef300b75`. Aufrufe schreiben keine Bytecode-Dateien in historische Verzeichnisse. Aktuelle Codes/Protokolle sind vor dem Lauf erneut über FROZEN_FILES_SHA256.json zu prüfen; der frühere Freeze bleibt archiviert. Das ZIP enthält keine Modellgewichte, historischen Rohkampagnen oder Zugangsschlüssel und benötigt für eine Wiederholung die bezeichneten lokalen Quellen.

## 7. Freigabeentscheidung und wissenschaftliche Aussage

**GO unter Bedingungen für einen später ausdrücklich freizugebenden Lauf dieses geprüften Pakets.** Die Bedingungen sind die unveränderten festen Gültigkeits-/Abbruchregeln, die echte Konfigurations- und Schedulerprüfung und eine ausführbare lokale GPU-Umgebung. Der bisherige Vorbereitungsstand sollte nicht mehr verwendet werden.

Die Codeprüfung und Offline-Tests stützen jetzt: Der vorbereitete Client kann Token32 nur dann als gültigen primären Endpunkt aufnehmen, wenn das definierte Client-Messfenster die Trigger-/Hook-Grenzen besteht; er bewahrt deren Rohgrundlage und prüft Paarungen auf Blockebene. Die gepufferte Journalverarbeitung reduziert nachweislich lokale Schreiblast. **Weder ein positiver Token32-Burst-Effekt noch ein Budgetvorteil noch eine unbeeinflusste GPU-Messung wurden dadurch nachgewiesen.**

Die Zusatzvalidierung bleibt eine nach Kenntnis der historischen Daten festgelegte Ergänzung. Der ursprünglich negative Primärbefund wird weder ersetzt noch umgedeutet. **Stop-and-Report ist erreicht: kein Serverstart und keine der32 GPU-Messepisoden ohne ausdrückliches menschliches GO.**
