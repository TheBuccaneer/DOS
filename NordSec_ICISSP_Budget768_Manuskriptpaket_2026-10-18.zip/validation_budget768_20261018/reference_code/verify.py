"""Raw journal reconstruction and bounded technical/scheduler checks."""
import hashlib,json,re,statistics
from pathlib import Path
from design import MODEL,SETTINGS,require,sha
from wire_checks import metric,token_stream

ITERATION=re.compile(r'Iteration\((\d+)\): (\d+) context requests, (\d+) context tokens, (\d+) generation requests, (\d+) generation tokens, iteration elapsed time: ([0-9.]+) ms')

def configuration(sample,budget):
    require(sample['http_status']==200 and sample['error'] is None,'configuration unavailable')
    config=sample['body']['vllm_config']
    groups=dict(
        scheduler_config=dict(max_num_batched_tokens=budget,max_num_scheduled_tokens=None,
            max_num_seqs=16,enable_chunked_prefill=True,max_num_partial_prefills=1,
            max_long_partial_prefills=1,long_prefill_token_threshold=0,policy='fcfs',
            async_scheduling=True,stream_interval=1,scheduler_cls=None),
        cache_config=dict(block_size=16,num_gpu_blocks_override=1024,cpu_offload_gb=0,
            enable_prefix_caching=False,gpu_memory_utilization=.9,cache_dtype='auto'),
        model_config=dict(dtype='torch.bfloat16',max_model_len=8192,seed=20260711,
            quantization=None,enforce_eager=False,generation_config='vllm',served_model_name=MODEL),
        parallel_config=dict(tensor_parallel_size=1,pipeline_parallel_size=1,data_parallel_size=1),
        device_config=dict(device='cuda'),
        observability_config=dict(enable_logging_iteration_details=True))
    for group,expected in groups.items():
        for key,value in expected.items():require(key in config[group] and config[group][key]==value,f'configuration mismatch {group}.{key}')
    for key in ['speculative_config','lora_config','kv_transfer_config','kv_events_config']:
        require(key in config and config[key] is None,'unsupported configuration '+key)
    require(config['offload_config']['uva']['cpu_offload_gb']==0 and config['offload_config']['prefetch']['offload_group_size']==0,'offload path enabled')
    return config

def state(sample):
    require(sample['http_status']==200 and sample['error'] is None,'metrics failed')
    raw=sample['raw_body']
    labels=re.findall(r'^vllm:cache_config_info\{([^\n]+)\}\s+1(?:\.0)?$',raw,re.M)
    require(len(labels)==1,'unique cache metrics required')
    actual=dict(re.findall(r'(\w+)="([^"\\]*)"',labels[0]))
    for k,v in [('num_gpu_blocks','1024'),('num_gpu_blocks_override','1024'),('block_size','16'),('enable_prefix_caching','False')]:
        require(actual.get(k)==v,'live KV configuration differs '+k)
    counters={key:metric(raw,'vllm:'+name) for key,name in dict(requests='request_success_total',prompt='prompt_tokens_total',
        generation='generation_tokens_total',context='request_prefill_kv_computed_tokens_sum',preemptions='num_preemptions_total').items()}
    return dict(counters=counters,running=metric(raw,'vllm:num_requests_running'),waiting=metric(raw,'vllm:num_requests_waiting'),process_start=metric(raw,'process_start_time_seconds'))

def scheduler(raw,budget,context_expected):
    records=[]
    for line in raw.splitlines():
        if 'Iteration(' not in line:continue
        match=ITERATION.search(line);require(match is not None,'malformed iteration log')
        records.append(tuple(map(int,match.groups()[:5])))
    require(bool(records),'no scheduler iteration evidence')
    require(all(b[0]==a[0]+1 for a,b in zip(records,records[1:])),'iteration log gap')
    require(sum(r[2] for r in records)==context_expected,'context-token accounting mismatch')
    require(max(r[2]+r[4] for r in records)<=budget,'scheduled tokens exceed budget')
    additional=[]
    if context_expected==10240:
        cumulative=0;boundary=False
        for r in records:
            if boundary:additional.append(r)
            cumulative+=r[2]
            if cumulative==2048:boundary=True
            require(boundary or cumulative<2048,'initial victim-context boundary not reconstructable')
        require(boundary and sum(r[2] for r in additional)==8192,'additional-prefill context accounting mismatch')
    return dict(iterations=len(records),context_iterations=sum(r[2]>0 for r in records),
        max_context_tokens=max(r[2] for r in records),max_total_scheduled_tokens=max(r[2]+r[4] for r in records),
        mixed_prefill_decode_iterations=sum(r[1]>0 and r[3]>0 for r in records),
        context_token_trajectory=[r[2] for r in records if r[2]],
        budget_binding_observed=any(r[2]+r[4]>=budget-8 for r in records),
        additional_context_tokens=sum(r[2] for r in additional),
        additional_max_context_tokens=max((r[2] for r in additional),default=0),
        additional_budget_binding_observed=any(r[2]+r[4]>=budget-8 and r[2]>0 for r in additional),
        additional_prefill_decode_overlap_iterations=sum(r[1]>0 and r[3]>0 for r in additional),
        request_attribution='aggregate_only',gpu_time_attributed=False)

def assess(plan,episode):
    issues=[];streams={};endpoints={};window={}
    try:
        require(not episode['errors'],'episode execution errors')
        require(set(episode['requests'])==set(plan['prompts']),'missing/additional request')
        trigger=episode['trigger']['trigger_ns'];cross=[]
        observed=episode['trigger']['observed_ns']
        require(trigger<=observed,'trigger observation predates token16 receipts')
        require(all(16<=n<32 for n in episode['trigger']['token_counts_at_observation']),
                'token32 window closed at trigger observation')
        require(episode['trigger']['single_token_thresholds']==[True]*8,'unresolved token16 threshold')
        for role in plan['prompts']:
            record=episode['requests'][role]
            require(record['request_id']==plan['request_ids'][role],'request ID mismatch')
            require(record['request_index']==int(role[1:]),'request index mismatch')
            require(record['generation_seed']==plan['seeds'][role] and record['prompt_seed']==plan['prompt_seeds'][role],'request seed mismatch')
            payload=dict(model=MODEL,prompt=plan['prompts'][role],max_tokens=plan['outputs'][role],min_tokens=plan['outputs'][role],
                ignore_eos=True,temperature=0,stream=True,stream_options=dict(include_usage=True),add_special_tokens=False,
                return_token_ids=True,seed=plan['seeds'][role])
            require(record['wire_payload']==payload,'wire payload differs from frozen plan')
            stream=token_stream(record,plan['prompts'][role],plan['outputs'][role]);streams[role]=stream
            require(all(x==1 for x in stream['batch_sizes']),'individually resolved token receipts required')
            if episode['origin']=='serving':require(record['dispatch_semantics']=='httpx_request_hook','missing HTTP hook')
            require(record['task_created_ns']>=episode['victim_start_ns'],'task predates phase')
            if role.startswith('V'):
                cross.append(stream['times'][15]);require(record['send_ns']<stream['times'][0]<=trigger<stream['times'][31],'victim token32 window closed at logical trigger')
                endpoints[role]=dict(token32_ms=(stream['times'][31]-trigger)/1e6,
                    token64_ms=(stream['times'][63]-trigger)/1e6,max_itl_ms=max((b-a)/1e6 for a,b in zip(stream['times'],stream['times'][1:])),
                    max_post_trigger_itl_ms=max((b-a)/1e6 for a,b in zip(stream['times'],stream['times'][1:]) if b>trigger),
                    completion_from_phase_ms=(stream['times'][63]-episode['victim_start_ns'])/1e6,
                    completion_from_http_hook_ms=(stream['times'][63]-record['send_ns'])/1e6,
                    terminal_from_phase_ms=(record['request_terminal_ns']-episode['victim_start_ns'])/1e6,
                    pre8_cadence_ms=(stream['times'][15]-stream['times'][7])/8e6,
                    age16_ms=(trigger-stream['times'][15])/1e6)
            else:require(record['send_ns']>trigger,'intervention before trigger')
        require(len(cross)==8 and max(cross)==trigger and cross==episode['trigger']['crossings'],'trigger differs from last token-16 receipt')
        reconstructed_counts=[sum(t<=observed for t in streams[f'V{i}']['times']) for i in range(8)]
        require(reconstructed_counts==episode['trigger']['token_counts_at_observation'],'trigger observation count/raw mismatch')
        window=dict(trigger_to_observer_ms=(observed-trigger)/1e6,
            min_trigger_to_token32_ms=min((streams[f'V{i}']['times'][31]-trigger)/1e6 for i in range(8)),
            burst_http_hook_semantics='client request hook before transport; no server admission/prefill timestamp')
        if plan['condition']=='burst':
            sends=[episode['requests'][f'E{i}']['send_ns'] for i in range(4)]
            first,last=min(sends),max(sends)
            window.update(trigger_to_first_burst_http_hook_ms=(first-trigger)/1e6,
                trigger_to_last_burst_http_hook_ms=(last-trigger)/1e6,
                burst_http_hook_span_ms=(last-first)/1e6,
                min_last_burst_hook_to_token32_ms=min((streams[f'V{i}']['times'][31]-last)/1e6 for i in range(8)))
            require(observed<=first and all(last<streams[f'V{i}']['times'][31] for i in range(8)),
                'token32 window closed before all four burst HTTP hooks')
        if episode['origin']=='serving':
            before=configuration(episode['config_before'],plan['budget']);after=configuration(episode['config_after'],plan['budget'])
            require(before==after,'server configuration changed during episode')
            require(episode['config_before']['response_ns']<episode['victim_start_ns'] and
                    episode['config_after']['scrape_start_ns']>max(r['request_terminal_ns'] for r in episode['requests'].values()),'configuration boundary times invalid')
            samples=episode['metrics_samples'];states=[state(s) for s in samples]
            require(len(samples)>=2,'missing metrics')
            require(states[0]['running']==states[0]['waiting']==states[-1]['running']==states[-1]['waiting']==0,'nonidle metric boundary')
            require(samples[0]['response_ns']<episode['victim_start_ns'],'metrics started late')
            require(samples[-1]['scrape_start_ns']>max(r['request_terminal_ns'] for r in episode['requests'].values()),'metrics ended early')
            require(all(0<=(b['scrape_start_ns']-a['scrape_start_ns'])/1e6<=250 for a,b in zip(samples,samples[1:])),'metrics coverage gap')
            require(all(abs(s['process_start']-episode['runtime']['process_start'])<2 for s in states),'metrics/server process binding mismatch')
            expected=dict(requests=len(plan['prompts']),prompt=sum(map(len,plan['prompts'].values())),generation=sum(plan['outputs'].values()),
                context=sum(map(len,plan['prompts'].values())),preemptions=0)
            for key,value in expected.items():
                require(all(b['counters'][key]>=a['counters'][key] for a,b in zip(states,states[1:])),'metric reset '+key)
                require(states[-1]['counters'][key]-states[0]['counters'][key]==value,'unexpected load/counter delta '+key)
            sched=scheduler(episode['iteration_log'],plan['budget'],expected['context'])
        else:sched={'synthetic':True,'actual_budget_wirkung_verified':False}
    except (KeyError,TypeError,ValueError,IndexError) as exc:
        issues.append(str(exc));sched={}
    valid=not issues
    return dict(schema='nordsec-validation-assessment-v2',origin=episode['origin'],measurement_valid=valid,issues=issues,
        primary_token32_ms=statistics.fmean(v['token32_ms'] for v in endpoints.values()) if valid and len(endpoints)==8 else None,
        victim_endpoints=endpoints,measurement_window=window,scheduler=sched,scientific_claim_established=False)

def read_episode(path):
    rows=[json.loads(line) for line in Path(path).read_text().splitlines()]
    require([r['journal_seq'] for r in rows]==list(range(len(rows))),'journal sequence gap')
    require(rows[-1]['record_type']=='episode_result','incomplete journal')
    episode=rows[-1]['episode'];plan=rows[0]['plan']
    require(rows[0]['record_type']=='episode_start' and sha(plan)==rows[0]['plan_sha256'],'journal plan mismatch')
    require(episode['plan']==plan,'final plan copy differs')
    valid=rows[-1]['assessment']['measurement_valid']
    require(all(r.get('role') in plan['prompts'] for r in rows if 'role' in r),'unknown journal role')
    for role in plan['prompts']:
        raw=[r for r in rows if r['record_type']=='sse_wire' and r['role']==role]
        stored=episode['requests'].get(role,{})
        results=[r for r in rows if r['record_type']=='request_result' and r['role']==role]
        require([r['record'] for r in results]==([stored] if stored else []),'request result journal copy mismatch')
        require(len(raw)==len(stored.get('raw_sse_events',[])),'wire/result event count mismatch')
        for i,(wire,event) in enumerate(zip(raw,stored.get('raw_sse_events',[]))):
            require(wire['event_index']==event['event_index']==i and wire['raw_data']==event['raw_data'] and
                    wire['receive_ns']==event['receive_perf_counter_ns'] and wire['request_id']==plan['request_ids'][role] and
                    wire['send_ns']==stored['send_ns'],'raw wire/result mismatch')
        sends=[r for r in rows if r['record_type']=='http_dispatch' and r['role']==role]
        if episode['origin']=='serving':
            require(len(sends)<=1 and (not sends or sends[0]['send_ns']==stored.get('send_ns')),'dispatch journal mismatch')
            if valid:require(len(sends)==1,'missing dispatch journal')
        wires=[r for r in rows if r['record_type']=='request_wire' and r['role']==role]
        require(len(wires)<=1 and (not wires or wires[0]['payload']==stored.get('wire_payload')),'request payload journal mismatch')
        if valid:require(len(wires)==1,'missing request payload journal')
    require([r['sample'] for r in rows if r['record_type']=='metrics_sample']==episode['metrics_samples'],'metrics journal copy mismatch')
    require([r['trigger'] for r in rows if r['record_type']=='progress_trigger']==([episode['trigger']] if episode['trigger'] is not None else []),'trigger journal copy mismatch')
    if episode['origin']=='serving':
        for phase in ['before','after']:
            require([r['sample'] for r in rows if r['record_type']=='configuration_snapshot' and r['phase']==phase]==[episode['config_'+phase]],'configuration journal copy mismatch')
        logs=[r for r in rows if r['record_type']=='iteration_log']
        require(len(logs)<=1 and (not logs or (logs[0]['raw_text']==episode['iteration_log'] and
                logs[0]['byte_end']-logs[0]['byte_start']==len(episode['iteration_log'].encode()))),'iteration log copy mismatch')
        if valid:require(len(logs)==1,'missing iteration log')
    result=assess(plan,episode)
    require(result==rows[-1]['assessment'],'independent reassessment mismatch')
    return episode,result
