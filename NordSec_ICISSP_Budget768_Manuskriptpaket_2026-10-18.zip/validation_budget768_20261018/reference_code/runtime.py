#!/usr/bin/env python3
"""Explicit Python 3.13 + existing package directory, without changing any venv."""
import os,sys,runpy
from pathlib import Path
PACKAGE_PATH='/home/rock/projects/porto/.venv/lib/python3.13/site-packages'
if sys.version_info[:2]!=(3,13):raise SystemExit('Use /home/rock/.local/bin/python3.13')
sys.dont_write_bytecode=True
sys.path.insert(0,PACKAGE_PATH)
os.environ['PYTHONPATH']=PACKAGE_PATH
os.environ['PYTHONDONTWRITEBYTECODE']='1'
if len(sys.argv)>1 and sys.argv[1]=='--metadata-only':
    import importlib.metadata,json
    print(json.dumps(dict(python=sys.version,package_path=PACKAGE_PATH,
        packages={n:importlib.metadata.version(n) for n in ['vllm','httpx','torch','transformers']}),indent=2))
else:
    script=Path(__file__).parent/'collect.py';sys.argv=[str(script)]+sys.argv[1:]
    runpy.run_path(str(script),run_name='__main__')
