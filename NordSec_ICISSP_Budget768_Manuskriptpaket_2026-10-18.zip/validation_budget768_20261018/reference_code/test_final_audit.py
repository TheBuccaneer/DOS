"""Boundary, failure and orchestration checks. Network and GPU are not used."""
import asyncio,copy,hashlib,json,os,socket,tempfile,time,unittest
from pathlib import Path
from unittest.mock import patch
from test_validation import FakeTransport
from design import prepare,sha,load_executor
from collect import workload,DispatchTap,campaign
from instrument import Journal,ReceiptClock
from verify import assess,read_episode

ROOT=Path(__file__).parent

class FastVictim(FakeTransport):
    def __init__(self,n):super().__init__();self.n=n
    async def stream_completion(self,url,headers,payload,timeout_s,*,request_id):
        role=request_id.split(':')[-1]
        # V0 runs ahead before the other victims cross 16; then yields normally.
        if role=='V0':
            stream=super().stream_completion(url,headers,payload,timeout_s,request_id=request_id)
            original=asyncio.sleep
            async def skip(delay):return None
            try:
                for _ in range(self.n):
                    with patch('asyncio.sleep',skip):raw=await anext(stream)
                    yield raw
                async for raw in stream:yield raw
            finally:await stream.aclose()
        else:
            async for raw in super().stream_completion(url,headers,payload,timeout_s,request_id=request_id):yield raw

class FinalAudit(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.plan=prepare();cls.base=load_executor()
        cls.burst=next(e for b in cls.plan['blocks'] for e in b['episodes'] if e['condition']=='burst')

    async def make_episode(self,path,ep=None,transport=None,expect_failure=False):
        ep=ep or self.burst;transport=transport or FakeTransport()
        e=dict(plan=ep,origin='synthetic',runtime={},requests={},trigger=None,errors=[],metrics_samples=[])
        j=Journal(path);j.emit('episode_start',plan=ep,plan_sha256=sha(ep),origin='synthetic')
        try:
            try:await workload(self.base,transport,ep,j,e,'offline-key','http://127.0.0.1:8028')
            except Exception as exc:
                if not expect_failure:raise
                e['errors'].append(dict(type=type(exc).__name__,detail=str(exc)))
            result=assess(ep,e)
            j.emit('episode_result',episode=e,assessment=result);await j.flush()
        finally:j.close()
        return e,result

    def test_token32_at_logical_trigger_rejected(self):
        async def run():
            with tempfile.TemporaryDirectory(dir=ROOT) as d:
                e,a=await self.make_episode(Path(d)/'e.jsonl')
                self.assertTrue(a['measurement_valid'])
                bad=copy.deepcopy(e)
                # Alter the non-last victim receipt to equal the existing trigger.
                trigger=bad['trigger']['trigger_ns'];r=bad['requests']['V0']
                for event in r['raw_sse_events']:
                    if 16<=event['event_index']<=31:event['receive_perf_counter_ns']=trigger
                b=assess(self.burst,bad)
                self.assertFalse(b['measurement_valid']);self.assertIsNone(b['primary_token32_ms'])
                self.assertIn('logical trigger',b['issues'][0])
        asyncio.run(run())

    def test_fixed_trigger_observation_boundaries_31_32_63(self):
        # Directly test the observation gate without relying on coroutine speeds.
        async def run(n):
            with tempfile.TemporaryDirectory(dir=ROOT) as d:
                e,a=await self.make_episode(Path(d)/'e.jsonl')
                e['trigger']['token_counts_at_observation'][0]=n
                b=assess(self.burst,e)
                self.assertFalse(b['measurement_valid'])
                if n>=32:self.assertIn('observation',b['issues'][0])
                else:self.assertIn('count/raw mismatch',b['issues'][0])
        for n in [31,32,63]:asyncio.run(run(n))

    def test_fast_victim_32_and_63_preserved_invalid_without_burst(self):
        async def run(n):
            with tempfile.TemporaryDirectory(dir=ROOT) as d:
                path=Path(d)/'e.jsonl';t=FastVictim(n)
                e,a=await self.make_episode(path,transport=t,expect_failure=True)
                self.assertFalse(t.burst_seen);self.assertEqual(t.active,0)
                self.assertFalse(a['measurement_valid']);self.assertIsNone(a['primary_token32_ms'])
                self.assertIsNotNone(e['trigger']);self.assertTrue(e['errors'])
                self.assertEqual(read_episode(path)[1],a)
                self.assertTrue(any(r['raw_sse_events'] for r in e['requests'].values()))
        for n in [32,63]:asyncio.run(run(n))

    def test_31_tokens_at_observation_is_valid_when_all_hooks_precede_32(self):
        async def run():
            with tempfile.TemporaryDirectory(dir=ROOT) as d:
                e,a=await self.make_episode(Path(d)/'e.jsonl')
                e['victim_start_ns']=0
                e['trigger']=dict(trigger_ns=1600,observed_ns=3100,crossings=[1600]*8,
                    token_counts_at_observation=[31]*8,single_token_thresholds=[True]*8)
                for role,r in e['requests'].items():
                    r['task_created_ns']=0;r['scheduled_dispatch_ns']=0
                    r['send_ns']=1 if role.startswith('V') else 3151+int(role[1:])
                    for i,event in enumerate(r['raw_sse_events']):
                        event['receive_perf_counter_ns']=(i+1)*100+(0 if role.startswith('V') else 7000)
                    r['request_terminal_ns']=r['raw_sse_events'][-1]['receive_perf_counter_ns']+1
                b=assess(self.burst,e)
                self.assertTrue(b['measurement_valid'],b);self.assertGreater(b['primary_token32_ms'],0)
        asyncio.run(run())

    def test_all_burst_hooks_must_precede_every_token32(self):
        async def run():
            with tempfile.TemporaryDirectory(dir=ROOT) as d:
                e,a=await self.make_episode(Path(d)/'e.jsonl');self.assertTrue(a['measurement_valid'])
                self.assertGreater(a['measurement_window']['min_last_burst_hook_to_token32_ms'],0)
                for offset in [0,1]:
                    b=copy.deepcopy(e)
                    b['requests']['E3']['send_ns']=b['requests']['V0']['raw_sse_events'][31]['receive_perf_counter_ns']+offset
                    aa=assess(self.burst,b);self.assertFalse(aa['measurement_valid']);self.assertIsNone(aa['primary_token32_ms'])
        asyncio.run(run())

    def test_http_hook_guard_records_late_window_and_executor_error(self):
        # Delay fake transport's dispatch callback until victims reach 32.
        class Late(FakeTransport):
            def __init__(self):super().__init__();self.send_hooks={}
            async def stream_completion(self,url,headers,payload,timeout_s,*,request_id):
                if request_id.split(':')[-1].startswith('E'):
                    while any(self.counts.get(f'V{i}',0)<32 for i in range(8)):await asyncio.sleep(0)
                self.send_hooks[request_id](time.perf_counter_ns())
                async for raw in super().stream_completion(url,headers,payload,timeout_s,request_id=request_id):yield raw
        async def run():
            with tempfile.TemporaryDirectory(dir=ROOT) as d:
                path=Path(d)/'late.jsonl';t=Late();e,a=await self.make_episode(path,transport=t)
                self.assertFalse(a['measurement_valid']);self.assertFalse(t.burst_seen)
                self.assertEqual(read_episode(path)[1],a)
                self.assertTrue(all(e['requests'][f'E{i}']['error_type']=='ValueError' for i in range(4)))
                windows=[json.loads(l) for l in path.read_text().splitlines() if json.loads(l)['record_type']=='intervention_window']
                self.assertEqual(len(windows),4)
                self.assertTrue(all(max(w['victim_token_counts'])>=32 for w in windows))
        asyncio.run(run())

    def test_raw_tampering_and_incomplete_journal_rejected(self):
        async def run():
            with tempfile.TemporaryDirectory(dir=ROOT) as d:
                path=Path(d)/'good.jsonl';e,a=await self.make_episode(path)
                rows=path.read_text().splitlines()
                incomplete=Path(d)/'partial.jsonl';incomplete.write_text('\n'.join(rows[:-1])+'\n')
                with self.assertRaisesRegex(ValueError,'incomplete'):read_episode(incomplete)
                obj=[json.loads(l) for l in rows];next(r for r in obj if r['record_type']=='sse_wire')['receive_ns']+=1
                tampered=Path(d)/'tampered.jsonl';tampered.write_text(''.join(json.dumps(r)+'\n' for r in obj))
                with self.assertRaisesRegex(ValueError,'wire/result'):read_episode(tampered)
                from wire_checks import token_stream
                r=copy.deepcopy(e['requests']['V0'])
                for ev in r['raw_sse_events']:
                    if ev['raw_data']=='[DONE]':continue
                    o=json.loads(ev['raw_data'])
                    for c in o.get('choices',[]):
                        if c.get('finish_reason')=='length':c['finish_reason']=None
                    ev['raw_data']=json.dumps(o)
                with self.assertRaisesRegex(ValueError,'raw finish'):token_stream(r,self.burst['prompts']['V0'],64)
        asyncio.run(run())

    def test_missing_done_real_executor_preserves_failed_episode(self):
        class NoDone(FakeTransport):
            async def stream_completion(self,*a,**kw):
                async for raw in super().stream_completion(*a,**kw):
                    if raw!='[DONE]':yield raw
        async def run():
            with tempfile.TemporaryDirectory(dir=ROOT) as d:
                p=Path(d)/'failed.jsonl';e,a=await self.make_episode(p,transport=NoDone())
                self.assertFalse(a['measurement_valid']);self.assertEqual(read_episode(p)[1],a)
                self.assertEqual(len(e['requests']),12)
                self.assertTrue(all(not r['done_received'] for r in e['requests'].values()))
        asyncio.run(run())

    def test_pair_prompts_seed_identity_ids_and_no_semaphore(self):
        for b in self.plan['blocks']:
            a,c=b['episodes']
            for role in [f'V{i}' for i in range(8)]:
                for key in ['prompts','seeds','prompt_seeds']:self.assertEqual(a[key][role],c[key][role])
                self.assertNotEqual(a['request_ids'][role],c['request_ids'][role])
                self.assertEqual(hashlib.sha256(json.dumps(a['prompts'][role],separators=(',',':')).encode()).hexdigest(),a['prompt_hashes'][role])
        for repeat in range(1,9):
            a,c=[b for b in self.plan['blocks'] if b['repeat']==repeat]
            for condition in ['burst','no_burst']:
                x=next(e for e in a['episodes'] if e['condition']==condition)
                y=next(e for e in c['episodes'] if e['condition']==condition)
                for key in ['prompts','seeds','prompt_seeds','prompt_hashes','outputs']:self.assertEqual(x[key],y[key])
        import ast
        t=ast.parse((ROOT/'collect.py').read_text())
        self.assertFalse(any(isinstance(x,ast.Attribute) and x.attr=='Semaphore' for x in ast.walk(t)))

    def test_batched_token16_crossing_stops_and_preserves_raw(self):
        class Batched(FakeTransport):
            async def stream_completion(self,*a,**kw):
                role=kw['request_id'].split(':')[-1];index=0
                async for raw in super().stream_completion(*a,**kw):
                    if role=='V0' and index==14:
                        obj=json.loads(raw);obj['choices'][0]['token_ids']=[42,42];raw=json.dumps(obj)
                    if not (role=='V0' and index==15):yield raw
                    index+=1
        async def run():
            with tempfile.TemporaryDirectory(dir=ROOT) as d:
                path=Path(d)/'batched.jsonl';t=Batched();e,a=await self.make_episode(path,transport=t,expect_failure=True)
                self.assertFalse(a['measurement_valid']);self.assertFalse(t.burst_seen)
                self.assertEqual(e['trigger']['single_token_thresholds'][0],False)
                self.assertEqual(read_episode(path)[1],a)
        asyncio.run(run())

    def test_percentile_bootstrap_against_independent_ordered_resamples(self):
        import itertools,math
        from analyze_campaign import ci,compositions
        values=[-8,1,4,12];ordered=sorted(sum(s)/4 for s in itertools.product(values,repeat=4))
        actual=ci(values,False)
        self.assertEqual(actual['ci_low'],ordered[math.ceil(.025*len(ordered))-1])
        self.assertEqual(actual['ci_high'],ordered[math.ceil(.975*len(ordered))-1])
        self.assertEqual(len(list(compositions(8,8))),6435)

    def test_actual_run_episode_with_synthetic_configuration_metrics_and_logs(self):
        # Exercises run_episode itself; the full campaign test separately mocks
        # this boundary to test process lifecycle. No server is contacted.
        from collect import run_episode
        from verify import configuration
        fixture=Path('/home/rock/projects/DOS/new/runs/prefill_shape_v1/diagnostic_b2048_strict_20261017T204032')
        original=json.loads(next(fixture.glob('*burst.jsonl')).read_text().splitlines()[-1])['episode']['server_config_before']['body']
        ep=next(e for b in self.plan['blocks'] for e in b['episodes'] if e['condition']=='no_burst' and e['budget']==2048)
        body=copy.deepcopy(original);body['vllm_config']['model_config'].update(max_model_len=8192,seed=20260711)
        async def run():
            with tempfile.TemporaryDirectory(dir=ROOT) as d:
                log=Path(d)/'server.log';log.write_text('');p=Path(d)/'episode.jsonl'
                class ServingFixture(FakeTransport):
                    def __init__(self):super().__init__();self.send_hooks={};self.finished=0
                    async def stream_completion(self,*a,**kw):
                        self.send_hooks[kw['request_id']](time.perf_counter_ns())
                        try:
                            async for raw in super().stream_completion(*a,**kw):yield raw
                        finally:
                            self.finished+=1
                            if self.finished==8:
                                log.write_text('Iteration(0): 8 context requests, 2048 context tokens, 0 generation requests, 0 generation tokens, iteration elapsed time: 1.0 ms\n')
                    async def get_json(self,url,headers,timeout):
                        if '/server_info' in url:return 200,body
                        n=self.finished
                        labels='num_gpu_blocks="1024",num_gpu_blocks_override="1024",block_size="16",enable_prefix_caching="False"'
                        data={'vllm:request_success_total':n,'vllm:prompt_tokens_total':n*256,
                            'vllm:generation_tokens_total':n*64,'vllm:request_prefill_kv_computed_tokens_sum':n*256,
                            'vllm:num_preemptions_total':0,'vllm:num_requests_running':self.active,
                            'vllm:num_requests_waiting':0,'process_start_time_seconds':1}
                        return 200,'vllm:cache_config_info{'+labels+'} 1\n'+''.join(k+' '+str(v)+'\n' for k,v in data.items())
                j=Journal(p)
                try:a=await run_episode(self.base,ServingFixture(),ep,j,dict(process_start=1),log,'offline-key',origin='serving')
                finally:j.close()
                self.assertTrue(a['measurement_valid'],a)
                self.assertEqual(read_episode(p)[1],a)
        asyncio.run(run())

    def test_journal_barrier_order_timestamps_and_batched_fsync(self):
        async def run():
            with tempfile.TemporaryDirectory(dir=ROOT) as d:
                p=Path(d)/'j.jsonl';j=Journal(p);stamps=[]
                try:
                    for i in range(1000):
                        stamp=time.perf_counter_ns();stamps.append(stamp);j.emit('sse_wire',receive_ns=stamp,raw_data='x'*100)
                    await j.flush()
                    rows=[json.loads(l) for l in p.read_text().splitlines()]
                    self.assertEqual(len(rows),1000);self.assertEqual([r['journal_seq'] for r in rows],list(range(1000)))
                    self.assertEqual([r['receive_ns'] for r in rows],stamps)
                    self.assertTrue(all(r['receive_ns']<=r['perf_counter_ns'] for r in rows))
                    self.assertEqual(j.stats['written'],1000);self.assertLess(j.stats['fsync_calls'],100)
                finally:j.close()
        asyncio.run(run())

    def test_writer_io_failure_fails_flush_and_close(self):
        async def run():
            with tempfile.TemporaryDirectory(dir=ROOT) as d:
                j=Journal(Path(d)/'j.jsonl')
                with patch('instrument.os.fsync',side_effect=OSError('offline injected failure')):
                    j.emit('test')
                    with self.assertRaisesRegex(ValueError,'persistence failure'):await j.flush()
                with self.assertRaisesRegex(ValueError,'persistence failure'):j.close()
                self.assertFalse(j.thread.is_alive())
        asyncio.run(run())

    def test_queue_full_fails_without_wait_and_retains_queued_rows(self):
        import threading
        async def run():
            with tempfile.TemporaryDirectory(dir=ROOT) as d:
                release=threading.Event();entered=threading.Event();real=os.fsync
                def blocked(fd):entered.set();release.wait(5);real(fd)
                j=Journal(Path(d)/'j.jsonl')
                with patch('instrument.os.fsync',blocked):
                    for _ in range(64):j.emit('initial')
                    while not entered.is_set():await asyncio.sleep(.001)
                    for _ in range(4096):j.emit('queued')
                    start=time.perf_counter_ns()
                    with self.assertRaisesRegex(ValueError,'queue full'):j.emit('overflow')
                    elapsed=(time.perf_counter_ns()-start)/1e6
                    self.assertLess(elapsed,100) # generous; failure must not wait for disk release
                    release.set()
                    with self.assertRaisesRegex(ValueError,'persistence failure'):await j.flush()
                with self.assertRaisesRegex(ValueError,'persistence failure'):j.close()
                rows=[json.loads(l) for l in (Path(d)/'j.jsonl').read_text().splitlines()]
                self.assertEqual(len(rows),4160)
        asyncio.run(run())

    def _simulate_campaign(self,fail_at=None,close_failure=False):
        # Process/service boundaries are mocked; per-request executor, journal,
        # workload, fixed plan, assessment, campaign ordering and cleanup are real.
        import subprocess
        original_sleep=asyncio.sleep;children=[];episodes=[];killed=[]
        async def fast_sleep(delay):await original_sleep(0)
        class Child:
            def __init__(self,command,**kw):
                self.pid=os.getpid();self.returncode=None;self.command=command
                kw['stdout'].write(f'v0.17.1 max_num_batched_tokens={command[command.index("--max-num-batched-tokens")+1]}. GPU KV cache size: 16,384 tokens\n');kw['stdout'].flush()
                children.append(self)
            def poll(self):return self.returncode
            def wait(self,timeout=None):self.returncode=0;return 0
        class Health:
            async def get_json(self,*a):return 200,{}
            async def close(self):
                if close_failure:raise OSError('injected client cleanup failure')
        async def inline_wait(fn,*a,**kw):return fn(*a,**kw)
        async def transport(base):return Health()
        async def episode(base,transport,ep,j,runtime,log,key):
            e=dict(plan=ep,origin='synthetic',runtime={},requests={},trigger=None,errors=[],metrics_samples=[])
            j.emit('episode_start',plan=ep,plan_sha256=sha(ep),origin='synthetic')
            await workload(base,FakeTransport(),ep,j,e,key,'http://127.0.0.1:8028')
            if fail_at is not None and len(episodes)+1==fail_at:e['errors'].append(dict(type='InjectedFailure',detail='offline test'))
            result=assess(ep,e);j.emit('episode_result',episode=e,assessment=result);await j.flush()
            episodes.append(ep['episode_id']);return result
        async def run():
            with tempfile.TemporaryDirectory(dir=ROOT) as d:
                out=Path(d)/'campaign'
                inventory=subprocess.CompletedProcess([],0,'0, NVIDIA GeForce RTX 3090, 24576 MiB, 802 MiB, test-driver\n','')
                with patch('collect.subprocess.Popen',Child),patch('collect.subprocess.run',return_value=inventory),patch('collect.shared_httpx_transport',transport),patch('collect.run_episode',episode),patch('collect.asyncio.to_thread',inline_wait),patch('collect.os.killpg',side_effect=lambda pid,sig:killed.append((pid,sig))),patch('collect.importlib.metadata.version',return_value='0.17.1'),patch('collect.socket.socket'),patch('collect.asyncio.sleep',fast_sleep):
                    self.assertEqual(await campaign(self.plan,out),1 if fail_at or close_failure else 0)
                summary=json.loads((out/'campaign_summary.json').read_text())
                expected=fail_at if fail_at else (2 if close_failure else 32)
                self.assertEqual(len(summary['not_completed']),32-expected)
                self.assertEqual(summary['error'] is not None,bool(fail_at or close_failure))
                self.assertEqual(len(summary['episodes']),expected)
                self.assertEqual(episodes,[e['episode_id'] for b in self.plan['blocks'] for e in b['episodes']][:expected])
                self.assertEqual(len(children),(expected+1)//2);self.assertEqual(len(killed),(expected+1)//2)
                if close_failure:self.assertEqual(summary['cleanup_errors'][0]['stage'],'transport_close')
        asyncio.run(run())

    def test_full_campaign_orchestrator_with_32_actual_executor_simulations(self):
        self._simulate_campaign()

    def test_first_invalid_episode_stops_without_replacement(self):
        self._simulate_campaign(fail_at=5)

    def test_client_close_failure_still_stops_owned_server_and_saves_summary(self):
        self._simulate_campaign(close_failure=True)

if __name__=='__main__':unittest.main()
