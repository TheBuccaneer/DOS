"""No network/GPU: actual historical executor plus synthetic transport."""
import asyncio,copy,csv,json,socket,tempfile,time,unittest,sys
from pathlib import Path
from unittest.mock import patch
from design import prepare,sha,validate,load_executor,server_command
from collect import workload
from instrument import Journal,shared_httpx_transport
from verify import assess,read_episode,scheduler,configuration
from analyze_campaign import ci

class FakeTransport:
    def __init__(self,early=False):self.counts={};self.active=0;self.peak=0;self.early=early;self.burst_seen=False
    async def stream_completion(self,url,headers,payload,timeout_s,*,request_id):
        role=request_id.split(':')[-1]
        if role.startswith('E'):
            assert len([x for x in self.counts if x.startswith('V')])==8
            assert all(self.counts[f'V{i}']>=16 for i in range(8));self.burst_seen=True
        self.active+=1;self.peak=max(self.peak,self.active)
        try:
            for i in range(payload['max_tokens']):
                if not (self.early and role=='V0'):await asyncio.sleep(0)
                self.counts[role]=i+1
                c=dict(index=0,text='x',token_ids=[42],prompt_token_ids=payload['prompt'] if i==0 else None,
                       finish_reason='length' if i==payload['max_tokens']-1 else None)
                yield json.dumps(dict(id=request_id,model=payload['model'],choices=[c],usage=None))
            yield json.dumps(dict(choices=[],usage=dict(prompt_tokens=len(payload['prompt']),completion_tokens=payload['max_tokens'],total_tokens=len(payload['prompt'])+payload['max_tokens'])))
            yield '[DONE]'
        finally:self.active-=1

class ValidationChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.plan=prepare();cls.base=load_executor()
    def test_frozen_design_and_balance(self):
        self.assertEqual(validate(self.plan),self.plan);self.assertEqual(len(self.plan['blocks']),16)
        for budget in [512,2048]:
            blocks=[b for b in self.plan['blocks'] if b['budget']==budget]
            self.assertEqual(sum(b['episodes'][0]['condition']=='burst' for b in blocks),4)
            for b in blocks:
                x,y=b['episodes']
                for i in range(8):self.assertEqual(x['prompts'][f'V{i}'],y['prompts'][f'V{i}'])
    def test_changed_plan_rejected(self):
        p=copy.deepcopy(self.plan);p['settings']['max_num_seqs']=8
        with self.assertRaises(ValueError):validate(p)
    def test_commands_only_budget_changes(self):
        a=server_command(512);b=server_command(2048);self.assertEqual([(x,y) for x,y in zip(a,b) if x!=y],[('512','2048')])
    def test_scheduler_budget_gate(self):
        raw='Iteration(1): 1 context requests, 504 context tokens, 8 generation requests, 8 generation tokens, iteration elapsed time: 1.0 ms'
        self.assertTrue(scheduler(raw,512,504)['budget_binding_observed'])
        with self.assertRaises(ValueError):scheduler(raw,256,504)
        with self.assertRaises(ValueError):scheduler(raw,512,505)
    def test_additional_prefill_is_distinguished_from_initial_victim_prefill(self):
        def line(i,context,decode):return f'Iteration({i}): 1 context requests, {context} context tokens, {decode} generation requests, {decode} generation tokens, iteration elapsed time: 1.0 ms'
        small=[512]*4+[504]*16+[128]
        r=scheduler('\n'.join(line(i+1,n,0 if i<4 else 8) for i,n in enumerate(small)),512,10240)
        self.assertEqual(r['additional_context_tokens'],8192);self.assertEqual(r['additional_max_context_tokens'],504)
        large=[2048]+[2040]*4+[32]
        r=scheduler('\n'.join(line(i+1,n,0 if i==0 else 8) for i,n in enumerate(large)),2048,10240)
        self.assertEqual(r['additional_context_tokens'],8192);self.assertGreater(r['additional_max_context_tokens'],512)
    def test_block_interval(self):
        self.assertEqual(ci([7]*8),dict(mean=7.,ci_low=7.,ci_high=7.,n=8))
        with self.assertRaises(ValueError):ci([1,2])
        self.assertEqual(ci([1,2],False),dict(mean=1.5,ci_low=None,ci_high=None,n=2))
        self.assertEqual(ci([3]*4,False),dict(mean=3.,ci_low=3.,ci_high=3.,n=4))
    def test_actual_httpx_hook_with_mock_transport_only(self):
        sys.path.insert(0,'/home/rock/projects/porto/.venv/lib/python3.13/site-packages')
        import httpx
        class Stream(httpx.AsyncByteStream):
            def __init__(self,payload):self.payload=payload
            async def __aiter__(self):
                p=self.payload
                for i in range(p['max_tokens']):
                    await asyncio.sleep(0)
                    raw=dict(choices=[dict(index=0,text='x',token_ids=[42],prompt_token_ids=p['prompt'] if i==0 else None,
                        finish_reason='length' if i==p['max_tokens']-1 else None)],usage=None)
                    yield ('data: '+json.dumps(raw)+'\n\n').encode()
                yield ('data: '+json.dumps(dict(choices=[],usage=dict(prompt_tokens=len(p['prompt']),completion_tokens=p['max_tokens'],total_tokens=len(p['prompt'])+p['max_tokens'])))+'\n\n').encode()
                yield b'data: [DONE]\n\n'
        async def handler(request):return httpx.Response(200,stream=Stream(json.loads(request.content)))
        original=httpx.AsyncClient
        async def run():
            ep=next(e for b in self.plan['blocks'] for e in b['episodes'] if e['condition']=='burst')
            with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as d:
                j=Journal(Path(d)/'hook.jsonl');transport=None
                try:
                    with patch.object(httpx,'AsyncClient',side_effect=lambda **kw:original(transport=httpx.MockTransport(handler),**kw)):
                        transport=await shared_httpx_transport(self.base)
                    e=dict(requests={},victim_start_ns=None,trigger=None)
                    await workload(self.base,transport,ep,j,e,'synthetic-test-key','http://127.0.0.1:8028')
                    self.assertEqual(len(e['requests']),12)
                    self.assertTrue(all(r['dispatch_semantics']=='httpx_request_hook' for r in e['requests'].values()))
                    await j.flush()
                finally:
                    if transport is not None:await transport.close()
                    j.close()
                rows=[json.loads(l) for l in (Path(d)/'hook.jsonl').read_text().splitlines()]
                self.assertEqual(sum(r['record_type']=='http_dispatch' for r in rows),12)
        with patch.object(socket.socket,'connect',side_effect=AssertionError('network forbidden')):asyncio.run(run())
    def test_all_32_synthetic_episodes_and_raw_reassessment(self):
        async def run():
            count=0;maximum=0
            with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
                for block in self.plan['blocks']:
                    for ep in block['episodes']:
                        path=Path(directory)/(ep['episode_id']+'.jsonl');journal=Journal(path);transport=FakeTransport()
                        e=dict(plan=ep,origin='synthetic',runtime={},requests={},trigger=None,errors=[],metrics_samples=[])
                        journal.emit('episode_start',plan=ep,plan_sha256=sha(ep),origin='synthetic')
                        try:
                            await workload(self.base,transport,ep,journal,e,'synthetic-test-key','http://127.0.0.1:8028')
                            result=assess(ep,e);self.assertTrue(result['measurement_valid'],result)
                            journal.emit('episode_result',episode=e,assessment=result);await journal.flush()
                        finally:journal.close()
                        self.assertEqual(read_episode(path)[1],result)
                        self.assertEqual(len(e['requests']),12 if ep['condition']=='burst' else 8)
                        self.assertEqual(transport.active,0);maximum=max(maximum,transport.peak);count+=1
                self.assertEqual(count,32);self.assertEqual(maximum,12)
        with patch.object(socket.socket,'connect',side_effect=AssertionError('network forbidden')):asyncio.run(run())
    def test_early_completed_victim_prevents_burst(self):
        async def run():
            ep=next(e for b in self.plan['blocks'] for e in b['episodes'] if e['condition']=='burst')
            with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as d:
                j=Journal(Path(d)/'journal.jsonl');t=FakeTransport(early=True);e=dict(requests={},victim_start_ns=None,trigger=None)
                try:
                    with self.assertRaises(ValueError):await workload(self.base,t,ep,j,e,'synthetic-test-key','http://127.0.0.1:8028')
                    self.assertFalse(t.burst_seen);self.assertEqual(t.active,0);await j.flush()
                finally:j.close()
        asyncio.run(run())
    def test_missing_done_is_rejected(self):
        from wire_checks import token_stream
        record=dict(status='complete',raw_sse_events=[],output_token_ids=[])
        with self.assertRaises(ValueError):token_stream(record,[1],64)
    def test_configuration_gate_with_retained_real_snapshot_fixture(self):
        source=Path('/home/rock/projects/DOS/new/runs/prefill_shape_v1/diagnostic_b2048_strict_20261017T204032')
        path=next(source.glob('*burst.jsonl'))
        last=json.loads(path.read_text().splitlines()[-1]);sample=copy.deepcopy(last['episode']['server_config_before'])
        # Synthetic adaptation of a retained real snapshot, NOT new serving evidence.
        sample['body']['vllm_config']['model_config'].update(max_model_len=8192,seed=20260711)
        configuration(sample,2048)
        changed=copy.deepcopy(sample);changed['body']['vllm_config']['device_config']['device']='cpu'
        with self.assertRaises(ValueError):configuration(changed,2048)
        with self.assertRaises(ValueError):configuration(sample,512)

if __name__=='__main__':unittest.main()
