#!/usr/bin/env python3
"""Offline journal benchmark: historical SSE payload sizes, no serving calls.

Requested rates are aggregate victim TOKEN DATA events/s, eight token bursts
per cadence; simultaneous extra streams add workload in the burst condition.
This is a client-side scheduling probe, not an inference-overhead experiment.
"""
import argparse,asyncio,csv,hashlib,importlib.util,json,math,os,statistics,time
from pathlib import Path
from unittest.mock import patch
from instrument import Journal

ROOT=Path(__file__).parent
SOURCE=Path('/home/rock/projects/DOS/new/runs/prefill_confirmation/llama/results/official_initial8_20260717T083031Z/episodes/llama_off0_conc8_trigger16_prefill_burst_rep01.json')

def percentile(values,q):
    values=sorted(values);return values[min(len(values)-1,math.ceil(q*len(values))-1)]

async def probe(cls,out,rate,condition,repeat):
    historical=json.loads(SOURCE.read_text());schedule=[];records={}
    cadence=8/rate
    for group,prefix,n in [('victim_requests','V',8)]+([('burst_requests','E',4)] if condition=='burst' else []):
        for i,record in enumerate(historical[group][:n]):
            role=prefix+str(i);records[role]=record
            for k,event in enumerate(record['raw_sse_events']):
                when=(min(k+1,len(record['output_token_ids']))+(16.01 if prefix=='E' else 0))*cadence
                schedule.append((when,role,k,event['raw_data']))
    schedule.sort(key=lambda r:r[0])
    path=out/f'{cls.__name__}-{rate}-{condition}-{repeat}.jsonl'
    j=cls(path);lags=[];emit_cost=[];high=0;fsyncs=0
    real_fsync=os.fsync
    def sync(fd):
        nonlocal fsyncs
        fsyncs+=1;return real_fsync(fd)
    start=time.perf_counter_ns();drain=None
    try:
        with patch('os.fsync',sync):
            for target,role,index,raw in schedule:
                remaining=target-(time.perf_counter_ns()-start)/1e9
                if remaining>0:await asyncio.sleep(remaining)
                receipt=time.perf_counter_ns();lags.append(max(0,(receipt-start)/1e6-target*1000))
                before=time.perf_counter_ns()
                j.emit('sse_wire',role=role,event_index=index,receive_ns=receipt,raw_data=raw)
                emit_cost.append((time.perf_counter_ns()-before)/1e3);high=max(high,j.queue.qsize())
            # Large final result is written after streaming, as in collect.py.
            j.emit('episode_result',episode=dict(requests=records),assessment=dict(synthetic=True))
            before=time.perf_counter_ns();await j.flush();drain=(time.perf_counter_ns()-before)/1e6
            j.close()
    finally:
        if not j.closed:j.close()
    rows=[json.loads(l) for l in path.read_text().splitlines()]
    assert len(rows)==len(schedule)+1 and [r['journal_seq'] for r in rows]==list(range(len(rows)))
    assert [r['raw_data'] for r in rows[:-1]]==[s[3] for s in schedule]
    assert all(r['receive_ns']<=r['perf_counter_ns'] for r in rows[:-1])
    size=path.stat().st_size;path.unlink() # temporary benchmark journals only
    return dict(implementation='before_per_record_fsync' if cls.__name__=='LegacyJournal' else 'buffered',
        rate_victim_token_events_per_s=rate,condition=condition,repeat=repeat,
        sse_records=len(schedule),persisted_records=len(rows),journal_bytes=size,
        emit_p50_us=percentile(emit_cost,.5),emit_p95_us=percentile(emit_cost,.95),
        emit_p99_us=percentile(emit_cost,.99),emit_max_us=max(emit_cost),
        scheduled_receipt_lag_p50_ms=percentile(lags,.5),scheduled_receipt_lag_p95_ms=percentile(lags,.95),
        scheduled_receipt_lag_p99_ms=percentile(lags,.99),scheduled_receipt_lag_max_ms=max(lags),
        fsync_calls=fsyncs,queue_high_water=high,post_stream_drain_ms=drain,integrity_verified=True)

async def main(out):
    if ROOT.resolve() not in out.resolve().parents:raise ValueError('benchmark output must stay inside revision directory')
    out.mkdir(exist_ok=False)
    spec=importlib.util.spec_from_file_location('before_instrument',ROOT/'final_code_audit/before/instrument.py')
    old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old);old.Journal.__name__='LegacyJournal'
    rows=[]
    # Rotate implementation and condition order across repetitions.
    for rate in [400,2000,10000]:
        for repeat in range(1,4):
            for cls in ([old.Journal,Journal] if repeat%2 else [Journal,old.Journal]):
                for condition in (['no_burst','burst'] if repeat%2 else ['burst','no_burst']):
                    rows.append(await probe(cls,out,rate,condition,repeat))
    with (out/'measurements.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,list(rows[0]));w.writeheader();w.writerows(rows)
    groups=[]
    for implementation in ['before_per_record_fsync','buffered']:
        for rate in [400,2000,10000]:
            for condition in ['no_burst','burst']:
                rr=[r for r in rows if r['implementation']==implementation and r['rate_victim_token_events_per_s']==rate and r['condition']==condition]
                groups.append(dict(implementation=implementation,rate=rate,condition=condition,n=3,
                    median_run_emit_p99_us=statistics.median(r['emit_p99_us'] for r in rr),
                    median_run_scheduled_lag_p99_ms=statistics.median(r['scheduled_receipt_lag_p99_ms'] for r in rr),
                    max_scheduled_lag_ms=max(r['scheduled_receipt_lag_max_ms'] for r in rr),
                    median_fsync_calls=statistics.median(r['fsync_calls'] for r in rr),
                    max_queue_high_water=max(r['queue_high_water'] for r in rr),
                    median_post_stream_drain_ms=statistics.median(r['post_stream_drain_ms'] for r in rr)))
    report=dict(schema='journal-offline-benchmark-v1',source=str(SOURCE),source_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        clock_resolution_s=time.get_clock_info('perf_counter').resolution,
        interpretation='Synthetic pacing and real local disk writes; no GPU/server, no inference interference bound; no CI from three repetitions.',
        zero_serving_requests=True,all_36_integrity_checks_passed=all(r['integrity_verified'] for r in rows),groups=groups)
    (out/'summary.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,default=ROOT/'final_code_audit'/'benchmark')
    asyncio.run(main(parser.parse_args().out))
