# Codex-Arbeitsauftrag: NordSec → ICISSP 2027 – gezielte Validierungsmessung

## 1. Rolle und Ziel

Du arbeitest als wissenschaftlicher Mitarbeiter mit Schwerpunkt empirische LLM-Serving-Systeme, experimentelle Methodik und wissenschaftliche Reproduzierbarkeit.

**Repository:** `/home/rock/projects/DOS/`

**Deadline:** 22. Oktober 2026.

Das bestehende NordSec-Manuskript soll für ICISSP 2027 wissenschaftlich gestärkt werden. Die Forschungsrichtung ist eingefroren. Keine neuen Forschungsideen, keine umfangreichen Parameterstudien und keine Arbeiten in DOS2.

Es existieren genau zwei gültige Reviews (−1 und 0).

Der ursprüngliche, nicht robuste Offload×Burst-Primärbefund bleibt bestehen. Neuere Analysen sind ergänzend und retrospektiv zu kennzeichnen.

## 2. Ausgangslage

Die bestehende Hauptkampagne umfasst 192 Episoden und 96 gepaarte Blöcke. Sie wurde unabhängig anhand der Raw-SSE-Daten auditiert.

Die anschließende Trigger-Fortschrittsanalyse zeigt, dass in den zwölf Konfigurationsmitteln bereits bei Token 32 rund 99,04–99,93 % der bis Token 64 zusätzlich beobachteten Zeit akkumuliert sind.

Das bisherige Closed-Loop-Design enthält jedoch clientseitige Semaphore-Wartezeiten. Außerdem wurde `max_num_batched_tokens` in der Hauptkampagne nicht systematisch variiert.

**Ziel ist eine einzige kleine Kontrollkampagne**, die diese methodischen Einschränkungen gezielt adressiert.

## 3. Vorgeschlagenes Experiment

| Faktor | Festlegung |
|---|---|
| Modell | Llama-3.1-8B-Instruct |
| GPU | RTX 3090 |
| vLLM | Historische Version prüfen |
| CPU-Offload | 0 GiB |
| Victims | 8 feste Request-Identitäten |
| Victim-Workload | 256 Input / 64 Output Tokens |
| Burst | 4 × 2048 Input / 16 Output Tokens |
| Prefill-Budgets | 512 und 2048 |
| max_num_seqs | 16 |
| Trigger | Alle 8 Victims haben mindestens 16 Output-Tokens empfangen |
| Conditions | Burst versus No-Burst |
| Wiederholungen | 8 gepaarte Blöcke je Budget |
| Gesamt | 32 Episoden |

Alle acht Victims müssen vor dem Burst bereits decodieren. Die Client-Anwendung darf keine künstliche Begrenzung erzeugen, durch die Victims vor dem HTTP-Dispatch warten.

Die Paare verwenden identische Victim-Prompts, Prompt-Seeds und Generierungsparameter. Burst/No-Burst-Reihenfolgen werden kontrolliert ausbalanciert.

## 4. Phase A – Technische Bestandsaufnahme

Untersuche eigenständig die vorhandenen Skripte, insbesondere:

- `new/scripts/prefill_confirmation/`
- `new/scripts/chunk_budget_screen/`
- `new/runs/prefill_confirmation/`
- `new/runs/chunk_budget_screen/`

Prüfe außerdem die vorhandenen Raw-SSE-Audits und Trigger-Fortschrittsanalysen aus dem Oktober 2026.

Bestimme, welche Komponenten ohne Änderungen übernommen werden können.

Verifiziere anhand des tatsächlichen Codes und der eingesetzten vLLM-Version:

- Ob das Budget 512 zulässig ist und wie Chunked Prefill wirkt.
- Ob beide Budgetkonfigurationen tatsächlich unterschiedliche Prefill-/Scheduling-Verläufe erzeugen.
- Ob das Triggerverfahren ohne Client-Semaphore implementierbar ist.
- Ob die geplante GPU-/KV-Konfiguration ausführbar ist.
- Ob vollständige Raw-SSE-Daten, Request-IDs, Timestamp-Grenzen und Pair-Metadaten gespeichert werden.

Falls die technischen Voraussetzungen nicht erfüllt sind, dokumentiere die minimal notwendige Anpassung. Keine eigenmächtige Ausweitung des Experiments.

## 5. Phase B – Wissenschaftliches Messprotokoll

Definiere vor Messbeginn:

**Primärer zusätzlicher Endpunkt:** Gepaarte zusätzliche klientenseitige Zeit vom Trigger bis zum Empfang von Token 32 bei festgelegten Victim-Identitäten.

**Sekundäre Endpunkte:** Zusätzliche Zeit bis Token 64, maximale ITL, Token-Fortschrittskurve und absolute Completion-Zeit.

Die Messung muss außerdem berücksichtigen:

- Blockweise Paarung als statistische Einheit.
- 95-%-Bootstrap-Konfidenzintervalle mit dokumentiertem Verfahren.
- Vor-Trigger-Unterschiede als Kontrollanalyse.
- Sensitivität gegenüber unterschiedlichen generierten Tokenfolgen.
- Tatsächliche statt nur konfigurierte Prefill-Budget-Wirkung.
- Grenzen der statistischen Aussagekraft bei acht Paaren.
- Klare Trennung zwischen Client-Empfangszeiten und serverinternen Ereignissen.

Definiere ausdrücklich, welche Ergebnisse unsere Interpretation stützen und welche sie schwächen oder widerlegen würden.

Insbesondere darf nicht vorab angenommen werden, dass kleinere Prefill-Budgets die Gesamtdauer reduzieren.

## 6. Phase C – Technische Vorbereitung

Falls technisch machbar, bereite eine reproduzierbare Experimentimplementierung vor.

Anforderungen:

- Bestehende historische Messdaten und Skripte unverändert lassen.
- Neue Dateien in einem separaten, eindeutig benannten Revisionsverzeichnis speichern.
- Konfigurationen, Seeds, Reihenfolgen und Softwarestände dokumentieren.
- Testmöglichkeiten ohne GPU-Messkampagne verwenden, soweit sinnvoll.
- Keine historischen Daten überschreiben.
- Keine stillschweigenden Änderungen der ursprünglichen Experimentalbedingungen.

## 7. Verbindlicher Freigabepunkt

**Vor dem Start der 32 neuen GPU-Messepisoden anhalten.**

Liefere zunächst:

1. Ergebnis der technischen Machbarkeitsprüfung.
2. Geplante Codeänderungen und verwendete bestehende Komponenten.
3. Präzises, eingefrorenes Messprotokoll.
4. Ausführbare Befehle und geschätzten Zeitaufwand.
5. Erwartete Aussagekraft und verbleibende Risiken.
6. Klare GO-/NO-GO-Empfehlung für die Messung.

**Warte anschließend auf meine ausdrückliche Freigabe.**

Erst nach meinem GO dürfen die eigentlichen GPU-Messungen gestartet werden.

## 8. Wissenschaftlicher Rahmen

Die neue Kampagne soll nicht die Forschungsrichtung verändern, sondern drei konkrete Fragen beantworten:

1. Bleibt der beobachtete frühe Token-Stall ohne Client-Semaphore bestehen?
2. Wie verändert das Prefill-Budget die zusätzliche Zeit bis Token 32?
3. Unterscheiden sich die Auswirkungen auf maximale ITL und gesamte Token-Fortschrittszeit?

Keine erfundenen Ergebnisse, keine unbelegten Kausalerklärungen und keine Behauptung einer neuartigen Scheduler-Schwachstelle.

Unterscheide jederzeit zwischen unabhängig geprüft, berichtet, explorativ und noch offen.

**Ziel:** Eine begrenzte, methodisch kontrollierte Zusatzmessung, die direkt zur Verbesserung des bestehenden NordSec-Manuskripts für ICISSP 2027 beiträgt.

Beginne jetzt mit der technischen Bestandsaufnahme und arbeite selbstständig bis zum verbindlichen Freigabepunkt.