"""Metric/token validators derived from historical prefill_shape_v1/audit.py."""
import json,math,re
from design import require

def metric(body,name):
    require(isinstance(body,str),'metrics body missing')
    values=[float(m[1]) for m in re.finditer(r'^'+re.escape(name)+r'(?:\{[^\n]*\})?\s+([^\s]+)',body,re.M)]
    require(values and all(math.isfinite(v) for v in values),'missing/nonfinite metric: '+name)
    return sum(values)

def token_stream(record,prompt,output):
    require(record['status']=='complete','request incomplete/failed')
    ids,times,sizes=[],[],[]
    done=False
    usage,echo=None,None
    finishes=[];usage_count=0
    prior=-1
    for event in record['raw_sse_events']:
        stamp=event['receive_perf_counter_ns']
        require(type(stamp) is int and stamp>=prior,'nonmonotone SSE receipts')
        prior=stamp
        raw=event['raw_data']
        require(not done,'data after DONE')
        if raw=='[DONE]': done=True; continue
        if raw=='': continue
        obj=json.loads(raw)
        require(isinstance(obj,dict) and 'error' not in obj,'SSE error payload')
        if obj.get('usage') is not None:
            usage=obj['usage'];usage_count+=1
        choices=obj.get('choices') or []
        require(isinstance(choices,list) and len(choices)<=1,'unexpected SSE choices')
        require(not choices or isinstance(choices[0],dict),'invalid SSE choice')
        for candidate in (
            obj.get('prompt_token_ids'),
            choices[0].get('prompt_token_ids') if choices else None
        ):
            if candidate is not None:
                require(isinstance(candidate,list) and all(type(t) is int for t in candidate),
                        'invalid prompt ID echo')
                require(echo is None or echo==candidate,'contradictory prompt ID echo')
                echo=candidate
        if choices and choices[0].get('finish_reason') is not None:finishes.append(choices[0]['finish_reason'])
        batch=(choices[0].get('token_ids') or []) if choices else []
        require(isinstance(batch,list) and all(type(t) is int and t>=0 for t in batch),'invalid output IDs')
        ids.extend(batch);times.extend([stamp]*len(batch))
        if batch: sizes.append(len(batch))
    require(done,'missing DONE')
    require(finishes==['length'] and usage_count==1,'raw finish/usage cardinality mismatch')
    require([e['event_index'] for e in record['raw_sse_events']]==list(range(len(record['raw_sse_events']))),'raw SSE index gap')
    require(record['request_terminal_ns']>=record['raw_sse_events'][-1]['receive_perf_counter_ns'],'terminal precedes DONE')
    require(echo==prompt and ids==record['output_token_ids'],'raw prompt/token copy mismatch')
    require(len(ids)==output and isinstance(usage,dict) and usage.get('completion_tokens')==output and
            usage.get('prompt_tokens')==len(prompt) and usage.get('total_tokens')==len(prompt)+output,'usage/output length mismatch')
    require(record['done_received'] and record['finish_reason']=='length','request finish mismatch')
    require(record['send_ns']>=record['scheduled_dispatch_ns'] and record['send_ns']<=times[0],
            'invalid send/receive timestamps')
    return dict(ids=ids,times=times,batch_sizes=sizes)
