#!/usr/bin/env python3
"""Analyze only complete, independently re-read serving evidence from the plan."""
import argparse,csv,itertools,json,math,statistics
from pathlib import Path
from design import validate,sha,require
from verify import read_episode,token_stream

def compositions(n,total,prefix=()):
    if n==1:yield prefix+(total,);return
    for x in range(total+1):yield from compositions(n-1,total-x,prefix+(x,))
def ci(values,require_eight=True):
    if require_eight:require(len(values)==8,'exactly eight paired block values required')
    n=len(values)
    if n<4:return dict(mean=statistics.fmean(values) if values else None,ci_low=None,ci_high=None,n=n)
    dist=[]
    for counts in compositions(n,n):
        probability=math.factorial(n)/(n**n*math.prod(math.factorial(k) for k in counts))
        dist.append((sum(k*v for k,v in zip(counts,values))/n,probability))
    dist.sort();cum=0;lo=None;hi=None
    for value,p in dist:
        cum+=p
        if lo is None and cum>=.025:lo=value
        if hi is None and cum>=.975:hi=value
    return dict(mean=statistics.fmean(values),ci_low=lo,ci_high=hi,n=n)

def analyze(path,out):
    require(Path(__file__).parent.resolve() in out.resolve().parents,'analysis output must remain inside this revision package')
    require(not out.exists(),'choose a new analysis output directory')
    plan=validate(json.loads((path/'plan.json').read_text()));recorded=json.loads((path/'campaign_summary.json').read_text())
    require(recorded['plan_sha256']==sha(plan) and not recorded['error'] and not recorded['not_completed'],'campaign incomplete; preserve partial data without eight-pair inference')
    blocks=[];request_pairs=[];trajectory=[]
    for block in plan['blocks']:
        conditions={}
        for ep in block['episodes']:
            episode,result=read_episode(path/block['block_id']/(ep['episode_id']+'.jsonl'))
            require(episode['origin']=='serving' and result['measurement_valid'],'invalid or synthetic measurement')
            require(episode['plan']==ep,'journal/plan mismatch');conditions[ep['condition']]=(episode,result)
            trajectory.append(dict(block_id=block['block_id'],budget=block['budget'],repeat=block['repeat'],condition=ep['condition'],**result['scheduler']))
        a,aa=conditions['no_burst'];b,bb=conditions['burst'];row=dict(block_id=block['block_id'],budget=block['budget'],repeat=block['repeat'])
        for endpoint in ['token32_ms','token64_ms','max_itl_ms','max_post_trigger_itl_ms','completion_from_phase_ms','completion_from_http_hook_ms','terminal_from_phase_ms']:
            x=statistics.fmean(aa['victim_endpoints'][f'V{i}'][endpoint] for i in range(8));y=statistics.fmean(bb['victim_endpoints'][f'V{i}'][endpoint] for i in range(8))
            row[endpoint+'_delta']=y-x;row[endpoint+'_log_ratio']=math.log(y/x)
        pre_max=0.;residual=[]
        for i in range(8):
            role=f'V{i}';sa=token_stream(a['requests'][role],a['plan']['prompts'][role],64);sb=token_stream(b['requests'][role],b['plan']['prompts'][role],64)
            require(a['plan']['prompts'][role]==b['plan']['prompts'][role] and a['plan']['seeds'][role]==b['plan']['seeds'][role],'paired identity mismatch')
            ta,tb=a['trigger']['trigger_ns'],b['trigger']['trigger_ns']
            delta=[((y-tb)-(x-ta))/1e6 for x,y in zip(sa['times'],sb['times'])]
            pre_max=max(pre_max,max(abs(v) for v in delta[:16]))
            p8a=aa['victim_endpoints'][role]['pre8_cadence_ms'];p8b=bb['victim_endpoints'][role]['pre8_cadence_ms']
            agea=aa['victim_endpoints'][role]['age16_ms'];ageb=bb['victim_endpoints'][role]['age16_ms']
            residual.append(delta[31]-(16*(p8b-p8a)-(ageb-agea)))
            prefix=next((j for j,(x,y) in enumerate(zip(sa['ids'],sb['ids'])) if x!=y),64)
            request_pairs.append(dict(block_id=block['block_id'],budget=block['budget'],repeat=block['repeat'],request_index=i,
                output_equal=prefix==64,common_prefix_tokens=prefix,delta32_ms=delta[31],delta64_ms=delta[63],
                progress_differences_ms=delta,pre8_forecast_residual32_ms=residual[-1]))
        row.update(pre_envelope_max_ms=pre_max,delta32_minus_pre_envelope_ms=row['token32_ms_delta']-pre_max,
                   mean_pre8_forecast_residual32_ms=statistics.fmean(residual));blocks.append(row)
    effects=[]
    for budget in [512,2048]:
        rr=[r for r in blocks if r['budget']==budget]
        for endpoint in [k for k in rr[0] if k.endswith('_delta') or k.endswith('_log_ratio')]+['delta32_minus_pre_envelope_ms','mean_pre8_forecast_residual32_ms']:
            effects.append(dict(budget=budget,endpoint=endpoint,**ci([r[endpoint] for r in rr])))
    indexed={(r['budget'],r['repeat']):r for r in blocks}
    for endpoint in ['token32_ms_delta','token64_ms_delta','max_itl_ms_delta','max_post_trigger_itl_ms_delta','completion_from_phase_ms_delta']:
        effects.append(dict(budget='512_minus_2048',endpoint=endpoint,**ci([indexed[512,r][endpoint]-indexed[2048,r][endpoint] for r in range(1,9)])))
    bursts={b:[r for r in trajectory if r['budget']==b and r['condition']=='burst'] for b in [512,2048]}
    # Verify actual scheduling differentiation rather than treating CLI values as evidence.
    actual=dict(budget512_binding_blocks=sum(r['additional_budget_binding_observed'] for r in bursts[512]),
        budget2048_blocks_with_context_above512=sum(r['additional_max_context_tokens']>512 for r in bursts[2048]),
        all_burst_blocks_have_prefill_decode_overlap=all(r['additional_prefill_decode_overlap_iterations']>0 for r in bursts[512]+bursts[2048]))
    actual['budget_manipulation_verified']=(actual['budget512_binding_blocks']==8 and actual['budget2048_blocks_with_context_above512']==8 and actual['all_burst_blocks_have_prefill_decode_overlap'])
    subgroup_rows=[];curves=[]
    for budget in [512,2048]:
        for target in [32,64]:
            for name,choose in [('identical_sequence',lambda r:r['output_equal']),('different_sequence',lambda r:not r['output_equal']),
                                ('identical_through_target',lambda r:r['common_prefix_tokens']>=target)]:
                chosen=[r for r in request_pairs if r['budget']==budget and choose(r)]
                values=[statistics.fmean(r[f'delta{target}_ms'] for r in chosen if r['repeat']==repeat) for repeat in range(1,9) if any(r['repeat']==repeat for r in chosen)]
                subgroup_rows.append(dict(budget=budget,target=target,subgroup=name,n_requests=len(chosen),**ci(values,False)))
        for k in range(64):
            values=[statistics.fmean(r['progress_differences_ms'][k] for r in request_pairs if r['budget']==budget and r['repeat']==repeat) for repeat in range(1,9)]
            curves.append(dict(budget=budget,token_rank=k+1,**ci(values)))
    out.mkdir(parents=True)
    relative=[]
    for row in effects:
        if row['endpoint'].endswith('_log_ratio'):
            relative.append(dict(budget=row['budget'],endpoint=row['endpoint'].removesuffix('_log_ratio'),
                geometric_effect_pct=100*math.expm1(row['mean']),ci_low=100*math.expm1(row['ci_low']),ci_high=100*math.expm1(row['ci_high']),n=8))
    for name,rows in [('paired_block_effects.csv',blocks),('effect_intervals.csv',effects),('request_pair_sensitivity.csv',request_pairs),('scheduler_trajectories.csv',trajectory),
                      ('output_subgroup_intervals.csv',subgroup_rows),('progress_curve_intervals.csv',curves)]:
        with (out/name).open('w',newline='') as f:
            w=csv.DictWriter(f,list(rows[0]));w.writeheader();w.writerows(rows)
    with (out/'relative_effects_pct.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,list(relative[0]));w.writeheader();w.writerows(relative)
    (out/'assessment.json').write_text(json.dumps(dict(plan_sha256=sha(plan),actual_scheduler_manipulation=actual,
        original_negative_primary_unchanged=True,exploratory_additional_validation=True,causal_server_mechanism_established=False),indent=2)+'\n')
    print(json.dumps(actual,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--campaign',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();analyze(a.campaign,a.out)
