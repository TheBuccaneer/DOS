> **Überholt durch den finalen Code-Audit:** Maßgeblich ist jetzt FINALER_CODE_AUDIT.md (29 Tests, Protokoll Revision 2). Dieser frühere Vorbereitungsbericht bleibt zur Nachvollziehbarkeit erhalten. Kein GPU-Start freigegeben oder ausgeführt.

# NordSec → ICISSP: Freigabevorlage für genau eine Kontrollkampagne

Stand 18.10.2026. **Freigabepunkt erreicht; keine neuen Serving-Episoden und kein vLLM-Server wurden gestartet.** Frist22.10.2026, zwei Reviews (−1/0), unveränderter negativer ursprünglicher Primärbefund. Dieses Paket betrifft ausschließlich die Ergänzung des vorhandenen Papers; DOS2 wurde nicht bearbeitet.

## Empfehlung

**GO für die vorbereitete, begrenzte Zusatzmessung nach deiner ausdrücklichen Freigabe**, mit einem harten technischen Gate vor dem ersten Victim jedes Blocks. Die Datenlage rechtfertigt diese einzelne Kontrolle: acht gleichzeitig schon decodierende feste IDs ohne Victim-Semaphore und ein innerhalb dieser Population gepaarter Budgetvergleich. Ein erwartetes positives Ergebnis wird nicht vorausgesetzt.

**Noch offen:** tatsächlicher Serverstart unter dem dokumentierten Python-3.13-Wrapper, reale CUDA-/Kernel-Lauffähigkeit dieser Kombination und die konkreten Zusatzprefill-Verläufe mit acht Victims. Die Offline-Prüfung kann diese Serving-Nachweise nicht ersetzen. Scheitert ein Start-/Konfigurations-/Rohdaten-Gate, endet die Kampagne ohne Ersatzversuche; das ist kein wissenschaftlicher Negativbefund.

## 1. Tatsächlich geprüfte Machbarkeit

| Punkt | Nachweis und Status |
|---|---|
| Historische Hauptkampagne | Abgeschlossener unabhängiger Raw-Audit:192 Episoden/96 Paare; Oktober-Fortschrittsanalyse und deren Herkunft gelesen. Neue Messung ersetzt den historischen Primärendpunkt nicht. |
| vLLM | Installierte Paketmetadaten:0.17.1; historisch ebenfalls0.17.1. Scheduler-Code und Tokenbudget-Pfade vor Ort gelesen/gehasht. |
| Budget512 | Die reine Validierungsmethode aus dem tatsächlich installierten Scheduler wurde ohne vLLM-/GPU-Import isoliert ausgeführt:512 und2048 mit Chunked Prefill akzeptiert;512 ohne Chunking bei max_model_len8192 abgelehnt. 512≥max_num_seqs16. |
| GPU | Read-only-Inventur außerhalb der Sandbox erfolgreich:RTX3090,24576MiB,802MiB belegt,Treiber580.178.04. Die fehlgeschlagene Sandbox-NVML-Abfrage belegt keinen Treiberdefekt. Keine CUDA-/Inferenzfunktion ausgeführt. |
| Modellcache | Gepinnter Llama-Snapshot vorhanden; vier Shards zusammen16.060.556.376 Bytes. Alle vorgesehenen tatsächlichen Prompt-IDs sind im lokalen Tokenizer vorhanden und nicht speziell. Keine Modell-Downloads vorgesehen. |
| KV-/Speicherplan | Fester Pool1024×16 Tokens=16384 nominell,16368 nach Nullblock. Maximal angebotene volle Sequenzbelegung10816 Tokens. KV-Speicher etwa2GiB. Das passt nominell auf24GiB neben den Gewichten; Graph-/Workspace-/Runtimebedarf wird erst beim freigegebenen Start geprüft. |
| Python | Alter venv-Interpreter läuft aktuell mit3.14 und sieht vLLM nicht. Das vorhandene Python3.13.7 sieht über den ausdrücklich gesetzten bestehenden Paketpfad vLLM0.17.1/Torch2.10.0/HTTPX0.28.1/Transformers4.57.6. Keine venv- oder Paketinstallation vorgenommen. |
| Ohne Semaphore | Neuer Workloadpfad startet acht Tasks unmittelbar; kein asyncio.Semaphore. Bestehender gemeinsamer HTTPX-Pool mit16 Slots hat mehr Plätze als zwölf Completion-Streams plus Metrikrequest. |
| Neue32-Episoden-Funktion | Elf Offline-Prüfungen bestanden, darunter alle32 geplanten Episoden mit künstlichen Streams durch den historischen SSE-Executor, unabhängiges Journallesen, Trigger, Peak12 und echter HTTPX-Request-Hook mit MockTransport. Künstliche Daten sind keine Serving-Ergebnisse. Details in evidence/offline_tests.txt. |
| Tatsächlich unterschiedliche Budgetwirkung | Quellcode setzt ein wirksames verbleibendes Iterationsbudget; ältere gespeicherte Vier-Victim-/Timer-Artefakte zeigen verwandte512/2048-Konfigurationen. **Der konkrete Acht-Victim-Vergleich ist noch ungemessen.** Die vorbereitete Auswertung fordert tatsächliche Zusatzprefill-Logdifferenzen. |

Die Belege einschließlich Quelle, Hashes, installierter Methode und älterer Artefaktgrenzen stehen in `evidence/technical_inventory.json` und `evidence/sources_sha256.csv`.

## 2. Neue Dateien und wiederverwendete Komponenten

| Komponente | Verwendung |
|---|---|
| Historischer `run_prefill_confirmation.py` | Unverändert, zur Laufzeit nur nach Prüfung des SHA-256 `981aba99aff820ea8fea3bef6df0e1e8bfb127df059695d4736d7702ef300b75` geladen. Nur der einzelne SSE-Request-Executor und seine Cancel-/Clock-Helfer werden benutzt, nicht der alte Episoden-/Semaphore-/Resume-Runner. |
| `prefill_shape_v1/instrument.py` | Byteidentische Kopie in diesem neuen Verzeichnis:Raw-Journal mit geordnetem fsync-Worker, gemeinsame HTTP-Verbindungen, Receipt-Clock, Metriksampler. Der neue DispatchTap protokolliert den HTTP-Hook zusätzlich separat. |
| `prefill_shape_v1/audit.py` | Zwei generische Funktionen `metric` und `token_stream` unverändert per AST extrahiert; `wire_checks.py` enthält diese Funktionen und minimale Importhülle. |
| Historische Workloads | Acht eingefrorene Llama-Repeats aus der Hauptkampagne; V0…V7 und vier originale Burst-Prompts samt Seed/Hash. Gleiche Workloads in beiden Budgets. |
| `design.py`, `plan.json` | Neue feste32-Episoden-Planung, balancierte Reihenfolge, Modell-/KV-/Softwarebedingungen. |
| `collect.py`, `verify.py` | Neuer Triggerorchestrator, Serverlebenszyklus, Konfigurations-/Rohdaten-/Metrik-/Scheduler-Gates. Keine historischen Dateiänderungen. |
| `runtime.py` | Expliziter vorhandener Python3.13-Interpreter plus vorhandene Pakete; keine Reparatur der alten Umgebung. |
| `analyze_campaign.py` | Vorbereitete Blockauswertung einschließlich Budgetkontrast, exakten Bootstrap-CIs, Prä-Kontrollen, Rangzeit- und Ausgabe-Sensitivitätsdaten sowie realer Zusatzprefill-Wirkungsprüfung. |

Die Wiederverwendung ist in `REUSE_PROVENANCE.json` dokumentiert. Die vorbereitete Kampagne schreibt ausschließlich in einen neuen Unterordner dieses Revisionsverzeichnisses. Die historischen Hauptdaten und Skripte sowie die abgeschlossenen Oktober-Auswertungen bleiben unverändert.

## 3. Eingefrorener Messvertrag

Die vollständige Definition einschließlich Stützungs-/Schwächungsregeln steht in `PROTOCOL.md`. Primärer zusätzlicher Endpunkt ist die gepaarte mittlere zusätzliche Zeit Trigger→Token32 für dieselben acht aktiven IDs. Token64, maximale ITL, Fortschrittsverlauf und Completion-Zeit sind sekundär. Acht gepaarte Blöcke je Budget; keine Token-/Request-Pseudoreplikation. Der Budgetkontrast ist Repeat-gepaart512 minus2048. Keine Richtung wird als Erfolg vorausgesetzt.

Die gezielt kontrollierten Abweichungen vom historischen Aufbau sind ausdrücklich:kein Victim-Semaphore; acht statt20 Victims; gemeinsamer HTTP-Pool mit zusätzlichem Hook; budgetunabhängig fester KV-Pool; kein separater Serving-Stabilisierungslauf; gepinnter lokaler Modellpfad und dokumentierte Python-Startanpassung. Die frühere Serverseed/max_model_len/max_num_seqs-/Prefix-/Offload-Bedingung wird erhalten. Der neue Treiberstand ist sichtbar dokumentiert.

Die gesamte Kampagne umfasst320 Completion-Requests,196608 Inputtokens und17408 Outputtokens. Die16 Serverstarts besitzen interne Engine-Warmups, aber keine zusätzlichen Completion-Testanfragen. Readiness-, Konfigurations- und Metrikabfragen sind keine Modell-Generierungsanfragen. Jede technisch ungültige Episode stoppt die Kampagne; kein automatischer Retry/Resume und keine Erweiterung von n=8.

## 4. Zeitbedarf

**Grobe Schätzung:15–30 Minuten Serving plus5–10 Minuten Reaudit/Auswertung.** Grundlage sind die vorhandenen Startup-Zeiten und kurzen0-GiB-Läufe. Ein erstmalig erneut erforderlicher Compile-/Graph-Aufbau kann die Dauer erhöhen; die Schätzung ist keine Messung dieses neuen Designs. Startup-Limit180s je Block, Request-Limit60s, Episode120s, Gesamtlimit90min zuzüglich notwendigem Prozess-Cleanup. Bei Abbruch kein automatisches Wiederholen.

## 5. Konkrete Befehle

`COMMANDS.md` enthält die konkreten absoluten Pfade, den finalen Planhash und den einzelnen Kampagnenstart. Die Metadaten- und Dry-Run-Befehle wurden ausgeführt; der Kampagnenstart wurde **nicht** ausgeführt. Es gibt keinen Testmodus, der heimlich zusätzliche GPU-Episoden startet.

Vor einem späteren Start werden eingefrorene Codes/Protokoll/Plan gegen `FROZEN_FILES_SHA256.json` und der Plan gegen den freigegebenen Hash geprüft. Eine Änderung erfordert eine neue wissenschaftlich sichtbare Fassung; keine stillschweigende Reparatur während des Laufs.

## 6. Aussagekraft und Risiken

Ein positiver Token32-Effekt mit den vorab benannten Kontrollen kann zeigen, dass der früh beobachtete klientenseitige Stall auch bei acht bereits decodierenden IDs ohne Victim-Semaphore auftritt. Der echte Logvergleich kann zusätzlich bestimmen, ob512 und2048 unter denselben Ressourcenbedingungen unterschiedliche Zusatzprefill-Verläufe erzeugen und ob maximale ITL und Completion davon verschieden betroffen sind.

Acht Paare sind eine begrenzte Konfigurationsvalidierung auf einem Modell/einer GPU/0GiB. Kein allgemeiner Sicherheits- oder Fairnessnachweis, keine universelle SLO-Garantie und keine kausale PCIe-/GPU-Erklärung. Das Ergebnis kann den vorhandenen inkrementellen Beitrag stärken oder einschränken, aber nicht den ursprünglichen Primärbefund rückwirkend positiv machen. Kleine Stichprobe, verbleibende Prä-Trigger-Variation, Ausgabeabweichungen, Transport-/Eventloop-Effekte und First-Condition-Effekte bleiben sichtbar.

**Hier wird angehalten. Die32 eigentlichen GPU-Messepisoden dürfen erst nach deinem ausdrücklichen GO gestartet werden.**
