# Eingefrorenes Zusatzprotokoll: acht aktive Victims ohne Client-Semaphore

Stand 18.10.2026, technische Revision 2 nach finalem Code-Audit, vor neuen Serving-Messungen. NordSec → ICISSP 2027, Frist 22.10.2026; genau zwei gültige Reviews (−1/0). Ergänzende Validierung des bestehenden Papers. Die historische nicht robuste normierte Offload×Burst-Interaktion bleibt unverändert. Dieses Protokoll ist vor der neuen Kampagne festgelegt, aber nach Kenntnis der historischen Resultate; keine externe Vorregistrierung wird behauptet.

## Umfang und unveränderliche Faktoren

Genau 32 Episoden: Llama-3.1-8B-Instruct, vLLM 0.17.1, RTX 3090 24 GiB, BF16, Offload 0 GiB, Prefix-Caching aus, Chunked Prefill an, max_num_seqs=16, max_model_len=8192, TP=1. Acht Victims je 256→64 Tokens; vier Zusatzlast-Requests je 2048→16 Tokens nur im Burst. Budgets 512 und 2048, acht Burst/No-Burst-Paare je Budget. Maximal zwölf gleichzeitige Completion-Anfragen. Keine zusätzlichen Warmup-/Stabilisierungs-Completion-Requests und keine Ersatzepisoden.

Der vorhandene Gewichts-Snapshot `0e9e39f249a16976918f6564b8830bc894c89659` wird über seinen lokalen Pfad mit Netzwerk-Downloads deaktiviert geladen. Die Vorbereitungsprüfung bestätigt vier vorhandene Shards und gültige nicht spezielle Prompt-Token-IDs. Eine nachträgliche Bytegleichheit mit den nicht vollständig gehashten historischen Modellgewichten wird nicht behauptet. Der aktuelle Treiber 580.178.04 unterscheidet sich vom historischen Laufmanifest 580.159.03; der Budgetvergleich erfolgt deshalb innerhalb dieser neuen Kampagne.

Serverseed 20260711, Temperatur 0, min_tokens=max_tokens, ignore_eos=True, generation_config=vllm wie im historischen Executor. Die ersten acht historischen Llama-Victim-Identitäten aus Offload0/c8/Repeats1–8 sowie die zugehörigen vier Bursts werden mit ihren tatsächlichen Prompt-IDs, Prompt-Seeds und Generierungs-Seeds übernommen. Dieselben Repeat-Workloads gelten für beide Budgets. Byteherkunft und IDs stehen in plan.json.

## Kontrollierte, ausdrücklich ausgewiesene Anpassungen

1. Neuer Orchestrator ohne Client-Semaphore oder Worker-Warteschlange. Acht Tasks werden unmittelbar gestartet. Gemeinsamer HTTPX-Pool mit 16 Verbindungen für höchstens zwölf Completion-Streams plus einen Metrikrequest; kein künstliches Victim-Limit vor HTTP-Dispatch.
2. HTTPX-Request-Hook nach Request-Vorbereitung und vor dem Transportpfad zusätzlich zum historischen Executor-Dispatch. Der Hook ist weder Socket-Sendezeit noch Server-Ankunft. Getrennte Speicherung von Task-Erstellung, Executor-Start/-Dispatch, Hook, Token-Receipts, DONE und Terminal.
3. Fester KV-Pool bei beiden Budgets: 1.024 Blöcke à 16 Tokens. Ein reservierter Nullblock lässt nominell 16.368 nutzbare Tokens. Die zwölf voll belegten Sequenzen benötigen höchstens 10.816 Tokens; der KV-Pool beträgt für dieses Modell etwa 2 GiB. Preemptions oder abweichende reale Kapazität machen den technischen Vergleich ungültig. Diese Kapazitätsfixierung ist eine neue explizite Kontrolle; historische Budget-Screens konnten budgetabhängig unterschiedliche verfügbare KV-Kapazitäten haben.
4. Keine separaten Stabilisierungsanfragen, um den Auftrag bei genau 32 Episoden / 320 Completion-Requests zu halten. vLLMs interne Startup-/Compile-Warmups bleiben Bestandteil des Starts. Dadurch mögliche First-Condition-Effekte werden ausbalanciert, nicht als beseitigt behauptet.
5. Die alte venv-Verknüpfung zeigt aktuell auf Python 3.14. Der separate runtime.py-Wrapper nutzt vorhandenes Python 3.13.7 und den vorhandenen 3.13-Paketpfad. Weder venv noch historische Skripte werden verändert.

## Paarung und Reihenfolge

16 Serverstarts: ein frischer Server je gepaartem Block, beide Bedingungen desselben Blocks nutzen dieselbe Serverinstanz. Nach jeder Episode fünf Sekunden Pause und bestätigter Idle-Zustand. Budgetreihenfolge je Repeat alterniert (viermal 512 zuerst, viermal 2048 zuerst). Die Bedingungsreihenfolge ist pro Budget exakt 4×Burst zuerst und 4×No-Burst zuerst; die Budgets verwenden im selben Repeat entgegengesetzte Reihenfolgen. Die konkrete aus Masterseed 20261018 abgeleitete, vorab gespeicherte Folge steht in plan.json.

Die Blockeinheit ist ein vollständiges Burst/No-Burst-Paar. Der Budgetkontrast vergleicht diese Paarwirkungen innerhalb identischer Repeat-Workload-Familien. Kein Paaren zwischen Modellen, keine zusätzlichen Modelle oder Offload-Zellen.

## Trigger und Intervention

Die Schwelle ist der einzeln empfangene Ausgabetoken 16 jedes der acht Victims. Wissenschaftlicher Trigger = Maximum dieser acht Receipt-Zeitpunkte, in Burst und Kontrolle jeweils separat. Der Callback liest ausschließlich bis dahin empfangene Tokenzahlen. Ein separater Eventloop-Watcher startet erst danach im Burst vier zusätzliche Tasks. Kein Timer aus dem alten Shape-Experiment wird übernommen.

Bei Beobachtung des Triggers und an jedem der vier Burst-HTTPX-Hooks müssen alle acht Victims mindestens 16 und weniger als 32 Tokens empfangen haben. Andernfalls bleibt die Episode als ungültig erhalten; die Kampagne endet ohne Burst-Nachholung oder Parameteranpassung. Der Offline-Reaudit verlangt für jeden Victim HTTP-Hook < erster Token ≤ Trigger < Token32 und für jeden Zusatzlast-Request Hook > Trigger. Zusätzlich muss der letzte der vier Burst-HTTPX-Hooks strikt vor jedem Victim-Token32 liegen. Gleichheit ist ungültig. Die tatsächliche Trigger→Beobachter-Lücke, Trigger→erster/letzter Burst-Hook, Hook-Spanne und kleinste letzte-Hook→Token32-Lücke werden offengelegt. Fehlende oder zusammen empfangene Token-16-Batches verhindern eine eindeutig aufgelöste Triggerprüfung und machen den technischen Vergleich ungültig.

## Endpunkte und Statistik

**Primärer zusätzlicher Endpunkt:** je Episode arithmetischer Mittelwert über dieselben V0…V7 von `(Token32-Receipt − eigener Trigger)/10^6` ms. Je Block Burst minus No-Burst. Je Budget Mittelwert der acht gepaarten Blockeffekte mit 95%-CI. Der direkte Budgetkontrast ist die mittlere Repeat-gepaarte Differenz dieser Wirkungen, Budget512 minus Budget2048, ebenfalls mit 95%-CI.

**Sekundär:** analog Token64; maximale ITL je Victim und ihr Blockmittel, sowohl im vollständigen Request als auch bei Intervallen mit Endreceipt nach dem Trigger; volle Token-Fortschrittskurve; absolute Completion ab gemeinsamem Victim-Phasenstart sowie ab HTTP-Hook, jeweils bis Token64; Terminalzeit separat. Ein Intervall, das den Trigger schneidet, gehört zur Post-Trigger-Maximumsdiagnose. Es wird nicht vorab angenommen, dass ein kleineres Budget Gesamtzeit oder Token32-Zeit reduziert.

CI-Regel: exakte nichtparametrische Percentile-Bootstrap-Verteilung über acht ganze Blockwerte. Alle 6.435 Multinomial-Häufigkeitsvektoren erhalten ihre korrekte Wahrscheinlichkeit; inverse gewichtete Verteilungsquantile bei 0,025/0,975. Relative Angaben: geometrisches Mittel der acht Verhältnisse und dieselbe Bootstrap-Regel auf Logskala. Die Intervalle sind punktweise; keine Request-/Token-Pseudoreplikation und keine simultane Absicherung. Acht Paare erlauben nur eine begrenzte Konfigurationsprüfung. Bootstrap-Intervalle aus acht Werten können systematische Fehler und alle Populationstails nicht abdecken; keine nachträgliche Powerbehauptung.

## Prä-Trigger- und Ausgabe-Kontrollen

Alle festen aktiven IDs und Ränge1–16 werden gepaart trigger-relativ verglichen. Pro Block wird die größte absolute Prä-Trigger-Differenz als deskriptive Vergleichshülle ausgewiesen. Eine individuelle konstante Fortsetzung der beobachteten Kadenz8→16 bis Rang32 liefert einen zweiten, ausdrücklich begrenzten Diagnosevergleich; das Alter von Token16 am globalen Trigger bleibt berücksichtigt. Keine dieser Rechnungen ist ein vollständiges Gegenfaktual oder kausale Adjustierung. No-Burst/No-Burst-Paare werden in dieser begrenzten Kampagne nicht ergänzt.

Alle angeforderten Identitäten bleiben in der Hauptanalyse, unabhängig vom generierten Text. Gleiche Prompts/Seeds und maximale Länge werden geprüft. Abweichende gesamte Ausgaben und gemeinsame Ausgabepräfixe werden mit Request-Index und Block ausgewiesen; Ergebniswerte dieser Untergruppen bleiben diagnostisch, weil die Auswahl nach der Ausgabe erfolgt. Kein Entfernen ungünstiger Paare. Bei weniger als vier beitragenden Blöcken kein Untergruppen-CI. Vollständige Rangzeit- und Token-ID-Listen werden erhalten.

## Tatsächliche Budgetwirkung und Instrumentierung

Vollständige `/server_info?config_format=json`-Snapshots vor/nach jeder Episode; bestätigte vLLM-Version, tatsächlicher KV-Pool, Prefix-Caching, Offload-Pfade, Chunking, max_num_seqs und effektives Budget. Rohes 50-ms-Prometheus-Journal mit Idle-Grenzen, Prozessbindung, monotonen Zählern und höchstens250-ms-Scrape-Lücken. Keine fremden Requests oder Zählerresets; exakt acht bzw. zwölf erfolgreiche Requests, 2.048 bzw.10.240 uncached Inputtokens, 512 bzw.576 Outputtokens und null Preemptions.

Vollständiges Byte-Segment der Iterationslogs pro Episode, lückenlose Iterationsnummern und Kontextsumme. Jedes `context_tokens + generation_tokens` muss das Budget einhalten. Da alle Victims vor der Intervention bereits Token16 liefern, sind ihre insgesamt2.048 initialen Kontexttokens vorher abgeschlossen. Die Kontextbilanz muss diese exakte kumulative Grenze aufweisen; danach müssen in Burst-Episoden genau8.192 weitere Kontexttokens vorhanden sein. So wird der Effekt des Zusatzprefills getrennt vom initialen Victim-Prefill geprüft. Diese Zuordnung beruht auf Sequenzordnung, Null-Preemption-/Uncached-Bilanz und aggregierten Logs, nicht auf einer einzelnen Scheduler-Request-ID oder gemessener GPU-Kernelzeit.

Der Budgetvergleich gilt als tatsächlich manipulierter Zusatzprefill nur, wenn in allen acht 512-Bursts budgetnahe Zusatzprefill-Iterationen und in allen acht2048-Bursts Zusatzprefill-Iterationen mit mehr als512 Kontexttokens beobachtet werden, jeweils mit Prefill-/Decode-Überlappung. Andernfalls bleiben die Latenzen gemessen, aber die behauptete unterschiedliche effektive Zusatzprefill-Planung ist nicht bestätigt. Keine Interpretation allein aus CLI-Parametern.

## Ergebnisregeln

| Beobachtung | Einordnung |
|---|---|
| Positiver Token32-Effekt mit 95%-CI oberhalb0, positive Wirkung über Blöcke und weiterhin positiver Rest unter den benannten Kontrollen | Stützt die begrenzte Beobachtung eines frühen klientenseitigen Token-Stalls auch ohne Victim-Semaphore |
| Token32-CI umfasst0 oder Kontrollen erklären die Größenordnung bereits | Schwächt die Zusatzvalidierung; keine Rettung über andere Endpunkte oder Ausschluss von Paaren |
| Token32-CI vollständig ≤0 | Widerspricht einer positiven mittleren Token32-Zusatzzeit in genau der getesteten Konfiguration; kein allgemeiner Nichtexistenzbeweis |
| Budget512−2048 bei Token32 mit CI vollständig<0 / >0 | Evidenz für geringere / höhere gemessene Zusatzzeit unter512; kein vorab erzwungenes Vorzeichen |
| Budgetkontrast umfasst0 | Keine hinreichende Differenz zwischen den Budgets auf dieser Datenbasis |
| Kleinere maximale ITL, aber gleiche oder längere Gesamt-/Token64-Zeit | Begrenzter Trade-off; kleinere Stalls bedeuten nicht automatisch kürzere Completion |
| Delay32/Delay64 ähnlich der historischen hohen Konzentration / deutlich spätere weitere Akkumulation | Stärkt / begrenzt die historische temporale Beschreibung; Werte und Intervalle berichten, keine post hoc gewählte Erfolgsgrenze |
| Fehlender Trigger, falsche IDs/Prompts, unvollständige SSE, fehlende Konfigurations-/Schedulerbelege, fremde Last oder Preemption | Technisch ungültig; keine wissenschaftliche Widerlegung. Rohdaten bleiben, keine Wiederholung/Erweiterung |

Kein Abbruch aufgrund positiver oder negativer Effektgrößen. Abbruch nur bei technischem Fehler, Zeitlimit oder menschlichem Stopp. Die erste ungültige Episode beendet den Lauf; keine automatischen Retries, kein Resume, keine neuen Parameter. Unvollständige Kampagnen erhalten keine acht-Paar-Inferenz.

## Grenzen und Freigabe

Client-Receipts enthalten Transport, Pufferung und Eventloop-Verzögerung. Der HTTPX-Hook beweist keinen Socket-Sende- oder Server-Ankunftszeitpunkt. Iterationslogs erklären aggregiert geplante Arbeit, keine kausale GPU-Zeit. First-Condition-/Compile-/Taktzustand und verbleibende Vor-Trigger-Variation werden nicht durch Randomisierung allein ausgeschlossen.

**Vor den32 GPU-Messepisoden ist anzuhalten.** Auch Startup und Serving-Preflight erfolgen in diesem Paket erst nach dem ausdrücklichen menschlichen GO. Offline-Prüfungen und passive Geräteinventur sind keine Serving-Validierung. Der Plan und alle eingefrorenen Codes/Protokolldateien müssen vor Ausführung hashidentisch zum freigegebenen Paket sein. Es werden keine Arbeiten in DOS2 vorgenommen.

## Explizites technisches Amendment v2 (18.10.2026)

Dieses Amendment ersetzt die bisher zu weite Token16…63-Zulässigkeitsregel. Die wissenschaftliche Triggerdefinition bleibt unverändert: Maximum der acht einzeln empfangenen Token16. Es wird weder auf einen früheren Trigger gewechselt noch werden Victim-Identitäten oder Endpunkte angepasst. Der Plan-SHA bleibt unverändert. Die Implementierungsdateien und dieses Protokoll werden neu eingefroren; die vorherigen Fassungen stehen in final_code_audit/before/.

**Feste Zulässigkeit:** Alle acht Token32-Receipts müssen strikt nach dem logischen Trigger liegen. Beim Eventloop-Beobachter und, in Burst, an jedem tatsächlichen HTTPX-Hook müssen die bereits empfangenen Victim-Zahlen jeweils 16…31 sein. Auch der letzte Burst-Hook muss strikt vor allen acht Token32 liegen. Receipt-Gleichstände an der Grenze sind ungültig. Der Reaudit rekonstruiert die beobachteten Tokenzahlen und Token16-Zeitpunkte unabhängig aus den SSE-Daten. Diese technischen Regeln werden nicht anhand von Latenzeffekten gelockert. Ein Fehler beendet die gesamte Kampagne; es werden keine Ersatzepisoden gesammelt und keine vollständigen Acht-Paar-Intervalle aus Teilkampagnen berechnet. Die Gültigkeit ist eine Bedingung dieses begrenzten Messfensters, kein Beleg für Treatment-Unabhängigkeit jeder späteren Grenzprüfung. Ein praktisch nicht einhaltbares Fenster erfordert einen neuen Bericht und Zustimmung zu einer Triggeränderung.

**Journaling:** Geordnete, auf 4096 Einträge begrenzte Queue; Producer verwendet put_nowait. JSON-Serialisierung, Dateischreiben, Flush und fsync erfolgen im einzelnen Writer-Thread. Synchronisierung nach 64 Datensätzen oder ungefähr 50 ms im Writer sowie an expliziter FIFO-Durabilitätsbarriere und beim Schließen. Die Zeitgrenze ist keine harte Echtzeit- oder Stromausfallgarantie bei blockiertem I/O. Receipt-Zeitstempel entstehen weiterhin vor emit im Client-Empfangspfad. Queue-Überlauf oder Schreibfehler machen den Lauf ungültig, statt im Empfangscallback auf freie Queue zu warten. Bereits angenommene Queue-Einträge werden bei Queue-Überlauf weiter geschrieben, soweit kein physischer Schreibfehler vorliegt. Nach dem emit dürfen referenzierte Felder nicht verändert werden; die aktuellen Call-Sites erfüllen dies. Bei Prozessabsturz können zuletzt gepufferte Einträge fehlen; ein Journal ohne finalen vollständigen Abschluss wird nicht zur Inferenz zugelassen.

Der HTTPX-Request-Hook liegt vor Transport-/Connection-Pool-Eintritt. Er ist keine Socket-Sendezeit, keine Server-Admission und kein Prefill-Beginn. Aufgezeichnet werden die vollständigen vom unveränderten historischen Transport gelieferten SSE-data-Nutzdaten einschließlich Usage/DONE, keine TCP-Pakete, SSE-Kommentare oder rohen HTTP-Bytes. Ein Server kann weiter fortgeschritten sein als der zuletzt verarbeitete Client-Receipt. Die zusätzlichen Fensterprüfungen beziehen sich ausschließlich auf Client-Beobachtungen.

**Weitere technische Korrekturen:** Task-Erstellungstimestamps werden vor create_task erfasst. Invalidierte Teil-Episoden mit finalem Fehlerbericht bleiben diagnostisch erneut lesbar. Der Raw-Validator prüft Finish-/Usage-Kardinalität, Event-Indizes und Terminalreihenfolge; Journalkopien werden gegengeprüft. Fehler beim Client-Schließen überspringen weder das Beenden des eigenen Servers noch die Zusammenfassung. Aufräumfehler werden explizit gespeichert und beenden den Lauf. Die Kampagne speichert zusätzlich den Manifesthash und tatsächliche Python-Codehashes.

Offline-Belastungstests begründen eine geringere Schreiblast; sie beweisen weder fehlende GPU-Interferenz noch deren Symmetrie. Iterationslogging, Metrikabfragen, JSON-Verarbeitung, Thread-/GIL-Konkurrenz und Transportpufferung bleiben beobachtungsrelevante Kosten. Die Messung gilt für die konfigurierte instrumentierte Umgebung.
