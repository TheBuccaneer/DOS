"""Durable raw journaling, continuous metrics and receipt/send timestamps."""
import asyncio
import json
import os
from pathlib import Path
import queue
import threading
import time
from types import SimpleNamespace
from urllib.parse import urlsplit

from design import require


def local_url(base_url):
    u=urlsplit(base_url)
    require(u.scheme=='http' and u.hostname=='127.0.0.1' and u.port is not None and
            1<=u.port<=65535 and not u.username and not u.password and
            u.path in ('','/') and not u.query and not u.fragment,'explicit loopback HTTP URL required')
    return base_url.rstrip('/')


class Journal:
    """Ordered, bounded, nonblocking producer; batched durability in one worker.

    A row owns its referenced fields after emit: callers must not mutate them.
    SSE strings/integers are immutable; request results are emitted after completion.
    Receipt timestamps are captured by Tap before emit, never by the writer.
    flush() is a FIFO durability barrier; close() is only used outside measurement.
    """
    BATCH_RECORDS=64
    SYNC_INTERVAL_S=.05

    def __init__(self,path):
        self.file=Path(path).open('x',encoding='utf-8')
        self.queue=queue.Queue(maxsize=4096)
        self.sequence=0;self.error=None;self.closed=False
        self.stats=dict(enqueued=0,written=0,fsync_calls=0,queue_high_water=0)
        self.thread=threading.Thread(target=self._write,daemon=True)
        self.thread.start()

    def _write(self):
        dirty=0;last_sync=time.monotonic();write_failed=False
        def sync():
            nonlocal dirty,last_sync
            if dirty:
                self.file.flush();os.fsync(self.file.fileno())
                self.stats['fsync_calls']+=1;dirty=0
            last_sync=time.monotonic()
        while True:
            try:row=self.queue.get(timeout=max(.001,self.SYNC_INTERVAL_S-(time.monotonic()-last_sync)))
            except queue.Empty:
                try:
                    if not write_failed:sync()
                except Exception as exc:self.error=type(exc).__name__;write_failed=True
                continue
            try:
                if row is None:
                    if not write_failed:sync()
                    return
                if isinstance(row,threading.Event):
                    if not write_failed:sync()
                    row.set()
                elif not write_failed:
                    self.file.write(json.dumps(row,allow_nan=False)+'\n')
                    dirty+=1;self.stats['written']+=1
                    if dirty>=self.BATCH_RECORDS or time.monotonic()-last_sync>=self.SYNC_INTERVAL_S:sync()
            except Exception as exc:
                self.error=type(exc).__name__;write_failed=True
                if isinstance(row,threading.Event):row.set()
            finally:self.queue.task_done()

    def emit(self,kind,**fields):
        require(not self.closed and self.error is None,'journal unavailable: '+str(self.error))
        row=dict(record_type=kind,journal_seq=self.sequence,perf_counter_ns=time.perf_counter_ns(),
                 wall_time_ns=time.time_ns(),**fields)
        try:self.queue.put_nowait(row)
        except queue.Full:
            self.error='QueueFull'
            raise ValueError('journal queue full; episode invalid, queued records retained')
        self.sequence+=1;self.stats['enqueued']+=1
        self.stats['queue_high_water']=max(self.stats['queue_high_water'],self.queue.qsize())

    async def flush(self):
        require(not self.closed,'journal closed')
        barrier=threading.Event()
        while True:
            try:self.queue.put_nowait(barrier);break
            except queue.Full:
                require(self.thread.is_alive(),'journal worker terminated')
                await asyncio.sleep(.001)
        while not barrier.is_set():
            require(self.thread.is_alive(),'journal worker terminated')
            await asyncio.sleep(.001)
        require(self.error is None,'journal persistence failure: '+str(self.error))

    def close(self):
        if not self.closed:
            self.closed=True
            self.queue.put(None,timeout=10)
            self.thread.join(timeout=10)
            require(not self.thread.is_alive(),'journal worker shutdown timeout; file retained')
            self.file.close()
        require(self.error is None,'journal persistence failure: '+str(self.error))


class Sampler:
    def __init__(self,transport,url,journal,api_key,interval=.05):
        self.transport,self.url,self.journal=transport,url,journal
        self.headers={'Authorization':'Bearer '+api_key}
        self.interval=interval
        self.samples=[]
        self.stop_event=asyncio.Event()
        self.task=None

    async def sample(self):
        row=dict(scrape_start_ns=time.perf_counter_ns(),http_status=None,raw_body=None,error=None)
        try:
            row['http_status'],row['raw_body']=await self.transport.get_json(self.url,self.headers,2)
            if row['http_status']!=200: row['error']='http_error'
        except Exception as exc: row['error']=type(exc).__name__
        row['response_ns']=time.perf_counter_ns()
        self.samples.append(row)
        self.journal.emit('metrics_sample',sample=row)
        return row

    def start(self):
        async def loop():
            while not self.stop_event.is_set():
                await self.sample()
                try: await asyncio.wait_for(self.stop_event.wait(),self.interval)
                except asyncio.TimeoutError: pass
        self.task=asyncio.create_task(loop())

    async def stop(self):
        self.stop_event.set()
        if self.task is not None: await self.task


async def sleep_until(deadline,*,now=time.perf_counter_ns,sleep=asyncio.sleep):
    while True:
        remaining=(deadline-now())/1e9
        if remaining<=0: return
        await sleep(remaining)


class ReceiptClock:
    def __init__(self,base):
        self.base,self.receipt=base,None
    def utcnow_iso(self): return self.base.utcnow_iso()
    def perf_counter_ns(self):
        if self.receipt is None: return time.perf_counter_ns()
        value,self.receipt=self.receipt,None
        return value


class Tap:
    def __init__(self,transport,plan,role,journal,clock,deadline_ns):
        self.transport,self.plan,self.role=transport,plan,role
        self.journal,self.clock,self.deadline_ns=journal,clock,deadline_ns
        self.dispatch_ns,self.payload=None,None
        self.semantics='fake_transport_entry'

    def sent(self,stamp):
        require(self.dispatch_ns is None,'duplicate HTTP dispatch')
        self.dispatch_ns,self.semantics=stamp,'httpx_request_hook'

    async def stream_completion(self,url,headers,payload,timeout_s,*,request_id=None):
        role,plan=self.role,self.plan
        require(payload['prompt']==plan['prompts'][role] and
                payload['max_tokens']==payload['min_tokens']==plan['outputs'][role] and
                payload['seed']==plan['seeds'][role] and payload['temperature']==0 and
                request_id==plan['request_ids'][role],'wire request differs from plan')
        self.payload=payload
        self.journal.emit('request_wire',role=role,request_id=request_id,payload=payload,
                          scheduled_dispatch_ns=self.deadline_ns)
        hooks=getattr(self.transport,'send_hooks',None)
        if hooks is not None: hooks[request_id]=self.sent
        else:
            self.sent(time.perf_counter_ns())
            self.semantics='fake_transport_entry'
        stream=self.transport.stream_completion(url,dict(headers,**{'X-Request-ID':request_id}),
                                                payload,timeout_s,request_id=request_id)
        try:
            index=0
            async for raw in stream:
                received=time.perf_counter_ns()
                require(self.dispatch_ns is not None,'missing outbound HTTP timestamp')
                self.journal.emit('sse_wire',role=role,request_id=request_id,event_index=index,
                    raw_data=raw,receive_ns=received,send_ns=self.dispatch_ns)
                self.clock.receipt=received
                yield raw
                index+=1
        finally:
            await stream.aclose()
            if hooks is not None: hooks.pop(request_id,None)


async def shared_httpx_transport(base):
    """Reuse original HttpxTransport methods with one pool and per-call timeouts.

    This avoids constructing SSL/client state separately at each burst dispatch.
    The original executor and its SSE parsing remain unchanged.
    """
    transport=base.HttpxTransport()
    module=transport._httpx
    transport.send_hooks={}
    async def hook(request):
        if request.url.path=='/v1/completions':
            request_id=request.headers.get('X-Request-ID')
            require(request_id in transport.send_hooks,'undeclared HTTP request')
            transport.send_hooks[request_id](time.perf_counter_ns())
    client=module.AsyncClient(trust_env=False,follow_redirects=False,
                              limits=module.Limits(max_connections=16,max_keepalive_connections=16),
                              event_hooks={'request':[hook]})
    class Proxy:
        def __init__(self,timeout): self.timeout=timeout
        async def get(self,url,**kwargs):
            return await client.get(url,timeout=self.timeout,**kwargs)
        def stream(self,*args,**kwargs):
            return client.stream(*args,timeout=self.timeout,**kwargs)
    class Scope:
        def __init__(self,timeout): self.proxy=Proxy(timeout)
        async def __aenter__(self): return self.proxy
        async def __aexit__(self,*args): return False
    transport._httpx=SimpleNamespace(AsyncClient=Scope)
    transport.close=client.aclose
    return transport
