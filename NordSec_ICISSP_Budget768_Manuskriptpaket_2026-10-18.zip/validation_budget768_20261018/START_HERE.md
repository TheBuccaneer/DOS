# NordSec: Budget768 abgeschlossen

**16/16 neue Episoden,8/8 Paare gültig. Kein weiterer Messlauf.**

- ANALYSEBERICHT.md: wissenschaftliche Antworten aufF1…F4 und Grenzen.
- TECHNISCHER_AUDITBERICHT.md: Raw-/Konfigurations-/Herkunftsnachweise.
- MANUSCRIPT_TABLE.md und MANUSCRIPT_RESULTS.md: direkt verwendbare Tabellen und englischer Ergebnisbaustein.
- figures/budget768_validation.pdf / .png / .svg und FIGURE_CAPTION.md.
- analysis/three_budget_results/: vollständige Ergebnis-CSVs für alle drei Budgets und Kontraste.
- audit/: eigenständiger Post-Audit, Request-/Hook-/Sequenzlisten und Konfigurationsdifferenzen.
- evidence/: Vorab-Gate, ursprüngliche29 und ergänzende5 Tests, Dry-Run, Code-/Datenherkunft.
- plan.json, PROTOCOL.md, FROZEN_FILES_SHA256.json: unveränderte vorab eingefrorene768-Spezifikation.
- serving_campaign_768/: sämtliche neuen Raw-Journale und Serverlogs (im Vollpaket).

Ergebnis: Bei50/100 ms bevorzugt die Häufigkeitsmetrik größere Budgets, die aufsummierte Überschreitung kleinere.768 zeigt den Konflikt ohne exakte Teilbarkeit;25 ms liefert keine universelle Umkehr. Token32-/64-Zeit ist nicht monoton. Der historische negative Offload×Burst-Primärbefund bleibt unverändert.

Für vollständige Wiederholung der Raw-Auswertung werden die im Manifest bezeichneten bisherigen32 Journale und historischen Promptquellen der lokalen Work-Umgebung benötigt. Sie sind im Übergabepaket nicht dupliziert; verarbeitetes Vergleichsmaterial, Herkunft, alle neuen Rohdaten im Vollpaket und sämtliche Skripte sind enthalten. Modellgewichte und Zugangsschlüssel sind nicht enthalten. Das kompakte Manuskriptpaket enthält keine Raw-Journale, aber alle Berichte, Tabellen, Abbildungen, Code und Auditbelege.
