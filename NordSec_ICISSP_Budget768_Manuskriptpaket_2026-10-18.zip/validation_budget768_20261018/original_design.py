"""Frozen 32-episode validation design; no GPU imports or serving requests."""
import hashlib,importlib.util,json,os,random,sys
from pathlib import Path

REPO=Path('/home/rock/projects/DOS')
EXECUTOR=REPO/'new/scripts/prefill_confirmation/run_prefill_confirmation.py'
EXECUTOR_SHA='981aba99aff820ea8fea3bef6df0e1e8bfb127df059695d4736d7702ef300b75'
MODEL='meta-llama/Llama-3.1-8B-Instruct'
MODEL_PATH=Path('/home/rock/.cache/huggingface/hub/models--meta-llama--Llama-3.1-8B-Instruct/snapshots/0e9e39f249a16976918f6564b8830bc894c89659')
SETTINGS=dict(model=MODEL,model_snapshot=str(MODEL_PATH),vllm='0.17.1',cpu_offload_gb=0,max_model_len=8192,max_num_seqs=16,
    block_size=16,num_gpu_blocks=1024,prefix_caching=False,chunked_prefill=True,server_seed=20260711,
    dtype='bfloat16',gpu_memory_utilization=.9,trigger_tokens=16,request_timeout_s=60,
    trigger_timeout_s=30,episode_timeout_s=120,startup_timeout_s=180,campaign_timeout_s=5400,
    metrics_interval_s=.05,max_metrics_gap_ms=250,host='127.0.0.1',port=8028)

def require(ok,message):
    if not ok:raise ValueError(message)
def sha(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def file_sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def load_executor():
    require(file_sha(EXECUTOR)==EXECUTOR_SHA,'historical executor hash mismatch')
    spec=importlib.util.spec_from_file_location('frozen_nordsec_executor',EXECUTOR)
    module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module
    sys.dont_write_bytecode=True;spec.loader.exec_module(module);return module

def prepare():
    blocks=[];sources=[];first=list(range(1,9));random.Random(20261018).shuffle(first)
    first=set(first[:4])
    for repeat in range(1,9):
        source=REPO/'new/runs/prefill_confirmation/llama/results/official_initial8_20260717T083031Z/episodes'/f'llama_off0_conc8_trigger16_prefill_burst_rep{repeat:02d}.json'
        old=json.loads(source.read_text());sources.append(dict(path=str(source),sha256=file_sha(source)))
        requests={f'V{i}':r for i,r in enumerate(old['victim_requests'][:8])}
        requests.update({f'E{i}':r for i,r in enumerate(old['burst_requests'])})
        budgets=[512,2048] if repeat%2 else [2048,512]
        for budget in budgets:
            burst_first=(repeat in first) if budget==512 else (repeat not in first)
            conditions=['burst','no_burst'] if burst_first else ['no_burst','burst']
            bid=f'validation-b{budget}-r{repeat:02d}';episodes=[]
            for order,condition in enumerate(conditions,1):
                eid=bid+'-'+condition;roles=[f'V{i}' for i in range(8)]+([f'E{i}' for i in range(4)] if condition=='burst' else [])
                episodes.append(dict(episode_id=eid,block_id=bid,budget=budget,repeat=repeat,
                    condition=condition,order_in_block=order,
                    prompts={role:requests[role]['prompt_token_ids_sent'] for role in roles},
                    seeds={role:requests[role]['generation_seed'] for role in roles},
                    prompt_seeds={role:requests[role]['prompt_seed'] for role in roles},
                    prompt_hashes={role:requests[role]['prompt_sha256'] for role in roles},
                    outputs={role:64 if role.startswith('V') else 16 for role in roles},
                    request_ids={role:eid+':'+role for role in roles}))
            blocks.append(dict(block_id=bid,budget=budget,repeat=repeat,episodes=episodes))
    return dict(schema='nordsec-validation-v1',master_seed=20261018,settings=SETTINGS,
        historical_executor_sha256=EXECUTOR_SHA,historical_inputs=sources,blocks=blocks,
        serving_episodes=32,completion_requests=320,input_tokens=196608,output_tokens=17408,
        extra_warmup_requests=0,primary='mean_V0_to_V7(receipt_token32 - own_trigger)',
        independent_unit='paired_block',retries=0,resume=False,requires_explicit_user_go=True)

def validate(plan):
    require(plan==prepare(),'plan differs from frozen design or historical prompt sources')
    return plan

def server_command(budget):
    require(budget in (512,2048),'unsupported budget')
    return [sys.executable,'-B','-m','vllm.entrypoints.cli.main','serve',str(MODEL_PATH),
        '--served-model-name',MODEL,'--host','127.0.0.1','--port','8028',
        '--dtype','bfloat16','--generation-config','vllm','--gpu-memory-utilization','0.90',
        '--tensor-parallel-size','1','--max-model-len','8192','--cpu-offload-gb','0',
        '--no-enable-prefix-caching','--enable-chunked-prefill','--max-num-batched-tokens',str(budget),
        '--max-num-seqs','16','--max-num-partial-prefills','1','--max-long-partial-prefills','1',
        '--long-prefill-token-threshold','0','--block-size','16','--num-gpu-blocks-override','1024',
        '--enable-logging-iteration-details','--seed','20260711']

if __name__=='__main__':
    path=Path(__file__).parent/'plan.json'
    with path.open('x') as f:json.dump(prepare(),f,indent=2)
    print(sha(json.loads(path.read_text())))
