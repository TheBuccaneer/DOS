"""Frozen three-budget analysis; raw re-read only, fixed8 blocks per budget."""
import argparse,csv,json,math,statistics
from pathlib import Path
from design import ROOT,BASELINE,require,sha,validate
from verify import read_episode,token_stream,ITERATION
from reference_code.analyze_campaign import ci

TARGETS=[25,50,100]

def write_csv(path,rows):
    if not rows:return
    with Path(path).open('x',newline='') as f:
        w=csv.DictWriter(f,list(rows[0]));w.writeheader();w.writerows(rows)

def measures(stream,trigger):
    t=stream['times'];itls=[(b-a)/1e6 for a,b in zip(t,t[1:]) if b>trigger]
    out=dict(token32_ms=(t[31]-trigger)/1e6,token64_ms=(t[63]-trigger)/1e6,
        token32_to64_ms=(t[63]-t[31])/1e6,max_post_itl_ms=max(itls),
        pre8_cadence_ms=(t[15]-t[7])/8e6,age16_ms=(trigger-t[15])/1e6,
        n_post_intervals=len(itls))
    for d in TARGETS:
        out[f'count_above_{d}ms']=sum(v>d for v in itls)
        out[f'excess_above_{d}ms']=sum(max(v-d,0) for v in itls)
    return out

def load(campaign):
    summary=json.loads((campaign/'campaign_summary.json').read_text());plan=json.loads((campaign/'plan.json').read_text())
    require(not summary['error'] and not summary['not_completed'],'incomplete campaign; no complete inference')
    require(summary['plan_sha256']==sha(plan),'campaign plan mismatch')
    data={};audit=[];iterations=[]
    for block in plan['blocks']:
        for ep in block['episodes']:
            path=campaign/block['block_id']/(ep['episode_id']+'.jsonl');e,a=read_episode(path)
            require(a['measurement_valid'] and e['origin']=='serving' and e['plan']==ep,'invalid raw episode')
            with (path.parent/'server.log').open('rb') as f:
                f.seek(e['log_byte_start']);segment=f.read(e['log_byte_end']-e['log_byte_start'])
            require(segment.decode()==e['iteration_log'],'server log segment differs')
            data[ep['budget'],ep['repeat'],ep['condition']]=(e,a)
            audit.append(dict(budget=ep['budget'],repeat=ep['repeat'],condition=ep['condition'],
                requests=len(e['requests']),sse_events=sum(len(r['raw_sse_events']) for r in e['requests'].values()),
                output_tokens=sum(len(r['output_token_ids']) for r in e['requests'].values()),
                min_hook_to_token32_ms=a['measurement_window'].get('min_last_burst_hook_to_token32_ms'),
                trigger_to_observer_ms=a['measurement_window']['trigger_to_observer_ms'],
                **a['scheduler']))
            context=0;initial_done=False
            for line in e['iteration_log'].splitlines():
                if 'Iteration(' not in line:continue
                m=ITERATION.search(line);require(m is not None,'bad iteration')
                i,c_req,c_tok,d_req,d_tok=map(int,m.groups()[:5])
                additional=initial_done
                iterations.append(dict(budget=ep['budget'],repeat=ep['repeat'],condition=ep['condition'],
                    iteration=i,context_requests=c_req,context_tokens=c_tok,decode_requests=d_req,decode_tokens=d_tok,
                    additional_context_phase=additional,elapsed_log_ms=float(m[6])))
                context+=c_tok
                if context==2048:initial_done=True
    return data,audit,iterations

def analyze(campaign768,out,baseline_only=False):
    out=Path(out);out.mkdir(exist_ok=False)
    data,audit,iterations=load(BASELINE/'serving_campaign_20261018')
    if not baseline_only:
        validate(json.loads((campaign768/'plan.json').read_text()))
        new,aa,ii=load(campaign768);data.update(new);audit+=aa;iterations+=ii
    budgets=[512,2048] if baseline_only else [512,768,2048]
    require(len(data)==len(budgets)*16,'episode cardinality')
    requests=[];blocks=[];curves=[];identities=[];prefill=[]
    for budget in budgets:
        for repeat in range(1,9):
            a,aa=data[budget,repeat,'no_burst'];b,bb=data[budget,repeat,'burst']
            # Across budgets every offered prompt/seed/profile must match512.
            for condition,e in [('no_burst',a),('burst',b)]:
                reference=data[512,repeat,condition][0]
                for key in ['prompts','prompt_seeds','seeds','prompt_hashes','outputs']:
                    require(e['plan'][key]==reference['plan'][key],'offered workload differs '+key)
                identities.append(dict(budget=budget,repeat=repeat,condition=condition,matched_offered_workload=True,
                    offered_prompt_tokens=sum(map(len,e['plan']['prompts'].values())),gpu_work_identity_claimed=False))
            row=dict(budget=budget,repeat=repeat);rr=[];delta_curves=[]
            for i in range(8):
                role=f'V{i}';sa=token_stream(a['requests'][role],a['plan']['prompts'][role],64)
                sb=token_stream(b['requests'][role],b['plan']['prompts'][role],64)
                require(a['plan']['prompts'][role]==b['plan']['prompts'][role] and a['plan']['seeds'][role]==b['plan']['seeds'][role],'within-pair identity')
                ta,tb=a['trigger']['trigger_ns'],b['trigger']['trigger_ns'];ma,mb=measures(sa,ta),measures(sb,tb)
                prefix=next((j for j,(x,y) in enumerate(zip(sa['ids'],sb['ids'])) if x!=y),64)
                delta=[((y-tb)-(x-ta))/1e6 for x,y in zip(sa['times'],sb['times'])]
                r=dict(budget=budget,repeat=repeat,request_index=i,output_equal=prefix==64,common_prefix_tokens=prefix,
                    no_burst_post_intervals=ma['n_post_intervals'],burst_post_intervals=mb['n_post_intervals'])
                for k in ma:
                    if k=='n_post_intervals':continue
                    r[k+'_no_burst']=ma[k];r[k+'_burst']=mb[k];r[k+'_delta']=mb[k]-ma[k]
                r['pre8_forecast_residual32_ms']=delta[31]-(16*(mb['pre8_cadence_ms']-ma['pre8_cadence_ms'])-(mb['age16_ms']-ma['age16_ms']))
                r['pre_envelope_ms']=max(abs(x) for x in delta[:16])
                requests.append(r);rr.append(r);delta_curves.append(delta)
            metrics=[k for k in rr[0] if k.endswith('_delta')]+['pre8_forecast_residual32_ms']
            for metric in metrics:row[metric]=statistics.fmean(r[metric] for r in rr)
            row['pre_envelope_max_ms']=max(r['pre_envelope_ms'] for r in rr)
            row['delta32_minus_pre_envelope_ms']=row['token32_ms_delta']-row['pre_envelope_max_ms']
            row['output_different_requests']=sum(not r['output_equal'] for r in rr)
            blocks.append(row)
            for k in range(64):curves.append(dict(budget=budget,repeat=repeat,token_rank=k+1,delta_ms=statistics.fmean(d[k] for d in delta_curves)))
            extra=[r for r in iterations if r['budget']==budget and r['repeat']==repeat and r['condition']=='burst' and r['additional_context_phase'] and r['context_tokens']>0]
            require(sum(r['context_tokens'] for r in extra)==8192,'extra context total')
            prefill.append(dict(budget=budget,repeat=repeat,additional_context_iterations=len(extra),
                context_tokens=[r['context_tokens'] for r in extra],context_request_counts=[r['context_requests'] for r in extra],
                decode_token_counts=[r['decode_tokens'] for r in extra],
                iterations_with_multiple_context_requests=sum(r['context_requests']>1 for r in extra),
                max_additional_context_tokens=max(r['context_tokens'] for r in extra),
                pure_global_ceil=math.ceil(8192/budget),pure_per_request_ceil=4*math.ceil(2048/budget),
                individual_request_ids_available=False))
    effects=[];contrast=[];subgroups=[];curve_ci=[]
    metrics=[k for k in blocks[0] if k.endswith('_delta')]+['pre8_forecast_residual32_ms','delta32_minus_pre_envelope_ms','pre_envelope_max_ms']
    indexed={(r['budget'],r['repeat']):r for r in blocks}
    for budget in budgets:
        for metric in metrics:effects.append(dict(budget=budget,metric=metric,**ci([indexed[budget,r][metric] for r in range(1,9)])))
        for rank in range(1,65):curve_ci.append(dict(budget=budget,token_rank=rank,**ci([r['delta_ms'] for r in curves if r['budget']==budget and r['token_rank']==rank])))
        for group,choose in [('identical_sequence',lambda r:r['output_equal']),('different_sequence',lambda r:not r['output_equal']),('identical_through32',lambda r:r['common_prefix_tokens']>=32)]:
            chosen=[r for r in requests if r['budget']==budget and choose(r)]
            for metric in [m for m in metrics if m.endswith('_delta')]+['pre8_forecast_residual32_ms']:
                values=[statistics.fmean(r[metric] for r in chosen if r['repeat']==repeat) for repeat in range(1,9) if any(r['repeat']==repeat for r in chosen)]
                subgroups.append(dict(budget=budget,subgroup=group,metric=metric,n_requests=len(chosen),**ci(values,False)))
    pairs=[(512,2048)] if baseline_only else [(768,512),(768,2048),(512,2048)]
    for x,y in pairs:
        for metric in metrics:contrast.append(dict(contrast=f'{x}_minus_{y}',metric=metric,**ci([indexed[x,r][metric]-indexed[y,r][metric] for r in range(1,9)])))
    for name,rows in [('episode_audit.csv',audit),('scheduler_iterations.csv',iterations),('matched_workload.csv',identities),('request_effects.csv',requests),
        ('paired_block_effects.csv',blocks),('effect_intervals.csv',effects),('budget_contrasts.csv',contrast),('sequence_sensitivity.csv',subgroups),
        ('paired_progress_curves.csv',curves),('progress_curve_intervals.csv',curve_ci),('additional_prefill_structure.csv',prefill)]:write_csv(out/name,rows)
    (out/'summary.json').write_text(json.dumps(dict(budgets=budgets,valid_episodes=len(data),paired_blocks=len(blocks),
        matched_offered_workload_verified=True,equal_gpu_computation_claimed=False,negative_historical_primary_unchanged=True,
        retrospective_extension=True,pointwise_exact_percentile_block_bootstrap=True,blocks_independent_unit=8,
        later768_session_is_potential_confound=True,effects=effects,contrasts=contrast),indent=2)+'\n')
    print(json.dumps(dict(out=str(out),budgets=budgets,episodes=len(data))))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--campaign768',type=Path,default=ROOT/'serving_campaign_768')
    p.add_argument('--out',type=Path,required=True);p.add_argument('--baseline-only',action='store_true');a=p.parse_args()
    analyze(a.campaign768,a.out,a.baseline_only)
