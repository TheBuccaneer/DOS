# Budget768: letzte gezielte NordSec-Ergänzung

USER_REQUEST.md autorisiert genau16 neue Episoden nach bestandenem Gate. Phase-A-Belege und Offline-Tests in evidence/. plan.json und PROTOCOL.md werden vor Messbeginn gehasht. Originale32 Episoden werden ausschließlich gelesen. Runtime ist die bestehende reparierte Python3.13-Umgebung.

Quellenkopien in reference_code/ dienen unveränderten Regressionstests; deren temporäre Dateien bleiben ausschließlich in diesem neuen Ordner. `original_design.py` ist eine unveränderte Kopie des ursprünglichen Planerzeugers; der neue design.py leitet genau die8 gespeicherten512-Blöcke zu768 ab. instrument.py/verify.py/wire_checks.py sind bytegleich übernommen. collect.py ändert nur berichtete Kampagnengröße, Dry-Run-Budget und zusätzliche vorab festgelegte768-Manipulationsprüfung; Mess- und Triggerpfade bleiben unverändert.

analyze_three.py liest alle Rohjournale erneut, prüft Serverlog-Bytes, erzeugt Blockeffekte/CI, vollständige Fortschrittskurve, Deadline-Auswertungen und Output-/Prä-Kontrollen. Die vorhandenen Logs liefern aggregierte Iterationsstruktur, keine Request-ID-Zerlegung. Die später gemessene768-Sitzung bleibt ein möglicher Konfundierer direkter Budgetkontraste.
