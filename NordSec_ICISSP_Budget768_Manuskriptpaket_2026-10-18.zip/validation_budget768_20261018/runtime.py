#!/usr/bin/env python3
"""Use the existing repaired environment directly; no package/environment edits."""
import importlib.metadata,json,os,runpy,sys
from pathlib import Path
from design import PYTHON,require
require(sys.version_info[:3]==(3,13,7),'Python3.13.7 required')
require(Path(sys.prefix).resolve()==PYTHON.parent.parent.resolve(),'use repaired environment')
sys.dont_write_bytecode=True
os.environ['PYTHONDONTWRITEBYTECODE']='1'
if len(sys.argv)>1 and sys.argv[1]=='--metadata-only':
    print(json.dumps(dict(executable=sys.executable,prefix=sys.prefix,version=sys.version,
        packages={n:importlib.metadata.version(n) for n in ['vllm','torch','httpx','transformers']}),indent=2))
else:
    script=Path(__file__).parent/'collect.py';sys.argv=[str(script)]+sys.argv[1:]
    runpy.run_path(str(script),run_name='__main__')
