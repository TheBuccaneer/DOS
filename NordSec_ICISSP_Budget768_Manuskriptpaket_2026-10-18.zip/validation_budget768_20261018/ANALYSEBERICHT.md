# Wissenschaftliche Auswertung: nichtteilendes Budget768

## 1. Ergebnis und Einordnung

Die zusätzliche Kampagne ist vollständig auditiert:16 Episoden,8 Paare, unveränderte technische Gültigkeitsregeln, kein Ausschluss oder Ersatz. Das nichtteilende768-Budget reproduziert den Konflikt zwischen Deadline-Häufigkeit und aufsummierter Überschreitungshöhe bei50 und100 ms. Exakte Teilbarkeit der2048er Prompts bzw.8192er angebotenen Burstlast ist damit **keine notwendige Bedingung** dieser Beobachtung in der getesteten Konfiguration.

Dies ist eine gezielte, vor ihrem Messlauf spezifizierte retrospektive Erweiterung. Keine neue historische Primäranalyse; ursprünglicher nicht robuster Offload×Burst-Befund und genau zwei Reviews−1/0 bleiben unverändert. Kein neues Schedulinggesetz, keine universelle Deadline-Rangordnung.

## 2. Definitionen und Statistik

Je Episode arithmetischer Mittelwert über identitätsfesteV0…V7, dann Burst−No-Burst je vollständigem Block. Je Budget Mittel über8 Blöcke. Counts sind pro Victim, nicht über8 Victims aufsummiert. Post-Trigger-ITLs haben einen rechten Receipt nach dem eigenen Trigger; ein triggerübergreifendes Intervall ist enthalten. A=count(ITL>d), B=sum(max(ITL−d,0)); beide nutzen dieselben Intervalle und Populationen. Die tatsächlich gefilterten Intervallzahlen je Request bleiben dokumentiert.

95%-CI: identisches exaktes Percentile-Bootstrap mit allen6435 multinomial gewichteten Achtblock-Häufigkeitsvektoren. Direkte Budgetkontraste paaren die Burst-Effekte anhand Repeat1…8. Keine Token-/Request-Pseudoreplikation. Alle CIs punktweise und ohne Multiplikitätsabsicherung. Degenerierte Counts erzeugen degenerierte empirische CIs; dies ist keine Populationsgarantie.25/50/100 ms sind die vom Auftrag vorgegebenen diagnostischen Zielwerte, keine nachträglich optimierten SLOs und keine vollständige Etalon-Fluidity-Auswertung.

## 3. F2: Token-Fortschritt

| Paired endpoint effect (ms) | Budget512 | Budget768 | Budget2048 |
|---|---:|---:|---:|
| Trigger → token32 | 1294.4 [1279.2, 1310.0] | 1776.4 [1770.1, 1783.5] | 1727.7 [1715.0, 1741.0] |
| Token32 → token64 | 461.1 [452.4, 474.6] | 38.4 [30.1, 47.0] | 16.4 [7.1, 26.0] |
| Trigger → token64 | 1755.5 [1743.6, 1767.5] | 1814.8 [1803.5, 1828.5] | 1744.1 [1732.7, 1755.7] |
| Maximum post-trigger ITL | 109.4 [107.6, 111.2] | 167.3 [166.2, 168.5] | 434.3 [431.1, 437.5] |

Bis Token32 sind bei768 deskriptiv97,9% der mittleren Zusatzzeit bis64 akkumuliert (Verhältnis der beiden mittleren Effekte, kein zusätzliches CI). Dennoch bleiben38,4 ms [30,1;47,0] weitere Akkumulation nach32.512 akkumuliert wesentlich mehr nach32;2048 fast alles vorher. Die maximale Post-Trigger-ITL liegt bei768 zwischen den bisherigen Armen.

Die absolute Zusatzzeit ist **nicht monoton im Budget**:768−512 beträgt+482,0 ms [464,7;498,5] bis32 und+59,3 ms [42,2;79,6] bis64;768−2048 beträgt+48,7 ms [36,8;59,4] bzw.+70,7 ms [57,5;83,1]. Die später gemessene768-Sitzung und budgetabhängige Kompilierungsbereiche begrenzen die Interpretation als isolierter Scheduler-Effekt. Ein kleinerer einzelner Stall garantiert weder einen früheren Token32-Empfang noch eine kürzere Gesamtzeit.

## 4. F3: Deadline-Bewertung

| Target(ms) | Budget | Additional intervals/victim | Additional excess(ms/victim) |
|---:|---:|---:|---:|
| 25 | 512 | 18.38 [18.00, 18.88] | 1670.2 [1652.5, 1686.0] |
| 25 | 768 | 16.34 [14.08, 18.67] | 1748.1 [1742.6, 1753.6] |
| 25 | 2048 | 5.38 [4.62, 6.09] | 1692.9 [1676.1, 1710.3] |
| 50 | 512 | 17.00 [17.00, 17.00] | 1241.7 [1223.2, 1257.9] |
| 50 | 768 | 11.00 [11.00, 11.00] | 1466.1 [1461.9, 1471.1] |
| 50 | 2048 | 4.00 [4.00, 4.00] | 1590.7 [1573.4, 1609.0] |
| 100 | 512 | 16.00 [16.00, 16.00] | 432.2 [413.9, 448.4] |
| 100 | 768 | 11.00 [11.00, 11.00] | 916.1 [911.9, 921.1] |
| 100 | 2048 | 4.00 [4.00, 4.00] | 1390.7 [1373.4, 1409.0] |

Bei100 ms: Count16→11→4, während Excess432,2→916,1→1390,7 ms mit wachsendem Budget steigt. Bei50 ms entsprechend17→11→4 und1241,7→1466,1→1590,7 ms. Die benachbarten direkten Kontraste haben hier jeweils entgegengesetzte, vom Nullwert getrennte Richtungen für Count und Excess. Bei100 ms sind768−512: Count−5, Excess+483,9 ms [469,0;501,5];768−2048: Count+7, Excess−474,6 ms [−495,6;−455,9].

**Gegenbefund bei25 ms:** Count bevorzugt2048 gegenüber768, aber auch Excess ist unter2048 geringer:768−2048 Count+10,97 [8,94;13,09], Excess+55,1 ms [33,2;74,9]. Zwischen512 und768 schließt das Count-CI0 ein; zwischen512 und2048 schließt das Excess-CI0 ein. Eine bei allen Deadlines statistisch abgesicherte vollständige Umkehr wäre daher falsch. Der768-Arm ist bei25 ms nach beiden Metriken schlechter als2048.

Alle Kontraste, auch25 ms und sämtliche Tokenendpunkte, stehen vollständig in budget_contrasts.csv. Kein Schwellenwert oder Repeat wurde aufgrund eines gewünschten Vorzeichens ausgesucht.

## 5. F1: Scheduler und mechanistische Alternativen

Die aggregierten Zusatz-Kontextiterationenzahlen lauten in allen8 Repeats17/11/5 für512/768/2048. Die idealen globalen Quotienten wären16/11/4, die pro Request aufgerundete Addition16/12/4. Die768-Kontexttrajektorie summiert sich exakt zu8192 und enthält drei Iterationen mit zwei Kontextrequests; Kontext und Decode teilen das reale Budget. Eine Annahme von12 exklusiven globalen Iterationen wird durch11 nicht gestützt. Die Gleichheit mit dem globalen Ideal11 ist mit dem konkreten Trace vereinbar, wird aber durch die Abweichungen der anderen Budgets nicht zu einem allgemeinen Gesetz.

Die100-ms-Zahlen zusätzlicher ITL-Überschreitungen16/11/4 sind nicht identisch mit den Kontextiterationenzahlen17/11/5. Endreste und Schwellenabhängigkeit können zu unterschiedlichen Zählungen beitragen; eine kausale Eins-zu-eins-Zuordnung einzelner Client-ITLs zu GPU-Prefill-Chunks ist nicht aufgezeichnet. Die Logs liefern keine Request-IDs je Kontextanteil. Direkte Chunkfolgen einzelnerE0…E3 lassen sich deshalb nicht ohne weitere Annahmen ausweisen. Keine solche Rekonstruktion wurde erfunden.

## 6. F4, Vor-Trigger- und Sequenzkontrollen

Tatsächlich gesendete Prompt-Hashes, Prompt-/Generierungs-Seeds und Request-Profile stimmen über alle drei Budgets für die wiederverwendeten Repeat-Identitäten überein. Neue Last:98304 angebotene Inputtokens, darunter je Burst8192 zusätzliche Prompttokens;8704 Outputtokens. Die gesamte matched-offered-workload-Prüfung ist bestanden. Tatsächliche GPU-Arbeit kann durch Chunking, Padding, Kompilierung und Logging abweichen und wird nicht als identisch behauptet.

Bei768 unterscheiden sich12 von64 gepaarten Victim-Ausgaben; sie bleiben in der Hauptanalyse.52 identische Ausgaben tragen zu allen8 Blöcken bei: Token32-Effekt1776,2 ms [1770,2;1783,0]. Die12 verschiedenen Ausgaben aus7 Blöcken ergeben1778,5 ms [1769,7;1787,5]. In beiden Gruppen bleibt der100-ms-Count-Effekt11; Excess liegt jeweils bei etwa916 ms.58 Paare sind durch Token32 identisch und zeigen ebenfalls1776,1 ms [1770,2;1782,9]. Diese nach der Ausgabe gebildeten Untergruppen sind diagnostisch, kein kausaler Selektionsnachweis.

Vor-Trigger-Hüllen reichen bei768 von5,2 bis127,7 ms je Block. Nach Abzug der jeweiligen maximalen absoluten Prä-Hülle verbleiben im Mittel1731,6 ms [1695,1;1762,2]; die individuelle konstante Kadenzfortschreibung8→16 lässt1774,2 ms [1768,1;1780,8] bis32 übrig. Die beobachteten Ausgangsunterschiede erklären diese Größenordnung in den benannten Kontrollen nicht. Ein vollständiges Gegenfaktual, verborgene Zustandskontrolle oder kausale Adjustierung ist damit nicht erbracht.

## 7. Konkretes wissenschaftliches Urteil

1. **Robust gegen die Teilbarkeitsalternative?** Ja für den begrenzten Häufigkeits-/Schwere-Konflikt bei50/100 ms: er tritt auch unter768 auf. Keine Behauptung unveränderter absoluter Verzögerungen oder Robustheit für alle Budgets/Deadlines.
2. **Welche Idealannahme ist vereinbar?** Globale11 ist mit768 vereinbar; exklusive Addition12 nicht mit der beobachteten aggregierten Iterationszahl. Beide einfachen Rechnungen erklären die drei Budgets nicht als allgemeine Mechanik. Request-ID-Zuordnung bleibt unbeobachtet.
3. **Bewertungsumkehr über drei Budgets?** Ja bei50/100 ms mit gegensätzlicher Rangrichtung und klaren benachbarten Kontrasten. Nicht bei25 ms für768 gegenüber2048.
4. **Zusätzlicher Erkenntniswert?** Ein nichtteilender Gegenbeleg zur notwendigen Teilbarkeit, die saubere Trennung von Kontextiterationszahl und schwellenbasierter Stallzahl sowie der nachgewiesene nichtmonotone Verlauf der Token32-/64-Zusatzzeit. Die Schlussfolgerung wird durch diese Grenzen präziser, nicht zu einem Schedulinggesetz erweitert.
5. **Für ICISSP geeignet?** Ja als kleine, eigenständige Validierungssektion/Abbildung innerhalb des bestehenden Papers, mit dem engen Teilclaim in MANUSCRIPT_RESULTS.md und ausdrücklich beibehaltenem negativem Primärbefund. Nicht als neue Primäranalyse oder behauptete optimale Budgetwahl.

**Messungen abgeschlossen. Keine vierte Variante, kein Qwen, keine andere GPU und keine weitere Kampagne. Die bereitgestellten Tabellen und der englische Ergebnisbaustein sind für die Manuskriptrevision vorgesehen.**
