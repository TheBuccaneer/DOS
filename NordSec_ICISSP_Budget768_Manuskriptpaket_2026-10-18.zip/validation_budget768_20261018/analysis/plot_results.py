"""Publication figure from audited CSVs; no campaign execution."""
import csv,os
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
os.environ['MPLCONFIGDIR']=str(ROOT/'figures/.mplconfig')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

def main():
    data=ROOT/'analysis/three_budget_results';out=ROOT/'figures'
    effects={(int(r['budget']),r['metric']):r for r in csv.DictReader((data/'effect_intervals.csv').open())}
    curves=list(csv.DictReader((data/'progress_curve_intervals.csv').open()))
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'svg.fonttype':'none'})
    fig=plt.figure(figsize=(10,7.3),layout='constrained');gs=fig.add_gridspec(2,2,height_ratios=[1.25,1])
    ax=fig.add_subplot(gs[0,:]);colors={512:'#2477a6',768:'#d27818',2048:'#8055a2'}
    for budget in [512,768,2048]:
        rr=[r for r in curves if int(r['budget'])==budget]
        x=[int(r['token_rank']) for r in rr];y=[float(r['mean']) for r in rr]
        ax.plot(x,y,color=colors[budget],label=f'Budget {budget}',lw=2)
        ax.fill_between(x,[float(r['ci_low']) for r in rr],[float(r['ci_high']) for r in rr],color=colors[budget],alpha=.16)
    ax.axhline(0,color='.6',lw=.7)
    ax.axvline(16,color='.7',lw=.7,ls=':');ax.axvline(32,color='.7',lw=.7,ls=':')
    ax.set(xlim=(1,64),xlabel='Output-token rank',ylabel='Additional trigger-relative time (ms)',
        title='A  Paired token-progress difference: burst minus no burst')
    ax.legend(loc='upper left',ncol=3,frameon=False);ax.grid(axis='y',alpha=.15)
    for column,metric,title,ylabel in [(0,'count','B  Exceedance frequency','Additional intervals per victim'),
                                      (1,'excess','C  Summed exceedance magnitude','Additional excess time (ms per victim)')]:
        ax=fig.add_subplot(gs[1,column])
        for offset,d,color,marker in [(-.17,25,'#7d7d7d','o'),(0,50,'#217ba0','s'),(.17,100,'#22804b','^')]:
            rows=[effects[b,f'{metric}_above_{d}ms_delta'] for b in [512,768,2048]]
            y=np.array([float(r['mean']) for r in rows]);lo=np.array([float(r['ci_low']) for r in rows]);hi=np.array([float(r['ci_high']) for r in rows])
            ax.errorbar(np.arange(3)+offset,y,yerr=[y-lo,hi-y],fmt=marker,color=color,capsize=3,ms=6,label=f'{d} ms target')
        ax.set(xticks=range(3),xticklabels=['512','768','2048'],xlabel='Prefill budget (tokens)',ylabel=ylabel,title=title)
        ax.set_xlim(-.4,2.4);ax.grid(axis='y',alpha=.15)
        if column==0:ax.legend(frameon=False,fontsize=8,loc='upper right')
    fig.get_layout_engine().set(h_pad=.13,w_pad=.10)
    for suffix in ['pdf','svg','png']:fig.savefig(out/f'budget768_validation.{suffix}',dpi=200,bbox_inches='tight')
    plt.close(fig)

if __name__=='__main__':main()
