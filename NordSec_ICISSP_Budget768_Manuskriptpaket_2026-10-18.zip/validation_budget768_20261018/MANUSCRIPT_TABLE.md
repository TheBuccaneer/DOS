# Audited three-budget results

| Paired endpoint effect (ms) | Budget512 | Budget768 | Budget2048 |
|---|---:|---:|---:|
| Trigger → token32 | 1294.4 [1279.2, 1310.0] | 1776.4 [1770.1, 1783.5] | 1727.7 [1715.0, 1741.0] |
| Token32 → token64 | 461.1 [452.4, 474.6] | 38.4 [30.1, 47.0] | 16.4 [7.1, 26.0] |
| Trigger → token64 | 1755.5 [1743.6, 1767.5] | 1814.8 [1803.5, 1828.5] | 1744.1 [1732.7, 1755.7] |
| Maximum post-trigger ITL | 109.4 [107.6, 111.2] | 167.3 [166.2, 168.5] | 434.3 [431.1, 437.5] |

| Target(ms) | Budget | Additional intervals/victim | Additional excess(ms/victim) |
|---:|---:|---:|---:|
| 25 | 512 | 18.38 [18.00, 18.88] | 1670.2 [1652.5, 1686.0] |
| 25 | 768 | 16.34 [14.08, 18.67] | 1748.1 [1742.6, 1753.6] |
| 25 | 2048 | 5.38 [4.62, 6.09] | 1692.9 [1676.1, 1710.3] |
| 50 | 512 | 17.00 [17.00, 17.00] | 1241.7 [1223.2, 1257.9] |
| 50 | 768 | 11.00 [11.00, 11.00] | 1466.1 [1461.9, 1471.1] |
| 50 | 2048 | 4.00 [4.00, 4.00] | 1590.7 [1573.4, 1609.0] |
| 100 | 512 | 16.00 [16.00, 16.00] | 432.2 [413.9, 448.4] |
| 100 | 768 | 11.00 [11.00, 11.00] | 916.1 [911.9, 921.1] |
| 100 | 2048 | 4.00 [4.00, 4.00] | 1390.7 [1373.4, 1409.0] |

| Contrast | Δ time to token32(ms) | Δ time to token64(ms) | Δ count,100ms | Δ excess,100ms |
|---|---:|---:|---:|---:|
| 768_minus_512 | 482.0 [464.7, 498.5] | 59.3 [42.2, 79.6] | -5.00 [-5.00, -5.00] | 483.9 [469.0, 501.5] |
| 768_minus_2048 | 48.7 [36.8, 59.4] | 70.7 [57.5, 83.1] | 7.00 [7.00, 7.00] | -474.6 [-495.6, -455.9] |
| 512_minus_2048 | -433.3 [-454.4, -411.5] | 11.4 [-7.9, 30.6] | 12.00 [12.00, 12.00] | -958.5 [-986.8, -930.9] |

All entries are means of eight paired block effects with pointwise95% exact percentile block-bootstrap intervals in brackets. Each episode first averages the fixed eight victims. Effects are burst minus no burst; budget contrasts subtract these effects within matching repeat identities. Post-trigger ITLs have a right receipt after the episode-specific trigger, including the crossing interval. A count is per victim; it is not summed over all eight victims. All eight blocks contribute to the main analysis. The768 arm was measured in a later session.

The fixed decode targets are25,50,100 ms; these are diagnostic thresholds, not independently established service-level objectives or an Etalon fluidity evaluation.
