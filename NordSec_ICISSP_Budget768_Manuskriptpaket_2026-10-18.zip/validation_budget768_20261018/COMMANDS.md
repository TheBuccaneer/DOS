# Reproduktion

Python: `/home/rock/projects/porto/.venv-py313-repair/bin/python`.
Plan-SHA: `48e519c34ee0a49cde1ec00cabb162a48f377a507c0438ba871cf3862def7e5f`. Der Nutzerauftrag erlaubt den neuen Arm nach bestandenem Gate, ohne weitere Rückfrage. Keine anderen Budgets starten.

```bash
cd /home/rock/.codex/.chatgpt-projects/g-p-6ac3aa45729881919c3a1edebe5c5965/revisions/validation_budget768_20261018
/home/rock/projects/porto/.venv-py313-repair/bin/python -B -m unittest discover -s reference_code -p 'test_*.py' -v
/home/rock/projects/porto/.venv-py313-repair/bin/python -B -m unittest -v test_extension
/home/rock/projects/porto/.venv-py313-repair/bin/python -B runtime.py dry-run --plan plan.json
/home/rock/projects/porto/.venv-py313-repair/bin/python -B runtime.py run --plan plan.json --approved-plan-sha 48e519c34ee0a49cde1ec00cabb162a48f377a507c0438ba871cf3862def7e5f --output-dir /home/rock/.codex/.chatgpt-projects/g-p-6ac3aa45729881919c3a1edebe5c5965/revisions/validation_budget768_20261018/serving_campaign_768
/home/rock/projects/porto/.venv-py313-repair/bin/python -B analyze_three.py --campaign768 /home/rock/.codex/.chatgpt-projects/g-p-6ac3aa45729881919c3a1edebe5c5965/revisions/validation_budget768_20261018/serving_campaign_768 --out /home/rock/.codex/.chatgpt-projects/g-p-6ac3aa45729881919c3a1edebe5c5965/revisions/validation_budget768_20261018/analysis/three_budget_results
```

Der Kampagnenzielordner darf vorher nicht existieren. Kein Resume/Wiederholen bei Fehler. Rohdaten bleiben erhalten. Analyseziel ebenfalls neu. Keine Änderungen im ursprünglichen512/2048-Verzeichnis. Benötigt vorhandene historische Promptquellen, alte32 Rohjournale und lokale Gewichte. Alle Serverstarts gehören zu den8 spezifizierten neuen Blöcken; keine separate GPU-Vorabkampagne.
