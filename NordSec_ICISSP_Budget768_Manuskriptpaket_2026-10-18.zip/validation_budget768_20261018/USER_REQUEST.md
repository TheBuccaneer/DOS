# Wissenschaftlicher Arbeitsauftrag – NordSec → ICISSP 2027
## Gezielte Validierung mit nichtteilendem Prefill-Budget 768

**Modus:** Scientific Audit + kontrollierte experimentelle Erweiterung  
**Repository:** `/home/rock/projects/DOS/` (NICHT DOS2)  
**Deadline:** 22. Oktober 2026  
**Priorität:** Hoch – genau eine gezielte Ergänzung des bestehenden NordSec-Papers.

## 1. Rolle und verbindlicher Kontext

Du arbeitest als wissenschaftlicher Mitarbeiter mit Schwerpunkt LLM-Serving, experimentelle Systems-Forschung, Reproduzierbarkeit und statistische Evaluation.

Deine Aufgabe ist nicht, eine neue Forschungsidee zu entwickeln, sondern eine bereits identifizierte methodische Unsicherheit unserer bestehenden ICISSP-Revision durch eine kleine, kontrollierte Messung zu untersuchen.

Die Forschungsrichtung ist eingefroren. Das vorhandene NordSec-Manuskript bleibt unsere Arbeit.

Es existieren genau zwei gültige NordSec-Reviews (−1 und 0). Der ursprüngliche nicht robuste Offload×Burst-Primärbefund bleibt unverändert.

**Wissenschaftliche Grundregeln:**

- Keine erfundenen Ergebnisse oder behaupteten Prüfungen ohne tatsächlichen Zugriff.
- Unsicherheiten, nicht überprüfte Annahmen und fehlende Daten ausdrücklich kennzeichnen.
- Negative Ergebnisse und Gegeninterpretationen gleichberechtigt berücksichtigen.
- Keine neuen Hypothesen nach Betrachtung der Messwerte entwickeln.
- Keine unnötige Abwertung bereits validierter Ergebnisse.
- Keine Änderung oder Überschreibung historischer Daten.

## 2. Ausgangsbefund

Eine neue kontrollierte Validierungskampagne mit Llama-3.1-8B-Instruct umfasst 32 Episoden:

- Prefill-Budgets 512 und 2048.
- Je acht gepaarte Burst/No-Burst-Blöcke.
- Acht feste Victim-Requests.
- Burst mit vier Requests zu jeweils 2048 Input-Tokens.
- Kein Client-Semaphore-Backpressure.
- Trigger nach mindestens 16 empfangenen Output-Tokens aller Victims.
- Raw-SSE-Aufzeichnung, Scheduler-Iterationslogs und geprüfte gepaarte Auswertung.

Die bisherigen Ergebnisse zeigen:

| Endpunkt | Budget 512 | Budget 2048 |
|---|---:|---:|
| Zusätzliche Zeit bis Token 32 | 1.294 ms | 1.728 ms |
| Zusätzliche Zeit bis Token 64 | 1.756 ms | 1.744 ms |
| Zusätzliche Zeit zwischen Token 32 und 64 | 461 ms | 16 ms |
| Zunahme maximale Post-Trigger-ITL | 109 ms | 434 ms |
| Zusätzliche ITL-Grenzwertüberschreitungen bei 100 ms | ca. 16 | ca. 4 |
| Summe der zusätzlichen Überschreitungshöhe bei 100 ms | ca. 432 ms | ca. 1.391 ms |

Die zentrale Beobachtung: Ein kleineres Prefill-Budget verteilt den zusätzlichen Token-Fortschrittsverlust über mehr Intervalle. Die Zahl der Deadline-Überschreitungen nimmt zu, während deren aufsummierte Schwere sinkt.

Die beiden Bewertungsgrößen können deshalb unterschiedliche Präferenzen für dieselbe Konfiguration erzeugen.

## 3. Offene methodische Frage

Die bisherigen Budgets 512 und 2048 teilen sowohl die einzelnen Burst-Prompts mit 2048 Input-Tokens als auch die gesamte angebotene Burst-Inputlast von 8192 Tokens restlos.

Damit entsteht eine alternative Erklärung: Die beobachtete Beziehung zwischen Budget und Stallanzahl könnte teilweise durch die besonders regelmäßige Zerlegung des Workloads begünstigt sein.

Wir prüfen deshalb **genau ein zusätzliches Budget: 768 Tokens**.

Die idealisierten Rechnungen lauten:

| Budget | ceil(8192/B) | 4 × ceil(2048/B) |
|---|---:|---:|
| 512 | 16 | 16 |
| 768 | 11 | 12 |
| 2048 | 4 | 4 |

Diese Rechnungen sind ausdrücklich **keine bestätigten Scheduler- oder Stallvorhersagen**.

Die tatsächlich beobachteten Scheduler-Iterationen waren bereits bei den bisherigen Budgets nicht identisch mit diesen einfachen Quotienten.

Insbesondere gilt:

- Die Zahl der Deadline-Verletzungen ist nicht automatisch die Zahl der Prefill-Chunks.
- Laufende Decode-Requests können Tokenbudget verbrauchen.
- Chunk-Zerlegung, Request-Zuordnung und Iterationsanzahl hängen vom tatsächlichen vLLM-Scheduler ab.
- Die globale und die requestbezogene Idealrechnung sind nur dann unterscheidbare mechanistische Hypothesen, wenn der konkrete Scheduler und die Logs eine entsprechende Interpretation erlauben.

**Ziel ist eine belastbare Gegenprobe zur Teilbarkeitsalternative, nicht die erzwungene Entdeckung eines neuen Schedulinggesetzes.**

## 4. Phase A – READ-ONLY Bestandsaufnahme

Untersuche zuerst die vorhandene Validierungskampagne und ihre zugehörigen Skripte.

Wichtiger Arbeitsordner:

`/home/rock/.codex/.chatgpt-projects/g-p-6ac3aa45729881919c3a1edebe5c5965/revisions/validation_no_semaphore_20261018/`

Nutze insbesondere:

- Den eingefrorenen Versuchsplan `plan.json`.
- Den vorhandenen `runtime.py`-Runner.
- Die Collect-/Verify-/Instrumentierungs- und Analysekomponenten.
- Die originale 32-Episoden-Kampagne und deren Serverlogs.
- Die vorhandenen Raw-SSE-Audits.
- Die bisherigen Deadline- und Token-Fortschrittsauswertungen.

Prüfe anhand des tatsächlichen vLLM-0.17.1-Scheduler-Codes, ob Budget 768 unter der bestehenden Konfiguration zulässig ist und welche Wirkung dieses Budget auf die Prefill-Zerlegung haben kann.

Verifiziere die vorhandenen Skriptparameter und den realen Versionsstand.

**Keine Änderungen am ursprünglichen Versuchsplan.**

## 5. Phase B – Eingefrorenes Zusatzexperiment

Es soll genau ein neuer Messarm durchgeführt werden.

| Faktor | Festlegung |
|---|---|
| Modell | Llama-3.1-8B-Instruct |
| GPU | RTX 3090 |
| vLLM | 0.17.1 |
| Python | 3.13.7 |
| Umgebung | `/home/rock/projects/porto/.venv-py313-repair/` |
| CPU-Offload | 0 GiB |
| Victims | 8 identitätsfeste Requests |
| Victim-Profil | 256 Input / 64 Output |
| Burst | 4 × (2048 Input / 16 Output) |
| Prefill-Budget | **768** |
| `max_num_seqs` | 16 |
| `max_model_len` | 8192 |
| Trigger | 16 Output-Tokens je Victim |
| Repeats | 8 |
| Bedingungen | Burst / No-Burst |
| Umfang | **16 zusätzliche Episoden** |

Alle übrigen Konfigurationen, Seeds, Prompt-Identitäten, Generierungsparameter, Ressourcenbegrenzungen, Laufreihenfolgeregeln, Warm-up-Verfahren und Messbedingungen sollen so weit wie möglich exakt der bestehenden 512/2048-Kampagne entsprechen.

Insbesondere `num_gpu_blocks_override`, Chunked-Prefill-Einstellungen und Logging nicht stillschweigend verändern.

Verwende dieselben Repeat-Identitäten 1–8, sofern die bisherigen Messpläne deren deterministische Wiederverwendung bestätigen.

Eine Änderung gegenüber dem ursprünglichen Design ist ausschließlich für das neue Prefill-Budget erlaubt.

## 6. Phase C – Vorab festgelegte Forschungsfragen

### F1 – Scheduler-Zerlegung

Wie werden die 8192 angebotenen Burst-Input-Tokens unter Budget 768 tatsächlich auf Scheduler-Iterationen und einzelne Requests verteilt?

Vor der Messung die durch statische Scheduleranalyse gestützten Erwartungen und deren Unsicherheiten dokumentieren.

Nach der Messung anhand tatsächlicher Iterationslogs überprüfen.

Keine Stallzahl allein aus der arithmetischen Teilbarkeit ableiten.

### F2 – Token-Fortschritt

Bleibt der Unterschied zwischen frühem Fortschrittsverlust und zusätzlicher Zeit bis Token 64 auch bei Budget 768 nachvollziehbar?

Zu berechnen:

- Trigger → Token 32.
- Token 32 → Token 64.
- Trigger → Token 64.
- Maximale Post-Trigger-ITL.
- Vollständige triggerrelative Fortschrittskurve.

### F3 – Deadline-Bewertungsumkehr

Untersuche die vorab festgelegten Decode-Zielwerte 25, 50 und 100 ms.

Für jeden Zielwert:

**Metrik A:** Anzahl der Inter-Token-Intervalle mit ITL oberhalb des Zielwerts.

**Metrik B:** Aufsummierte Überschreitungshöhe:

`sum(max(ITL - deadline, 0))`

Beide Größen müssen identisch gefilterte Tokenintervalle und Victim-Populationen verwenden.

Berechne Burst-minus-No-Burst-Effekte je gepaartem Block und vergleiche anschließend die Budgets 512, 768 und 2048.

Dokumentiere, ob die Metriken weiterhin unterschiedliche Budgetbewertungen liefern.

Weder Monotonie noch ein bestimmter Umkehrpunkt dürfen vorausgesetzt werden.

### F4 – Identische angebotene Arbeit

Prüfe, dass Victim-Prompts und angebotene Burst-Tokenarbeit über die drei Budgetkonfigurationen übereinstimmen.

Unterscheide ausdrücklich:

- **Matched offered workload:** identisch angebotene Tokens und Request-Profile.
- **Actual computational work:** tatsächlich ausgeführte GPU-Arbeit, die durch Scheduling- und Chunking-Overhead abweichen kann.

Es darf keine unbelegte Behauptung identischer GPU-Rechenkosten geben.

## 7. Phase D – Statistische Auswertung und Audit

Verwende die gleichen wissenschaftlichen Analyseprinzipien wie in der bereits abgeschlossenen Kontrollkampagne.

- Acht gepaarte Blöcke als unabhängige Auswertungseinheiten.
- Dieselbe Effektdefinition und ein dokumentiertes Block-Bootstrap-Verfahren.
- Konfidenzintervalle für absolute Unterschiede.
- Gepaarte Budgetkontraste anhand der Repeat-Identitäten.
- Keine Request- oder Token-Pseudoreplikation.
- Keine nachträgliche Auswahl günstiger Wiederholungen.
- Abweichende generierte Tokenfolgen dokumentieren und durch eine Sensitivitätsanalyse berücksichtigen.
- Vor-Trigger-Unterschiede prüfen.
- Technische Ungültigkeit nach eingefrorenen Kriterien behandeln.
- Fehlende oder unvollständige Episoden ausdrücklich dokumentieren.

Die 512er- und 2048er-Ergebnisse dürfen ausschließlich READ-ONLY für den Dreiervergleich verwendet werden.

Das neue Budget 768 darf nicht in den ursprünglichen historischen Analyseplan hineingeschrieben werden.

**Die neue Messung ist eine vorab spezifizierte retrospektive Erweiterung des Forschungsprogramms, keine neue historische Primäranalyse.**

## 8. Phase E – Umsetzung und Durchführung

Lege einen neuen, separaten Experimentordner für Budget 768 an.

Erstelle darin:

1. Einen eingefrorenen, gehashten Messplan.
2. Die minimal erforderliche Runner-Konfiguration.
3. Eine kurze Dokumentation der unveränderten und geänderten Parameter.
4. Eine reproduzierbare Startanleitung.
5. Automatisierte Integritäts- und Gültigkeitsprüfungen.
6. Einen separaten Ergebnis- und Audit-Ordner.

Verwende die bestehende Python-3.13-Umgebung:

`source /home/rock/projects/porto/.venv-py313-repair/bin/activate`

Führe die vorhandenen Offline-Tests sowie einen Dry-Run mit dem neuen Plan durch.

**Bei bestandenem technischen Gate kannst du die genau 16 spezifizierten Messepisoden starten.**

Falls dafür mehr als kleine, klar begründete Codeänderungen notwendig werden oder wesentliche Konfigurationsabweichungen auftreten, halte vor dem GPU-Start an und berichte.

Nach einem Fehler keine stillschweigenden Wiederholungen, keine Parameteroptimierung und keine zusätzlichen Budgetvarianten.

Das bestehende 32-Episoden-Experiment bleibt unverändert.

## 9. Abbruchregeln

Stoppe die neue Erweiterung, wenn:

- Budget 768 technisch nicht zulässig oder nicht wirksam ist.
- Der bestehende Runner einen größeren Umbau benötigt.
- Die benötigte Instrumentierung nicht zuverlässig funktioniert.
- Das Timingfenster am Trigger technisch ungültig wird.
- Die tatsächliche Konfiguration nicht mit der geplanten übereinstimmt.
- Die neue Kampagne nicht vollständig und sauber auditierbar ist.

Bei einem solchen Fall keine improvisierte Ersatzkampagne entwickeln.

Die bisherigen Ergebnisse sind unabhängig davon weiterhin die Grundlage der ICISSP-Einreichung.

## 10. Erwartete Ergebnisse

Erstelle nach erfolgreichem Messlauf:

**A. Technischer Auditbericht**

- 16 Episoden und acht Paare überprüft.
- Vollständigkeit der Raw-SSE-Daten.
- Prompt-/Seed-Identität.
- Trigger- und Dispatchvalidierung.
- Effektive Budgetkonfiguration.
- Tatsächliche Scheduler-Iterationsstruktur.
- Fehler, Abweichungen und verbleibende Unsicherheiten.

**B. Wissenschaftliche Auswertung**

- Tabelle der drei Budgets 512/768/2048.
- Token-32-/64-Effekte mit Unsicherheitsintervallen.
- Deadline-Häufigkeit und Überschreitungshöhe bei 25/50/100 ms.
- Direkte gepaarte Budgetkontraste.
- Mechanistische Alternativerklärungen.
- Eine geeignete Abbildung des Token-Fortschritts.

**C. Wissenschaftliches Urteil**

Beantworte konkret:

1. Ist die bisherige Beobachtung robust gegenüber einem nichtteilenden Prefill-Budget?
2. Welche der einfachen Chunk-Zerlegungsannahmen sind mit den Schedulerlogs vereinbar?
3. Ist die Deadline-Bewertungsumkehr auch bei drei Budgetkonfigurationen nachvollziehbar?
4. Welchen zusätzlichen Erkenntniswert liefert Budget 768 gegenüber den bisherigen Daten?
5. Ist der Zusatzbefund für das bestehende ICISSP-Manuskript geeignet?

Bewerte die Ergebnisse ehrlich, unabhängig davon, ob sie die Erwartungen bestätigen oder widerlegen.

**D. Übergabe**

Lege den vollständigen Audit, die Ergebnis-CSVs, Reproduktionsskripte und Abbildungen in einem separaten Ordner ab und erstelle zusätzlich ein ZIP zur Übergabe an ChatGPT für die Manuskriptrevision.

## 11. Harte Scope-Grenze

Dies ist die letzte vorgesehene experimentelle Erweiterung vor der ICISSP-Frist.

- Kein Qwen.
- Kein viertes Budget.
- Keine zweite GPU.
- Keine neue Cache-Isolationsstudie.
- Keine umfassende Scheduler-Parametersuche.
- Keine ungefragte zusätzliche Experimentkampagne.

Nach Abschluss oder technischem Abbruch unmittelbar zur Überarbeitung des bestehenden NordSec-Manuskripts zurückkehren.

**Beginne jetzt mit der technischen Bestandsaufnahme. Arbeite nach bestandenem Gate eigenständig bis zur vollständig auditierten 768er-Auswertung.**