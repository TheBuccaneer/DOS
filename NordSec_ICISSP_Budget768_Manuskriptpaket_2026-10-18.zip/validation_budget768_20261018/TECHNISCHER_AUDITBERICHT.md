# Technischer Audit: Budget768

**Ergebnis:16/16 Episoden und8/8 Paare gültig; keine Wiederholung, keine Ersatzepisode, keine Fehler oder Cleanup-Fehler.** Genau der genehmigte768-Arm wurde ausgeführt. Eine rein lesende Abschlussabfrage findet danach keine CUDA-Rechenprozesse. Keine weitere Kampagne gestartet.

## Vorab-Gate und Umsetzung

Die32 vorhandenen Episoden wurden aus allen Rohjournalen erneut gelesen; alle18048 SSE-data-Ereignisse und zugehörigen Serverlog-Byte-Segmente bestanden die Prüfung. Installierter vLLM-0.17.1-Validator akzeptierte768 mit Chunking und Modelllänge8192.29 unveränderte Tests in lokalen Quellenkopien und5 Ergänzungstests bestanden. Dry-Run:16 Episoden/160 Completion-Requests, genau8 neue Serverstarts. Tatsächliche Laufzeitumgebung: Python3.13.7 in `.venv-py313-repair`, vLLM0.17.1, Torch2.10.0, HTTPX0.28.1, Transformers4.57.6, RTX3090, Treiber580.178.04.

Plan und Protokoll wurden vor dem Start eingefroren. Plan-SHA256:
`48e519c34ee0a49cde1ec00cabb162a48f377a507c0438ba871cf3862def7e5f`.

Änderungen beschränken sich auf einen separaten Ordner: neuer768-Plan aus den512-Repeat-Identitäten, direkte Nutzung der reparierten Umgebung, dynamische Umfangsanzeige im Runner sowie vorab festgelegter Nachweis der768-Budgetwirkung. instrument.py, verify.py und wire_checks.py sind bytegleich zum alten Freeze. Der originale32-Episoden-Plan wurde nicht angepasst. Die konkrete Differenz steht in evidence/minimal_runner_changes.patch. Die32-Episoden-Tests schreiben nur in neue lokale Quellenkopien, nicht in die historische Kampagne.

## Vollständigkeit und Identität

| Größe | Geprüfter Wert |
|---|---:|
| Neue Episoden / Paare |16 /8|
| Victim-Requests / Burst-Requests |128 /32|
| Gepaarte Victim-Identitäten |64|
| Completion-Requests insgesamt |160|
| Raw-SSE-data-Ereignisse |9024|
| Angebotene Inputtokens |98304|
| Empfangene Outputtokens |8704|
| Fehlende/ungültige Episoden |0|
| Nicht identische generierte Victim-Ausgaben |12 von64 Paaren|

Geprüft: lückenlose Journal-Indizes, Request-ID/Index, Prompt-Hash aus tatsächlich gesendetem Payload, Prompt- und Generierungs-Seeds, Prompt-Echo, vollständige Tokenlisten, Usage/DONE/Finish, Terminalreihenfolge und vollständiger Abgleich der Wire-/Executor-/Ergebniskopien. Geprüft sind SSE-data-Nutzdaten des historischen Transports, keine TCP-Rohbytes oder SSE-Kommentare. Die aufgezeichneten Empfangszeitpunkte sind Client-Receipts.

## Trigger- und Dispatchprüfung

Wissenschaftlicher Trigger bleibt das Maximum der acht Token16-Receipts, mit eigenem Trigger je Bedingung. Alle Beobachter und vier Burst-Hooks hatten Zähler16…31; diese Zähler wurden im Post-Audit unabhängig aus den Raw-Zeiten rekonstruiert. Alle Victims hatten Token32 weder am Trigger noch am letzten Burst-Hook erreicht. Kleinste letzte-Hook→Token32-Lücke:2052.326 ms. Diese Lücke enthält bereits die behandelte Client-Verzögerung und ist kein unbeeinflusstes Zeitfenster oder Beleg einer Server-Admission.

Je Episode sind Trigger→Beobachter, erster/letzter Hook und alle Hook-Zähler in den Audit-CSVs erhalten. Alle16 bestehen unverändert die vorher eingefrorenen technischen Fensterkriterien. Kein Fehler wurde aufgrund einer Effektgröße entfernt. Der HTTPX-Hook liegt vor dem Transport, nicht am Socket oder beim Server-Prefill.

## Tatsächliche Konfiguration und Abweichungen

Vor-/Nach-Snapshots jeder Episode sind identisch. Fester KV-Pool1024×16, Prefix aus, Offload0, Chunking an, max_num_seqs16, Modelllänge8192, Serverseed, Generierungsparameter, Instrumentierung, Logging, Pausen und Ressourcenlimits entsprechen der vorhandenen Kampagne. Exakte Request-/Prompt-/Generation-/uncached-Kontextzähler, Idle-Grenzen, Prozessbindung, null Preemption, keine Zählerresets/Fremdlast und maximal250-ms-Metriklücken bestanden. Iterationslogs sind lückenlos und context+decode überschreitet768 nicht.

Der vollständige Blattvergleich mit beiden alten Armen fand nur: Budgetwert; daraus automatisch abgeleitete encoder_cache_size und max_num_encoder_input_tokens; budgetabhängige compile_ranges_split_points; neue Server-instance_id. Die Encoderfelder werden in installiertem scheduler.py:227–228 auf das Budget gesetzt. Der Compile-Bereich endet laut config/vllm.py:1492–1495 bei max_num_batched_tokens. Werte somit[512]/[768]/[2048]. Die prozessabhängige instance_id ist innerhalb eines Paares gleich. Es wurden keine anderen festgesetzten Parameterabweichungen gefunden.

Diese vollständige Auflistung abgeleiteter Felder erfolgte erst im Post-Audit; sie wird nicht als bereits vollständig vorab geprüft dargestellt. Es sind keine heimlich manuell geänderten Einstellungen. Insbesondere darf der Vergleich deshalb nicht als isolierter Effekt einer einzigen Chunk-Zahl bei identischem Kompilierungspfad/GPU-Aufwand beschrieben werden. Der eingefrorene Text wies bereits mögliche Compile- und tatsächliche Arbeitsunterschiede aus. Rohdifferenzen stehen in audit/RAW_AUDIT.json, Quellennachweise in DERIVED_CONFIGURATION.json.

## Scheduler-Zerlegung

Jeder Burst weist exakt8192 Zusatz-Kontexttokens nach der abgeschlossenen initialen2048-Kontextgrenze auf. In allen8 Blöcken:

`760,760,760,759,759,759,758,758,758,757,604`.

Das sind11 Kontextiterationen; die ersten10 füllen das gemeinsame768-Budget zusammen mit Decodearbeit, die letzte ist ein Rest. Drei Kontextiterationen enthalten jeweils zwei Kontextrequests. Budgetwirkung ist tatsächlich beobachtet: max Zusatzkontext760>512, budgetnahe gemischte Iterationen in allen8 Blöcken. Bereits die alten Budgets hatten17 und5 Zusatz-Kontextiterationen, keine ideale16/4-Zerlegung.

Vorhandene Logs identifizieren keine einzelnen Request-IDs pro Iteration. Damit ist keine direkt beobachtete Chunkfolge fürE0…E3 lieferbar; eine solche Zuordnung würde Zusatzannahmen über Admission/Reihenfolge erfordern. Die11 aggregierten Iterationen widerlegen eine additive Rechnung von12 exklusiven globalen Iterationen, nicht die Möglichkeit mehrerer lokaler Fragmente pro Request.11 ist mit der globalen Untergrenze vereinbar, kein Schedulinggesetz. Gleiche Client-ITL-Zahl und Kontextiterationszahl bei768 beweisen keine allgemeine Eins-zu-eins-Zuordnung; bei512/2048 unterscheiden sie sich.

## Unverändertheit und Herkunft

134 vorab inventarisierte Dateien der vorhandenen Vorbereitung/Kampagne blieben SHA256-identisch. Ebenso alle vorab eingefrorenen Erweiterungsdateien. Tatsächlich ausgeführte Plan-, Manifest- und Python-Dateihashes wurden mit approval_binding.json abgeglichen. Referenzsoftware und aktive Modell-/Promptquellen wurden nicht verändert. Die neuen Dateien liegen ausschließlich im separaten Erweiterungsordner. Vollständige Modellgewicht-Bytegleichheit mit der historischen Juli-Kampagne wird weiterhin nicht behauptet.

## Wissenschaftliche Grenzen

Neue768-Daten stammen aus einer späteren Sitzung; nur die Workload-Familien und Within-Budget-Bedingungen sind gepaart. Zeit-/Takt-, Compilation-/Profiling- und Instrumentierungskosten können direkte Budgetkontraste mitprägen. Die acht Blöcke und punktweisen Bootstrap-CIs sichern keine allgemeine Population, Produktions-SLO oder alle versteckten Systemzustände ab. Gleich angebotene Arbeit ist geprüft, gleiche tatsächliche GPU-Rechenkosten sind nicht geprüft. Client-Receipts und aggregierte Logs identifizieren keine serverinterne Ursache. Der negative historische Offload×Burst-Primärbefund bleibt unverändert.

**Technischer Abschluss erreicht. Kein weiterer Messarm oder Nachlaufexperiment erforderlich/gestartet.**

## Hinweis zu konservativen Rohstatusfeldern

Der unveränderte Collector schreibt in campaign_summary.json die Platzhalter actual_budget_difference_demonstrated=False und scientific_claim_established=False. Er aktualisiert diese nicht aus der späteren Drei-Budget-Analyse. Dies ist keine gemeldete technische Ungültigkeit: die einzelnen Assessments und alle acht verpflichtenden768-Manipulationsprüfungen bestanden. Der abschließende technische/wissenschaftliche Status steht separat in audit/FINAL_VERDICT.json und diesem Bericht; es wird kein Rohstatus nachträglich überschrieben.
